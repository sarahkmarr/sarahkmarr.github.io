The HP-45 is a vintage RPN calculator, first sold in 1973. The beauty of its design is
matched by the beauty of the code used to make it work. But, it is almost 50 years old
at the time of writing, and increasingly hard to come by. So, I thought it might be
interesting and educational to try to create a simulator for it which would run on the
Z80-MBC2, which is single-board Z80-based machine which runs a CP/M environment. Later,
I added compile-time instructions to enable compilation on Mac, Windows, and Linux.

This release includes:

 - compiled code to run on all four platforms
 - source code (which does not include the HP-45 ROM instructions but is otherwise
   complete)
 - an annotated listing of the HP-45 ROM to help others understand what it's doing

The way that storage, logic and program flow occur on the HP-45 is clever, but not
entirely obvious. The best way to understand what's going on is to look at the comments
in the code, which are detailed and numerous. I've included the comments from the start
of the code below.

This whole endeavour is just something I did for my own entertainment. Emulators for
the HP-45 already exist, and have their own graphical user interfaces, run on phones,
etc. Still, hopefully this will be of interest to others who want to see how the 'engine'
works, or whose hobby involves retrocomputing, or who just get a kick out of using the
terminal in this way.

Don't claim the work as your own. Don't use it commercially. Basically, if you know
that what you're planning to do with the code is just not very nice, please don't.

Anyway, enjoy.

Sarah K. Libman
20th December, 2021





Opening Comments from the Source Code
-------------------------------------

HP45TERM is a simulator of the HP-45 calculator. 

2021 Sarah K Libman

Please note that the distributed source code of this project does not contain the ROM
codes from the HP-45 calculator.

HP45TERM was written in C with the following aims:

 -  compile on multiple platforms (including a Z80-MBC2, running CP/M on a Z80 CPU, 
    for which it was designed) without the need for changes to the code or compile
    options
 -  keep the code simple (and well-commented) to maximize compatibility and minimize
    coding experience needed to understand it (this does not mean it's well-written code:
    it almost certainly isn't)
 -  indent code and comments to separate code simulating the calculator from code
    concerned with managing and displaying additional information to the user
 -  provide information about the internal operations and states of the calculator but...
 -  ... provide a way to bypass unecessary 'cosmetic' processing to run on slower systems
 -  include help screens so the program is self-documenting when run
 -  run the same way on different platforms; i.e. same keypresses, error checking, etc.

HP45TERM is designed to run in an 80x24 ANSI (or VT100) terminal. Fewer columns or rows
will definitely cause problems. More columns or rows should be all right, for the most
part.

The code has been compiled and executed successfully using gcc on Mac, Linux and DietPi
(for Raspberry Pi OS), and on Windows (using mingw-w64 for x86_64 architectures). It was
originally written to run on a Z80-MBC2, running CP/M on a Z80 CPU, for which it has been
cross-compiled on Mac using sd88k. The CP/M version should also run on appropriate
emulators. I'm pretty sure sd88k could be used to compile for TRS-80, etc. with minimal
changes.

For Z80 CP/M:        zcc +cpm -o hp45term.com hp45term[release].c
For Mac:             gcc hp45term[release].c -o hp45term-mac.com
For Linux:           gcc hp45term[release].c -o hp45term-linux.com
For Windows:         gcc hp45term[release].c -o hp45term-win.com
For DietPi / Pi OS:  gcc hp45term[release].c -o hp45term-pi.com

The best way to learn to use HP45TERM is to work through the HP-45 documentation which
is available on the internet. The built-in help screens will show you which key does what
when needed.

A note on THE SHIFT KEY:
Just like the HP-45, the shift key is a key pressed prior to the pressing of the desired
shifted function: it is not simulated by using the "shift" key on the terminal keyboard.
To obtain shifted functions (e.g. inverse sine) use the ' (apostrophe) key.

A note on quitting hp45term:
It's an uppercase 'Q' — shift+q — to avoid accidental quitting.

A note on THE HEAT MAP:
The HP-45 has 8 ROMs, each with 256 10-bit bytes which encode both an operator and a
parameter. (I marvel at the way so much was fitted into so little storage, so elegantly.)
When a key is pressed, execution moves from byte to byte and ROM to ROM until the display
is updated. (On the calculator itself, a loop then runs, waiting for a keypress. In the
simulator, execution stops and hands over to the terminal until a key press is
registered.) The 'heat map' shows which bytes of the 8 ROMs are being used between the
keypress and the updating of the display. So, if the key for SIN is pressed, the heatmap
shows where processing of the sine function occurs. To do this in the limited space
available, the heat map splits each ROM into 32 blocks of 8 bytes each: 0-7, 8-15, etc.
When a key is pressed the count for each block is set to zero. If execution passes to any
byte within a block, that block's count is incremented. If execution passes to a block
more than 9 times, that block is shown with an X on the heat map. The heat map can either
display all the block values when execution is complete or (much more slowly) as each
block value increments. It's much easier to just watch in action than to describe.

HP45TERM was written from scratch, as a challenge, rather than being a port of existing
simulators. It will come as no surprise, though, given the nature of writing a simulator, 
that it looks similar to existing simulators (by Eric Smith and David Hicks, in 
particular) in structure and functions: both are thanked in HP45TERM's help screens.

Finally: this was done for fun, as a way to pass time during Covid lockdown, so I make no
promises to update it, fix errors, or anything else. But I hope you enjoy it.

The program is distributed WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.