// HP45TERM is a simulator of the HP-45 calculator. 

// 2021 Sarah K Libman

// Please note that the distributed source code of this project does not contain the
// ROM codes from the HP-45 calculator.

// HP45TERM was written in C with the following aims:

//  - 	compile on multiple platforms (including a Z80-MBC2, running CP/M on a Z80 CPU, 
//      for which it was designed) without the need for changes to the code or compile
//  	options
//  - 	keep the code simple (and well-commented) to maximize compatibility and minimize
//  	coding experience needed to understand it (this does not mean it's well-written code:
//      it almost certainly isn't)
//  -   indent code and comments to separate code simulating the calculator from code
//      concerned with managing and displaying additional information to the user
//  -	provide information about the internal operations and states of the calculator but...
//  -	... provide a way to bypass unecessary 'cosmetic' processing to run on slower systems
//  -   include help screens so the program is self-documenting when run
//  -   run the same way on different platforms; i.e. same keypresses, error checking, etc.

// HP45TERM is designed to run in an 80x24 ANSI (or VT100) terminal. Fewer columns or rows will
// definitely cause problems. More columns or rows should be all right, for the most part.

// The code has been compiled and executed successfully using gcc on Mac, Linux and DietPi
// (for Raspberry Pi OS), and on Windows (using mingw-w64 for x86_64 architectures). It was
// originally written to run on a Z80-MBC2, running CP/M on a Z80 CPU, for which it has been
// cross-compiled on Mac using sd88k. The CP/M version should also run on appropriate
// emulators. I'm pretty sure sd88k could be used to compile for TRS-80, etc. with minimal
// changes.

// For Z80 CP/M:        zcc +cpm -o hp45term.com hp45term[release].c
// For Mac:             gcc hp45term[release].c -o hp45term-mac.com
// For Linux:           gcc hp45term[release].c -o hp45term-linux.com
// For Windows:         gcc hp45term[release].c -o hp45term-win.com
// For DietPi / Pi OS:  gcc hp45term[release].c -o hp45term-pi.com

// The best way to learn to use HP45TERM is to work through the HP-45 documentation which
// is available on the internet. The built-in help screens will show you which key does what
// when needed.

// A note on THE SHIFT KEY:
// Just like the HP-45, the shift key is a key pressed prior to the pressing of the desired
// shifted function: it is not simulated by using the "shift" key on the terminal keyboard.
// To obtain shifted functions (e.g. inverse sine) use the ' (apostrophe) key.

// A note on quitting hp45term:
// It's an uppercase 'Q' — shift+q — to avoid accidental quitting.

// A note on THE HEAT MAP:
// The HP-45 has 8 ROMs, each with 256 10-bit bytes which encode both an operator and a parameter.
// (I marvel at the way so much was fitted into so little storage, so elegantly.) When a key is
// pressed, execution moves from byte to byte and ROM to ROM until the display is updated. (On the
// calculator itself, a loop then runs, waiting for a keypress. In the simulator, execution stops
// and hands over to the terminal until a key press is registered.) The 'heat map' shows which
// bytes of the 8 ROMs are being used between the keypress and the updating of the display. So, if
// the key for SIN is pressed, the heatmap shows where processing of the sine function occurs. To do
// this in the limited space available, the heat map splits each ROM into 32 blocks of 8 bytes each:
// 0-7, 8-15, etc. When a key is pressed the count for each block is set to zero. If execution
// passes to any byte within a block, that block's count is incremented. If execution passes to a
// block more than 9 times, that block is shown with an X on the heat map. The heat map can either
// display all the block values when execution is complete or (much more slowly) as each block value
// increments. It's much easier to just watch in action than to describe.

// HP45TERM was written from scratch, as a challenge, rather than being a port of existing
// simulators. It will come as no surprise, though, given the nature of writing a simulator, 
// that it looks similar to existing simulators (by Eric Smith and David Hicks, in 
// particular) in structure and functions: both are thanked in HP45TERM's help screens.

// Finally: this was done for fun, as a way to pass time during Covid lockdown, so I make no
// promises to update it, fix errors, or anything else. But I hope you enjoy it.

// The program is distributed WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

// Code associated with the HP-45 — registers, pointers, operations, etc. is indented from left     with comments here    
//                  Code associated with display and control is indented to here                                        with comments here

// Global variables take the form _alpha or alpha_Alpha.
// Local variables take the form alphaAlpha.
// Assembler macros take the form ALHPA_ALPHA.

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#if defined (__APPLE__) || defined (__linux__)                                                                          
    #include <termios.h>                                                                                                // Mac/Linux : terminal management header
    #include <unistd.h>                                                                                                 // Mac/Linux : used in terminal management code
    #define MACLINUX                                                                                                    // Mac/Linux : for use in main code
#endif
#if defined (WIN32) || defined (_WIN32) || defined (WIN64) || defined (_WIN64)                                          
    #include <windows.h>                                                                                                // Windows : header used in setting terminal mode
    #include <fcntl.h>                                                                                                  // Windows : header used in setting binary/text mode for stdin
    #define ENABLE_VIRTUAL_TERMINAL_PROCESSING 0x0004                                                                   // Windows : used in setting terminal output mode
    #define ENABLE_VIRTUAL_TERMINAL_INPUT 0x0200                                                                        // Windows : used in setting terminal input mode
    #define WINDOWS                                                                                                     // Windows : for use in main code
#endif

// +----------------------------------------------------------------------------
// |    ASSEMBLER MACROS
// +----------------------------------------------------------------------------
                    #define ESC_CHR 27                                                                                  // escape character code used as prefix for terminal display codes

#define REG_A 0                                                                                     // the values of n in r_G[n][m]                                            
#define REG_B 1
#define REG_C 2
#define REG_D 3
#define REG_E 4
#define REG_F 5
#define REG_M 6
                                                                                                    // the values of n in _nibbles[n][m]
#define C_P 0                                                                                       // 0 P  Pointer (nibble indicated by pointer) [P]
#define C_M 1                                                                                       // 1 M  Mantissa [12, 11, ..., 3]
#define C_X 2                                                                                       // 2 X  Exponent [2, 1, 0]
#define C_W 3                                                                                       // 3 W  Word (entire register) [13, 12, ..., 0]
#define C_WP 4                                                                                      // 4 WP Word up to and including nibble indicated by pointer [P, P-1, ..., 0]
#define C_MS 5                                                                                      // 5 MS Mantissa and Sign [13, 12, ..., 3]
#define C_XS 6                                                                                      // 6 XS Exponent Sign [2]  : 0 if positive and 9 if negative, may hold other values
#define C_S 7                                                                                       // 7 S  Mantissa Sign [13] : 0 if positive and 9 if negative, may hold other values


// +----------------------------------------------------------------------------
// |    HP45 : GLOBAL VARIABLES
// +----------------------------------------------------------------------------

// HP45 : ROMS                                                                  

int _ROM[8][256] =                                                                                  // 8 ROMs, each with 256 10-bit bytes which encode both operator and parameter
    { { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,                                             // *************************************************************
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,                                             // ***                                                       ***
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,                                             // ***  NOTE THAT THE ACTUAL ROM CODES ARE NOT INCLUDED      ***
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,                                             // ***  IN THIS SOURCE LISTING                               ***
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,                                             // ***                                                       ***
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,                                             // *************************************************************
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,                                             // *************************************************************
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,                                             // ***  IF YOU HAVE ADDED CORRECT ROM CODES HERE THEN ALSO   ***
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,                                             // ***  REMOVE THE WARNING ON THE MAIN SCREEN BEFORE         ***
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,                                             // ***  COMPILING. SEARCH FOR: DELETE ONCE ROM CODES ADDED   ***                    ***
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,                                             // *************************************************************
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    {   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    {   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    {   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    {   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    {   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    {   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    {   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 } };

// HP45 : LOCATION INFORMATION

int current_Rom = 0;                                                                                // which ROM are we in (0 - 7)
int current_Byte = 0;                                                                               // which byte in the ROM (0 - 255)
int last_Jump_Byte = 0;                                                                             // from which byte did we last jumpSub

// HP45 : GENERAL REGISTERS (called INTERNAL REGISTERS on display)                                                                        

int g_R[7][14];                                                                                     // 7 registers, each with 14 4-bit nibbles (8-bit int in simulator) numbered 13, 12, ..., 0

// HP45 : COMPONENTS OF GENERAL REGISTERS
                                                                                                    // the low and high nibbles for different components
int _nibbles[8][2] = { {0,0}, {3,12}, {0,2}, {0,13}, {0,0}, {3,13}, {2,2}, {13,13} };               // _nibbles[0] and _nibbles[4] are actually {_p, _p} and {_p, 0}
                                                                                                    
// HP45 : STATUS REGISTER                                                                           

bool _s[12] = {false, false, false, false, false, false, false, false, false, false, false, false}; // 12 single bits numbered 11, ..., 0 

// HP45 : DATA REGISTERS (called STORAGE REGISTERS on display)                                                       

int data_Reg[10][14];                                                                               // 10 registers (0 to 9), each 14-nibble, numbered 13, 12, ..., 0
int data_Address = 0;                                                                               // the data register to read/write - the n in data_Reg[n][m] - set from C[12], i.e. g_R[REG_C][12]

// HP45 : POINTER                                                               
                                                                                                    // pointer holds from 0 to 15 but only 0 to 13 actually point to nibbles
int _p= 0;                                                                                          // operations using _p as an index with _p > 13 are ignored
                     
// HP45 : FLAGS                                                                                     
                                                                                                    // flags which manage execution flow and the display
int _carry = 0;                                                                                     // set to 0 before each operation, except goto : goto executes if no carry, otherwise does not & resets to 0
bool last_True = true;                                                                              // set to true or false by if... operations; goto executes if true, otherwise does not & resets to true
bool display_Enabled = false;                                                                       // is the calculator display enabled?

// HP45 : KEYBOARD                                                                                  
                                                                                                    
int key_Code = 99;                                                                                  // other than shift, pressing a key makes execution go to the byte defined by that key's keycode
char key_Codes[39][2] = {                                                                           // shift sets a status bit which changes the ROM in which the subsequent keycode byte is branched to
        {'\\', 6},       {'l', 4},        {'^', 3},        {'f', 2},        {'\'', 0},              // [ 1/x ][ y^x ]   [ ln  ][ log ]   [ e^x ][10^x ]   [ FIX ][ SCI ]   [   shift    ] 
        {'w', 46},       {'p',44},        {'s', 43},       {'c', 42},       {'t', 40},              // [ x^2 ][sqrtx]   [ ->P ][ ->R ]   [ SIN ][aSIN ]   [ COS ][aCOS ]   [ TAN ][aTAN ]
        {'a', 14},       {'r', 12},       {'[', 11},       {']', 10},       {'y', 8},               // [x<->y][ n!  ]   [ R\/ ][xbr,s]   [ STO ][>D.MS]   [ RCL ][D.MS>]   [  %  ][delt%]                                                               
    {10, 62},{13, 62},                    {'z', 59},       {'e', 58},       {';', 56},              // [ENTER (13 for Windows)][ DEG ]   [ CHS ][ RAD ]   [ EEX ][ GRD ]   [ CLx ][CLEAR]
        {'-', 54},        {'7', 52},               {'8', 51},               {'9', 50},              // [   -   ]       [   7   ][ cm/in ]      [   8   ][ kg/lb ]      [   9   ][ltr/gal]
    {'+', 22},{'=', 22},  {'4', 20},               {'5', 19},               {'6', 18},              // [   +   ]       [       4        ]      [       5        ]      [       6        ]
    {'*', 30},{'x', 30},  {'1', 28},               {'2', 27},               {'3', 26},              // [   x   ]       [       1        ]      [       2        ]      [       3        ]       
        {'/', 38},        {'0', 36},               {'.', 35},               {'o', 34},              // [   ÷   ]       [   0   ][ LASTx ]      [   .   ][  pi   ]      [sigma+ ][sigma- ]      
                                                                            {'?', 60} };            // '?' is used in conjunction with RCL (']') to trigger the timer, which usually requires simultaneous keypresses


// +----------------------------------------------------------------------------
// |                GLOBAL VARIABLES : INTERPRETER
// +----------------------------------------------------------------------------

                    int operation_List[11] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};                                         // holds the operation codes for recent key presses
                    unsigned int rom_Op_Count[8] = {0, 0, 0, 0, 0, 0, 0, 0};                                            // total number of operations performed in a ROM
                    char rom_Op_Position[8][32];                                                                        // number of ops performed in a rom, separated into 8-byte location blocks
                    bool timer_Mode = false;                                                                            // are we in timer mode?
                    bool minimal_Mode = false;                                                                          // are we in minimal display mode?
                    int operation_Types[88] = { 2,   3,   4,   6,   8,   10,  11,  12,                                  // the operation types stored in operation_List ... 
                                                14,  18,  19,  20,  22,  26,  27,  28,
                                                30,  34,  35,  36,  38,  40,  42,  43,  
                                                44,  46,  50,  51,  52,  54,  56,  58,
                                                59,  60,  62,  102, 103, 104, 106, 108,
                                                110, 111, 112, 114, 134, 135, 136, 140,  
                                                142, 143, 144, 146, 150, 151, 152, 156,  
                                                158, 159, 162, 318, 319, 320, 326, 327, 
                                                328, 335, 350, 351, 352, 356, 358, 359, 
                                                362, 418, 419, 420, 426, 427, 428, 435, 
                                                450, 451, 452, 456, 458, 459, 462, 999 };
                    char operation_Text[87][13] = { "   [ FIX   ]", "   [ e^x   ]", "   [ ln    ]", "   [ 1/x   ]",     // ... and their corresponding operation text
                                                    "   [ %     ]", "   [ RCL   ]", "   [ STO   ]", "   [ Rdown ]",     // except for the last operation_Types entry which means an non-existent operation was attempted
                                                    "   [ x<->y ]", "   [ 6     ]", "   [ 5     ]", "   [ 4     ]", 
                                                    "   [ +     ]", "   [ 3     ]", "   [ 2     ]", "   [ 1     ]", 
                                                    "   [ x     ]", "   [ sigma+]", "   [ .     ]", "   [ 0     ]", 
                                                    "   [ /     ]", "   [ TAN   ]", "   [ COS   ]", "   [ SIN   ]", 
                                                    "   [ ->P   ]", "   [ x^2   ]", "   [ 9     ]", "   [ 8     ]", 
                                                    "   [ 7     ]", "   [ -     ]", "   [ CLx   ]", "   [ EEX   ]", 
                                                    "   [ CHS   ]", "[TIMER MODE]", "   [ ENTER ]", "   [ SCI   ]", 
                                                    "   [ 10^x  ]", "   [ log   ]", "   [ y^x   ]", "   [ delta%]", 
                                                    "   [ D.MS> ]", "   [ >D.MS ]", "   [ xbr,s ]", "   [ n!    ]", 
                                                    "   [ sigma-]", "   [ pi    ]", "   [ LASTx ]", "   [ aTAN  ]", 
                                                    "   [ aCOS  ]", "   [ aSIN  ]", "   [ ->R   ]", "   [ sqrtx ]", 
                                                    "   [ ltr/gl]", "   [ kg/lb ]", "   [ cm/in ]", "   [ CLEAR ]", 
                                                    "   [ GRD   ]", "   [ RAD   ]", "   [ DEG   ]", "[TMR  rcl 6]", 
                                                    "[TMR  rcl 5]", "[TMR  rcl 4]", "[TMR  rcl 3]", "[TMR  rcl 2]", 
                                                    "[TMR  rcl 1]", "[EXIT TIMER]", "[TMR  rcl 9]", "[TMR  rcl 8]", 
                                                    "[TMR  rcl 7]", "[TMR  reset]", "[TMR  100th]", "[TMR  start]",
                                                    "[EXIT TIMER]", "[TMR  sto 6]", "[TMR  sto 5]", "[TMR  sto 4]", 
                                                    "[TMR  sto 3]", "[TMR  sto 2]", "[TMR  sto 1]", "[EXIT TIMER]", 
                                                    "[TMR  sto 9]", "[TMR  sto 8]", "[TMR  sto 7]", "[TMR  reset]", 
                                                    "[TMR  100th]", "[TMR  stop ]", "[EXIT TIMER]" };


// +----------------------------------------------------------------------------
// |    HP45 : POINTER OPERATIONS
// +----------------------------------------------------------------------------

// UPDATE HIGH AND LOW NIBBLES FOR UPDATED POINTER

                    void updateNibbles()                                                            // not strictly an HP-45 operation but reflects way in which simulator determines components
                    {
                        _nibbles[C_P][0] = _p; _nibbles[C_P][1] = _p;
                        _nibbles[C_WP][0] = 0; _nibbles[C_WP][1] = _p;
                        return;
                    }

// SET POINTER VALUE : implements VALUE -> P

void setP(int point)                                                            
{
    _p = point;
    updateNibbles();
    return;
}

// INCREMENT POINTER : implements INCREMENT P

void incP()                                                                     
{
    _p = (_p + 1) & 15;                                                                             // pointer is set to 0 on incrementing 15
    updateNibbles();
    return;
}

// DECREMENT POINTER : implements DECREMENT P

void decP()                                                                     
{
    _p = (_p - 1) & 15;                                                                             // pointer is set to 15 on decrementing 0
    updateNibbles();
    return;
}

// COMPARE POINTER TO VALUE & SET LAST_TRUE ACCORDINGLY : implements IF P != VALUE

void ifPNotValue(int value)                                                     
{
    last_True = (_p != value);
    return;
}


// +----------------------------------------------------------------------------
// |    HP45 : REGISTER OPERATIONS
// +----------------------------------------------------------------------------

                    // CLEAR ALL REGISTERS

                    void clearRegs()                                                                                    // not strictly an HP-45 operation but used on startup to reset all registers
                    {
                        for (int i = 0; i < 7; i++)
                        {
                            for (int j = 0; j < 14; j++)
                            {
                                g_R[i][j] = 0;
                            }
                        }
                        return;
                    }

// CLEAR A COMPONENT OF A REGISTER : implements CLEAR A , CLEAR B , CLEAR C

void clearReg(int reg, int comp)                            
{
    for (int nibble = _nibbles[comp][0]; nibble <= _nibbles[comp][1]; nibble++)
    {
        g_R[reg][nibble] = 0;
    }
    return;
}

// COPY COMPONENT OF REGISTER 1 TO REGISTER 2 : implements A -> B , B -> C , C -> A, M -> C

void copyReg(int reg1, int reg2, int comp)                  
{
    for (int nibble = _nibbles[comp][0]; nibble <= _nibbles[comp][1]; nibble++)
    {
        g_R[reg2][nibble] = g_R[reg1][nibble];
    }
    return;
}

// EXCHANGE COMPONENT OF REGISTER 1 AND REGISTER 2 : implements EXCHANGE A B , EXCHANGE A C, EXCHANGE B C, EXCHANGE C M

void exchangeRegs(int reg1, int reg2, int comp)             
{
    int tempNibble;
    for (int nibble = _nibbles[comp][0]; nibble <= _nibbles[comp][1]; nibble++)
    {
        tempNibble = g_R[reg1][nibble];
        g_R[reg1][nibble] = g_R[reg2][nibble];
        g_R[reg2][nibble] = tempNibble;
    }
    return;
}

// ADD COMPONENT OF REGISTER 1 TO REGISTER 2 AND STORE RESULT IN REGISTER 3 : implements A + B -> A , A + C -> A , A + C -> C , C + C -> C

void addRegs(int reg1, int reg2, int reg3, int comp)        
{
    int tempNibble;
    for (int nibble = _nibbles[comp][0]; nibble <= _nibbles[comp][1]; nibble++)
    {
        tempNibble = g_R[reg1][nibble] + g_R[reg2][nibble] + _carry;                                // carry will be 0 when the function is called
        if (tempNibble >= 10)
        {
            tempNibble = tempNibble - 10;
            _carry = 1;
        }
        else
        {
            _carry = 0;
        }
        g_R[reg3][nibble] = tempNibble;
    }
    return;
}

// SUBTRACT COMPONENT OF REGISTER 2 FROM REGISTER 1 AND STORE RESULT IN REGISTER 3 : implements A - B -> A , A - C -> A , A - C -> C

void subRegs(int reg1, int reg2, int reg3, int comp)        
{
    int tempNibble;
    for (int nibble = _nibbles[comp][0]; nibble <= _nibbles[comp][1]; nibble++)
    {
        tempNibble = g_R[reg1][nibble] - g_R[reg2][nibble] - _carry;                                // carry will be 0 when the function is called
        if (tempNibble < 0)
        {
            tempNibble = tempNibble + 10;
            _carry = 1;
        }
        else
        {
            _carry = 0;
        }
        g_R[reg3][nibble] = tempNibble;
    }
    return;
}

// INCREMENT COMPONENT OF A REGISTER : implements INCREMENT A, INCREMENT C

void incReg(int reg, int comp)                              
{
    _carry = 1;                                                                                     // setting carry to 1 ensures we run the loop at least once ...
    int tempNibble = 0;
    int nibble = _nibbles[comp][0];
    while (_carry == 1 && nibble <= _nibbles[comp][1])
    {
        tempNibble = g_R[reg][nibble] + _carry;                                                     // ... and we use carry to perform the increment
        if (tempNibble == 10)
        {
            tempNibble = 0;                                                                         // carry remains 1 if we've added 1 to 9 ...
        }
        else
        {
            _carry = 0;                                                                             // ... otherwise carry is 0 and we're done
        }
        g_R[reg][nibble] = tempNibble;
        nibble++;
    }
    return;             
}

// DECREMENT COMPONENT OF REG : implements DECREMENT A, DECREMENT C

void decReg(int reg, int comp)                              
{
    _carry = 1;                                                                                     // setting carry to 1 ensures we run the loop at least once ...
    int tempNibble = 0;
    int nibble = _nibbles[comp][0];
    while (_carry == 1 && nibble <= _nibbles[comp][1])
    {
        tempNibble = g_R[reg][nibble] - _carry;                                                     // ... and we use carry to perform the decrement
        if (tempNibble == -1)
        {
            tempNibble = 9;                                                                         // carry remains 1 if we've subtracted 1 from 0 ...
        }
        else
        {
            _carry = 0;                                                                             // ... otherwise carry is 0 and we're done
        }
        g_R[reg][nibble] = tempNibble;
        nibble++;
    }
    return;
}

// NEGATE COMPONENT OF REGISTER (TEN'S COMPLEMENT) : implements 0 - C -> C

void negReg(int reg, int comp)                              
{
    int tempNibble;
    for (int nibble = _nibbles[comp][0]; nibble <= _nibbles[comp][1]; nibble++)
    {
        tempNibble = 0 - g_R[reg][nibble] - _carry;                                                 // carry will be 0 when the function is called
        if (tempNibble < 0)
        {
            tempNibble = tempNibble + 10;
            _carry = 1;
        }
        else
        {
            _carry = 0;
        }
        g_R[reg][nibble] = tempNibble;
    }
    return;
}

// NEGATE AND DECREMENT COMPONENT OF REGISTER (NINE'S COMPLEMENT) : implements 0 - C - 1 -> C

void negDecReg(int reg, int comp)                           
{
    for (int nibble = _nibbles[comp][0]; nibble <= _nibbles[comp][1]; nibble++)
    {
        g_R[reg][nibble] = 9 - g_R[reg][nibble];                                                    // nibble holds 0 to 9 so no need to worry about carry
    }
    return;
}

// SHIFT A SPECIFIC COMPONENT OF A REGISTER TO THE RIGHT : implements RIGHTSHIFT A, RIGHTSHIFT B, RIGHTSHIFT C

void rShiftReg(int reg, int comp)                           
{
    int nibble;
    for (nibble = _nibbles[comp][0]; nibble < _nibbles[comp][1]; nibble++)                          // the lowest nibble of the component (farthest right) is discarded
    {                                                                          
        g_R[reg][nibble] = g_R[reg][nibble + 1];
    }
    g_R[reg][nibble] = 0;                                                                           // the highest nibble of the component (farthest left) is set to 0
    return;
}                                                                           

// SHIFT COMPONENT OF REGISTER TO THE LEFT : implements LEFTSHIFT A

void lShiftReg(int reg, int comp)                           
{
    int nibble;
    for (nibble = _nibbles[comp][1]; nibble > _nibbles[comp][0]; nibble--)                          // the highest nibble of the component (farthest left) is discarded
    {                                                                       
        g_R[reg][nibble] = g_R[reg][nibble - 1];
    }
    g_R[reg][nibble] = 0;                                                                           // the lowest nibble of the component (farthest right) is set to 0
    return;
}                                                                     

// SET LAST_TRUE TO TRUE IF COMPONENT OF REGISTER = 0, ELSE FALSE : implements IF B = 0, IF C = 0

void ifRegZero(int reg, int comp)                           
{
    last_True = false;
    for (int nibble = _nibbles[comp][0]; nibble <= _nibbles[comp][1]; nibble++)
    {
        if (g_R[reg][nibble] > 0)
        {
            return;
        }
    }
    last_True = true;
    return;
}

// COMPARE COMPONENT OF REGISTER 1 TO REGISTER 2 AND SET LAST_TRUE TO TRUE IF 1 >= 2, ELSE FALSE : implements IF A >= B, IF A >= C

void ifRegReg(int reg1, int reg2, int comp)                 
{
    last_True = false;
    for (int nibble = _nibbles[comp][1]; nibble >= _nibbles[comp][0]; nibble--)
    {
        if (g_R[reg1][nibble] < g_R[reg2][nibble])
        {
            return;                                                                                 // reg2 has non-zero digit to left of reg1 OR first different digit is greater in reg2
        }
        else if (g_R[reg2][nibble] < g_R[reg1][nibble])
        {
            last_True = true;                                                                       // reg1 has non-zero digit to left of reg2 OR first different digit is greater in reg1
            return;             
        }
    }
    last_True = true;                                                                               // reg1 = reg2
    return;
}

// SET LAST_TRUE TO TRUE IF A SPECIFIC COMPONENT OF A REGISTER >= 1 (I.E. > 0), ELSE FALSE : implements IF A >= 1, IF C >= 1

void ifRegOne(int reg, int comp)                            
{
    last_True = false;
    for (int nibble = _nibbles[comp][0]; nibble <= _nibbles[comp][1]; nibble++)
    {
        if (g_R[reg][nibble] > 0)
        {
            last_True = true;
            return;
        }
    }
    return;
}

// PUSH REGISTER C ONTO THE STACK (E->F, D->E, C->D), ALWAYS WHOLE WORD AS COMPONENT : implements C -> STACK

void pushC()                                                
{
    for (int nibble = _nibbles[C_W][0]; nibble <= _nibbles[C_W][1]; nibble++)
    {
        g_R[REG_F][nibble] = g_R[REG_E][nibble];
        g_R[REG_E][nibble] = g_R[REG_D][nibble];
        g_R[REG_D][nibble] = g_R[REG_C][nibble];
    }
    return;
}

// POP THE STACK INTO REGISTER A (D->A, E->D, F->E), ALWAYS WHOLE WORD AS COMPONENT : implements STACK -> A

void popA()                                                 
{
    for (int nibble = _nibbles[C_W][0]; nibble <= _nibbles[C_W][1]; nibble++)
    {
        g_R[REG_A][nibble] = g_R[REG_D][nibble];
        g_R[REG_D][nibble] = g_R[REG_E][nibble];
        g_R[REG_E][nibble] = g_R[REG_F][nibble];
    }
    return;
}

// ROTATE DOWN (D->C, E->D, F->E AND ORIGINAL C->F), ALWAYS WHOLE WORD AS COMPONENT : implements ROTATEDOWN

void rotateDown()                                           
{
    int reg_CNibbleValue;
    for (int nibble = _nibbles[C_W][0]; nibble <= _nibbles[C_W][1]; nibble++)
    {
        reg_CNibbleValue = g_R[REG_C][nibble];
        g_R[REG_C][nibble] = g_R[REG_D][nibble];
        g_R[REG_D][nibble] = g_R[REG_E][nibble];
        g_R[REG_E][nibble] = g_R[REG_F][nibble];
        g_R[REG_F][nibble] = reg_CNibbleValue;
    }
    return;
}

// LOAD A CONSTANT VALUE TO REGISTER C NIBBLE AT POINTER P AND DECREMENT POINTER P : implements LOADCONSTANT

void loadConstant(int value)                                
{
    if (_p < 14) g_R[REG_C][_p] = value;                                                            // if P is 14 or 15 then just decrement without storing anything
    decP();
    return;
}


// +----------------------------------------------------------------------------
// | HP45 : STATUS OPERATIONS
// +----------------------------------------------------------------------------

// CLEAR ALL BITS OF THE STATUS REGISTER : implements CLEAR ALL STATUSBITS

void clearAllStatus()                                       
{
    for (int i = 0; i < 12; i++)
    {
        _s[i] = 0;
    }
    return;
}

// SET STATUS BIT TO FALSE : implements CLEAR STATUSBIT

void clearStatus(int bit)                                   
{
    _s[bit] = false;
    return;
}

// SET STATUS BIT TO TRUE : implements SET STATUSBIT

void setStatus(int bit)                                     
{
    _s[bit] = true;
    return;
}

// SET LAST_TRUE TO TRUE IF STATUS BIT IS FALSE, ELSE SET LAST_TRUE TO FALSE : implements IF STATUSBIT !=1

void ifSBitZero(int bit)                                    
{
    last_True = !_s[bit];
    return; 
}


// +----------------------------------------------------------------------------
// | HP45 DATA : OPERATIONS
// +----------------------------------------------------------------------------

                    // CLEAR ALL DATA REGISTERS

                    void clearDataRegs()                                                                                // not strictly an HP-45 operation but used on startup to reset all registers
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            for (int j = 0; j < 14; j++)
                            {
                                data_Reg[i][j] = 0;
                            }
                        }
                        return;
                    }

// USE REGISTER C NIBBLE 12 TO SET THE DATA ADDRESS (0 TO 9) FOR READ/WRITE : implements C -> DATAADDRESS

void setDataAddress()                                       
{
    data_Address = g_R[REG_C][12];
    return;
}

// READ DATA REGISTER AT CURRENT DATA ADDRESS INTO REGISTER C, ALWAYS WHOLE WORD AS COMPONENT : implements DATA -> C

void dataToC()                                              
{
    for (int i = 0; i < 14; i++)
    {
        g_R[REG_C][i] = data_Reg[data_Address][i];
    }
    return;
}

// WRITE REGISTER C INTO DATA REGISTER AT CURRENT DATA ADDRESS, ALWAYS WHOLE WORD AS COMPONENT : implements C -> DATA

void cToData()                                              
{
    for (int i = 0; i < 14; i++)
    {
        data_Reg[data_Address][i] = g_R[REG_C][i];
    }
    return;
}


// +----------------------------------------------------------------------------
// | HP45 : FLOW OPERATIONS
// +----------------------------------------------------------------------------

// SELECT ROM : implements SELECTROM

void selectRom(int romNumber) 
{                                                                                                   // when byte n contains an operation to select ROM r the next byte executed is byte n+1 of ROM r
    current_Rom = romNumber;                                                                        // this function sets r; the incrementing of n occurs in the main loop
    return;                                                                                            
}

// SET NEW CURRENT_BYTE LOCATION (AFTER CHECKING CARRY AND LAST_TRUE) : implements GOTO

bool goTo(int location)                                     
{
    if (_carry == 0 && last_True)                                                                   // carry is not set to 0 before a goto operation (but is set to 0 after the operation)
    {                                                                           
        current_Byte = location;
        last_True = true;                                                                           // last_True is reset to true in this function and will remain true until set ...
        return true;                                                                                // ... false by a subsequent condition check
    }
    last_True = true;                                                                               // last_True is set true whether or not the goto itself is performed
    return false;
}

// SET NEW CURRENT_BYTE LOCATION AND STORE JUMP-FROM LOCATION : implements JUMPSUB

bool jumpSub(int location)                                  
{
    last_Jump_Byte = current_Byte;
    current_Byte = location;
    return true;
}

// GO TO LOCATION OF CURRENT KEYCODE IN CURRENT ROM : implements KEYS -> ROMADDRESS

bool keyGoTo()                                              
{
    current_Byte = key_Code;
    return true;
}

// SET NEW CURRENT_BYTE LOCATION TO LOCATION AFTER LAST JUMPSUB INSTRUCTION : implements RETURN

void ret()                                                 
{
    current_Byte = last_Jump_Byte + 1;
    return;
}


// +----------------------------------------------------------------------------
// | HP45 : OTHER OPERATIONS
// +----------------------------------------------------------------------------

// NO OPERATION (DO NOTHING) : implements NOP

void nOp()                                                  
{
    return;
}

// TURN OFF THE DISPLAY : implements DISPLAYOFF

void displayOff()                                           
{
    display_Enabled = false;
    return;
}

// TOGGLE THE DISPLAY : implements DISPLAYTOGGLE

void displayToggle()                                        
{
    display_Enabled = !(display_Enabled);
    return;
}


// +----------------------------------------------------------------------------
// |                NON-HP45 FUNCTIONS : INTERPRETER/EMULATOR FUNCTIONS
// +----------------------------------------------------------------------------

                    // SET UP THE TOP STATIC PART OF THE SCREEN

                    void printScreenTopBackground() 
                    {
                        printf("%c[2J", ESC_CHR);
                        printf("%c[%d;%dH", ESC_CHR, 0, 0);
                        printf("                                                                                \n");
                        printf("                                [     ] [     ] [     ] [                    ]  \n");
                        printf("                                                                                \n");
                        printf("%c[%d;%dH", ESC_CHR, 2, 30);
                        return;
                    }

                    // SET UP THE LOWER STATIC PARTS OF THE SCREEN

                    void printScreenBackground(int display) 
                    {
                        printf("%c[%d;%dH", ESC_CHR, 4, 0);
                        if (display == 0 || display == 32 || display == 64 || display == 96)                            // nothing shown on screen (bits 5 & 6 concern formatting, not display)
                        {
                            printf("________________________________________________________________________________\n");
                        }
                        else
                        {
                            printf("                                                                                \n");
                        }
                        printf("                                                                                \n");
                        printf("                                                                                \n");
                        printf("                                                                                \n");
                        printf("                                                                                \n");
                        printf("                                                                                \n");
                        printf("                                                                                \n");
                        printf("                                                                                \n");
                        printf("                                                                                \n");
                        printf("                                                                                \n");
                        printf("                                                                                \n");
                        printf("                                                                                \n");
                        printf("                                                                                \n");
                        printf("                                                                                \n");
                        printf("                                                                                \n");
                        printf("                                                                                \n");
                        if (display == 0 || display == 32 || display == 64 || display == 96)                            // nothing shown on screen (bits 5 & 6 concerns formatting, not display)
                        {
                            printf("              select 'display options' to show further information              \n");
                        }
                        else
                        {
                            printf("                                                                                \n");
                        }   
                        printf("If you're seeing this message and no calculator activity it's probably because  \n");   // DELETE ONCE ROM CODES ADDED
                        printf("the ROM codes have not been added to the code before compiling.                 \n");   // DELETE ONCE ROM CODES ADDED
                    //    printf("                                                                                \n"); // UNREMARK ONCE ROM CODES ADDED
                    //    printf("                                                                                \n"); // UNREMARK ONCE ROM CODES ADDED
                        printf("________________________________________________________________________________\n");	
                        printf(" HP45TERM         [m]inimal mode      [d]isplay options      [h]elp      [Q]uit ");
                        printf("%c[%d;%dH", ESC_CHR, 2, 30);
                        return;
                    }

                    // WAVE GOODBYE

                    void printGoodbye() 
                    {
                        //printf("%c[2J", ESC_CHR);
                        //printf("%c[%d;%dH", ESC_CHR, 0, 0);
                        for (int i = 1; i < 30 ; i++)                                                                   // more than needed, to be sure to clear if slightly more than 24 rows
                        {
                            printf("                                                                                \n");
                        }
                        printf("________________________________________________________________________________\n");	
                        printf(" HP45TERM / GOODBYE                                                             \n\n");
                        return;
                    }

                    // PRINT THE CALCULATOR DISPLAY (AS SEEN ON THE REAL CALCULATOR)

                    void printDisplay()                                                    
                    {   
                        printf("%c[%d;%dH", ESC_CHR, 2, 7);
                        if (display_Enabled)                                        
                        {
                            for (int i = 13; i >= 0; i--)                                                               // register A holds the raw data to be shown on the display
                            {                                                                                           // register B translates register A to the signs, digits, spaces and decimal points shown on the display
                                if (g_R[REG_B][i] <= 7)                                                                 // if B nibble <= 7 then the digit in the corresponding A nibble is lit otherwise it is unlit
                                {
                                    if (i == 2 || i == 13)                                                              // nibbles 2 and 13 hold the signs of exponent and exponent, respectively
                                    {
                                        (g_R[REG_A][i] >= 8) ? printf("-") : printf(" ");                               // if A nibble >= 8 then the negative sign is lit, otherwise it is unlit
                                    }
                                    else
                                    {
                                        printf("%d", g_R[REG_A][i]);
                                    }
                                    if (g_R[REG_B][i] == 2)                                                             // if B nibble = 2 then the display digit to the right of that nibble is a decimal point
                                    {
                                        printf(".");
                                    }
                                }
                                else
                                {
                                    printf(" ");
                                }
                            }
                            printf("   ");                                                                              // we add a few spaces at the end of the display to cover any previous "IMPROPER OPERATION" message
                        }
                        else
                        {
                            if (_s[5])                                                                                  // if status flag 5 is set then an improper operation has occurred...
                            {
                                printf("IMPROPER OPERATION");                                                           // ... and the real display would be flashing : we simply print a message where the display is on screen
                            }
                            else
                            {
                                printf("                  ");                                                           // if the display is off then we fill it with enough spaces to cover any value it may have previously held
                            }
                        }    
                        printf("%c[%d;%dH", ESC_CHR, 2, 30);
                        return;
                    }

                    // TAKE A STANDARD REGISTER AND CALCULATE A SCI9 REPRESENTATION OF IT AND PRINT IT
                                                                                                                         
                    void printDecodeReg(int reg, bool regType)                                                          // allows us to show the stack and data registers in SCI9 format instead of as raw internal data
                    {
                        if (regType)                                                                                    // regType = true for general registers (A...M)
                        {
                            (g_R[reg][13] == 9) ? printf("-") : printf(" ");
                            printf("%d.",g_R[reg][12]);
                            for (int nibble = 11; nibble >= 3; nibble--)
                            {
                                printf("%d", g_R[reg][nibble]);
                            }
                            if (g_R[reg][2] != 9)                                                                       // in timer mode, nibble 2 can be 2 we so can't just check against 0 here  
                            {
                                printf(" %d%d", g_R[reg][1], g_R[reg][0]);
                            }
                            else
                            {
                                printf("-%02d", 100 - ((g_R[reg][1] * 10) + g_R[reg][0]));                              // a negative exponent (nibble 2 is 9) needs to be subtracted from 100 to get the correct value
                            }
                        }
                        else                                                                                            // regType = false for data registers (R0...R9)
                        {
                            (data_Reg[reg][13] == 9) ? printf("-") : printf(" ");
                            printf("%d.",data_Reg[reg][12]);
                            for (int nibble = 11; nibble >= 3; nibble--)
                            {
                                printf("%d", data_Reg[reg][nibble]);
                            }
                            if (data_Reg[reg][2] != 9)                                                                  // in timer mode, nibble 2 can be 2 we so can't just check against 0 here   
                            {
                                printf(" %d%d", data_Reg[reg][1], data_Reg[reg][0]);
                            }
                            else
                            {
                                printf("-%02d", 100 - ((data_Reg[reg][1] * 10) + data_Reg[reg][0]));                    // a negative exponent (nibble 2 is 9) needs to be subtracted from 100 to get the correct value
                            }
                        }
                        return;
                    }

                    // UPDATE FIX and SCI and SHIFT DISPLAY ON SCREEN DEPENDING ON CONTENTS OF M REGISTER AND STATUS REGISTER

                    void printFixSciShift()                                                                             // (additional chars here clean up any extra characters echoed from incorrect keypresses)
                    {
                        printf("%c[%d;%dH", ESC_CHR, 2, 31);                                                            // print FIX settings depending on M register ...
                        (g_R[REG_M][1] == 0) ? printf("  [FIX %d", g_R[REG_M][2]) : printf("  [     ");                   
                        printf("%c[%d;%dH", ESC_CHR, 2, 42);                                                            // print SCI settings depending on M register ...
                        (g_R[REG_M][1] == 1) ? printf("SCI %d", g_R[REG_M][2]) : printf("     ");
                        printf("%c[%d;%dH", ESC_CHR, 2, 50);                                                            // print shift indicator depending on status bit 10
                        (_s[10] == 1) ? printf("shift") : printf("     ");
                        return;
                    }

                    // UPDATE VALUES ON SCREEN (OTHER THAN CALCULATOR DISPLAY) DEPENDING ON WHAT WE'RE DISPLAYING

                    void printValues(int display)                                                                       // the first 6 bits of display (from right) govern what we see on screen
                    {
                        int operationPrintValue = 0;                                                                    // used for when displaying the recent operation list
                        bool displaySci = false;                                                                        // flag for type of display of data registers (raw data or SCI9)
                        printFixSciShift();
                        if (display & 32)                                                                               // bit 5 of display is set: we will show data registers (REG), below, in sci9 format
                        {
                            displaySci = true;
                        }
                        if (display & 16)                                                                               // bit 4 of display is set: show the stack (STK) (always in SCI9 format)
                        {                                                                           
                            printf("%c[%d;%dH", ESC_CHR, 5, 14);
                            printDecodeReg(REG_F, true);                                                                // general register F is the T stack item
                            printf("%c[%d;%dH", ESC_CHR, 6, 14);
                            printDecodeReg(REG_E, true);                                                                // general register E is the Z stack item
                            printf("%c[%d;%dH", ESC_CHR, 7, 14);
                            printDecodeReg(REG_D, true);                                                                // general register D is the D stack item
                            printf("%c[%d;%dH", ESC_CHR, 8, 14);
                            printDecodeReg(REG_C, true);                                                                // general register C is the C stack item
                            printf("%c[%d;%dH", ESC_CHR, 10, 14);
                            printDecodeReg(0, false);                                                                   // data register R0 is the LASTx stack item

                        }                                                                           
                        if (display & 8)                                                                                // bit 3 of display is set: show the general registers, status bits & R0 (INT)
                        {
                            for(int i = 0; i < 7; i++)                                                                  // loop through the registers A-F, M, and show the contents
                            {                                                                        
                                printf("%c[%d;%dH", ESC_CHR, 5+i, 67);
                                for(int j = 13; j >= 0; j--)
                                {
                                    printf("%d", g_R[i][j]);
                                }
                            }
                            printf("%c[%d;%dH", ESC_CHR, 12, 67);                                                       // show R0
                            for(int j = 13; j >= 0; j--)
                            {
                                printf("%d", data_Reg[0][j]);
                            }
                            printf("%c[%d;%dH", ESC_CHR, 13, 69);                                                       // show S : if a bit is set show the nibble number of the bit (in hex), else "_"
                            (_s[11]) ? printf("B") : printf("_");
                            (_s[10]) ? printf("A") : printf("_");
                            for(int i = 9; i >= 0; i--)
                            {
                                (_s[i]) ? printf("%d", i) : printf("_");
                            }
                        }
                        if (display & 4)                                                                                // bit 2 of display is set: show the data registers (REG)
                        {
                            for(int i = 1; i <= 9; i++)                                                                 // loop through the data registers R1-R9 ...
                            {
                                if (displaySci)                                                                         // ... and either print a SCI9 formatted version of the contents ...
                                {
                                    printf("%c[%d;%dH", ESC_CHR, 4+i, 40); 
                                    printDecodeReg(i, false); 
                                }
                                else                                                                                    // ... or the raw contents
                                {
                                    printf("%c[%d;%dH", ESC_CHR, 4+i, 41);
                                    for(int j = 13; j >= 0; j--)
                                    {
                                        printf("%d", data_Reg[i][j]);
                                    }
                                }
                            }
                        }
                        if (display & 2)                                                                                // bit 1 of display is set: show heatmap of rom operations since last keypress (RHM)...
                        {
                            for (int i = 0; i < 8; i++)
                            {
                                if (rom_Op_Count[i] != 0)
                                {
                                    printf("%c[%d;%dHROM%d %4d [                                ]", ESC_CHR, 15+i, 37, i, rom_Op_Count[i]);
                                    for (int j = 0; j < 32; j++)
                                    {
                                        printf("%c[%d;%dH", ESC_CHR, 15+i, 48+j);
                                        switch (rom_Op_Position[i][j])                                                  // how many times was the operation at this rom/byte called
                                        {
                                            case 0:
                                                printf(" ");
                                            break;
                                            case 10:
                                                printf("X");
                                            break;
                                            default:
                                                printf("%d", rom_Op_Position[i][j]);
                                            break;
                                        }
                                    }
                                }
                                else
                                {
                                    printf("%c[%d;%dH....      [                                ]", ESC_CHR, 15+i, 37);
                                }
                            }
                            
                        }
                        if (display & 1)                                                                                // bit 0 of display is set: show list of recent operations (KEY)
                        {
                            for (int i = 0; i <= 10; i++)                                                               // loop through the items in the operation list (newest to oldest)
                            {
                                printf("%c[%d;%dH", ESC_CHR, 12+i,6);
                                operationPrintValue = operation_List[i];
                                if (operationPrintValue != 0)                                                           // if the list item isn't blank ...
                                {
                                    if (operationPrintValue > 300)                                                      // if the list item > 300 then it's a kepypress during timer mode so ...
                                    {
                                        operationPrintValue = operationPrintValue - 300;                                // ... subtract 300 to get the actual keypress
                                    }
                                    if (operationPrintValue > 100)                                                      // if the list item > 100 then it's a keypress which followed a shift keypress ...
                                    {
                                        printf("[%02d][shft] ", operationPrintValue - 100);                             // ... so show the shift notification and subtract 100 to get the actual keypress
                                    }
                                    else
                                    {
                                        printf("[%02d]       ", operationPrintValue);                                   // otherwise just show the actual keypress as stored in the list item ...
                                    }
                                    for (int opLoop = 0; opLoop <= 88; opLoop++)                                        // ... and look up the decode of that keypress
                                    {
                                        if (operation_Types[opLoop] == operation_List[i])
                                        {
                                            for (int charLoop = 0; charLoop <= 11; charLoop++)                          // last character of each description omitted as just EOL marker
                                            {
                                                printf("%c", operation_Text[opLoop][charLoop]);
                                            }
                                            break;
                                        }
                                        else if (operation_Types[opLoop] == 999)                                        // we reached the end of the list without finding the operation decode ...
                                        {                                                                               // ... and that means either we're in timer mode and have pressed a key which 
                                            operation_List[i] > 300 ? printf("[TMR unused]") : printf("[key unused]");  // ... doesn't do anything in timer mode or we've pressed shift and a key with...
                                        }                                                                               // ... no shifted function
                                    }
                                }
                            }

                        }
                        printf("%c[%d;%dH", ESC_CHR, 2, 30);
                        return;
                    }

                    // UPDATE THE STATIC SCREEN TEXT WHEN DIFFERENT DISPLAY OPTIONS ARE CHOSEN OR AFTER SHOWING THE HELP SCREEN

                    void manageScreenBackground(int display)
                    {
                        if (display == 0 || display == 32 || display == 64 || display == 96)                            // nothing shown on screen (bits 5 & 6 concern formatting, not display)
                        {
                            return;
                        }
                        if (display & 16)                                                                               // bit 4 of display is set: show the stack (STK) labels ...
                        {
                            printf("%c[%d;%dH[STK]_______________________", ESC_CHR, 4, 1);
                            printf("%c[%d;%dHT", ESC_CHR, 5, 11);
                            printf("%c[%d;%dHZ", ESC_CHR, 6, 11);
                            printf("%c[%d;%dHY", ESC_CHR, 7, 11);
                            printf("%c[%d;%dHX", ESC_CHR, 8, 11);
                            printf("%c[%d;%dHlast X", ESC_CHR, 10, 6);
                        }
                        if (display & 8)                                                                                // bit 3 of display is set: show the general register, status bit & R0 (INT) labels ...
                        {
                            printf("%c[%d;%dH[INT]__________________", ESC_CHR, 4, 58);
                            printf("%c[%d;%dH|    A", ESC_CHR, 5, 58);
                            printf("%c[%d;%dH|    B", ESC_CHR, 6, 58);
                            printf("%c[%d;%dH|    C", ESC_CHR, 7, 58);
                            printf("%c[%d;%dH|    D", ESC_CHR, 8, 58);
                            printf("%c[%d;%dH|    E", ESC_CHR, 9, 58);
                            printf("%c[%d;%dH|    F", ESC_CHR, 10, 58);
                            printf("%c[%d;%dH|    M", ESC_CHR, 11, 58);
                            printf("%c[%d;%dH|    R0", ESC_CHR, 12, 58);
                            printf("%c[%d;%dH|    S", ESC_CHR, 13, 58);
                        }
                        if (display & 4)                                                                                // bit 2 of display is set: show the data register (REG) labels ... 
                        {
                            printf("%c[%d;%dH[REG]__________________", ESC_CHR, 4, 32);
                            for (int i = 0; i < 9; i++)
                            {
                                printf("%c[%d;%dH|    R%d", ESC_CHR, 5+i, 32, i+1);
                            }
                        }
                        if (display & 2)                                                                                // bit 1 of display is set: show rom heatmap (RHM) labels ... 
                        {
                            printf("%c[%d;%dH[RHM]____________________________________________", ESC_CHR, 14, 32);
                            for (int i = 0; i < 8; i++)
                            {
                                printf("%c[%d;%dH|", ESC_CHR, 15+i, 32);
                            }
                        }
                        if (display & 1)                                                                                // bit 0 of display is set: show recent operation (KEY) labels ...
                        {
                            printf("%c[%d;%dH[KEY]_______________________  ", ESC_CHR, 11, 1);
                        }
                        printValues(display);                                                                           // populate the new values we want to show
                        return;
                    }

                    // NO ECHO GETCHAR : IMPLEMENTS NO ECHO BY DELETE ON KEYPRESS IF NOT WINDOWS/MAC/LINUX

                    int noEchoGetchar()
                    {
                        #if !defined (WINDOWS) && !defined (MACLINUX)   
                            int keyGot = getchar();
                            printf("%c[1D ", ESC_CHR);
                        #else
                            int keyGot = getchar();
                        #endif
                        return keyGot;
                    }

                    // PRINT THE HELP SCREEN
                    
                    void printHelp(int display)
                    {
                        printf("%c[%d;%dH", ESC_CHR, 4, 0);
                        printf("________________________________________________________________________________\n");
                        printf("                                                                                \n");
                        printf(" 1/x|y^x   [\\]  | ln|log   [l]  | e^x|10^x [^]  | FIX|SCI  [f]  | SHIFT     ['] \n"); 
                        printf(" ---------------+---------------+---------------+---------------+-------------- \n");
                        printf(" x^2|sqrtx [w]  | ->P|->R  [p]  | SIN|aSIN [s]  | COS|aCOS [c]  | TAN|aTAN  [t] \n");
                        printf(" ---------------+---------------+---------------+---------------+-------------- \n");
                        printf(" x<>y|n!   [a]  | R\\/|xbrs [r]  | STO|>DMS [[]  | RCL|DMS> []]  | %%|delta%%  [y] \n");
                        printf(" ---------------+---------------+---------------+---------------+-------------- \n");
                        printf("       ENTER|DEG   [enter]      | CHS|RAD  [z]  | EEX|GRD  [e]  | CLx|CLR   [;] \n");
                        printf(" ---------------+---------------+----+----------+----------+----+-------------- \n");
                        printf(" -  [-]         |       7|cm/in [7]  |        8|kg/lb [8]  |        9|lt/gl [9] \n");
                        printf(" ---------------+--------------------+---------------------+------------------- \n");
                        printf(" +  [=] or [+]  |             4 [4]  |              5 [5]  |              6 [6] \n");
                        printf(" ---------------+--------------------+---------------------+------------------- \n");
                        printf(" x  [x] or [*]  |             1 [1]  |              2 [2]  |              3 [3] \n");
                        printf(" ---------------+--------------------+---------------------+------------------- \n");
                        printf(" /  [/]         |        0|LSTx [0]  |           .|pi [.]  |  sigma+|sigma- [o] \n");
                        printf("                                                                                \n");
                        printf("                                                                                \n");   
                        printf("________________________________________________________________________________\n");	
                        printf(" HP45TERM / HELP          [a]bout     [t]imer help     [other key] to exit help ");
                        printf("%c[%d;%dH", ESC_CHR, 2, 30);
                        char waitChar = noEchoGetchar();                                                                // leave the help screen showing until a key is pressed
                        if (waitChar == 't' || waitChar == 'T')                                                         // show the timer mode help screen if key was 't' or 'T'
                        {
                            printf("%c[%d;%dH", ESC_CHR, 4, 0);
                            printf("________________________________________________________________________________\n");
                            printf("                                                                                \n");
                            printf(" 1/x|y^x   +--------------------------------------------------------+       ['] \n"); 
                            printf(" -------   | The HP-45 has an undocumented timer mode. On the       |   ------- \n");
                            printf(" x^2|sqr   | calculator it requires simultaneous keypresses. Here   |   AN  [t] \n");
                            printf(" -------   | it is accessed by pressing RCL (']') followed by       |   ------- \n");
                            printf(" x<>y|n!   | '?'. Because this is a terminal application it pauses  |   a%%  [y] \n");
                            printf(" -------   | execution to wait for a keypress. With the timer       |   ------- \n");
                            printf("           | started (press 'z') you can record 'null' keypresses   |   R   [;] \n");
                            printf(" -------   | by holding down 'k', so that the timer updates. The    |   ------- \n");
                            printf(" -  [-]    | other controls use the same keys as the calculator.    |   /gl [9] \n");
                            printf(" -------   | [z] (CHS)                  : start and stop timer      |   ------- \n");
                            printf(" +  [=]    | [1] to [9] (timer running) : store time in register    |     6 [6] \n");
                            printf(" -------   | [1] to [9] (timer stopped) : recall time from register |   ------- \n");
                            printf(" x  [x]    | [e] (EEX)                  : toggle 100th seconds      |     3 [3] \n");
                            printf(" -------   | [enter]                    : exit timer                |   ------- \n");
                            printf(" /  [/]    | [.]                        : exit with last time in X  |   ma- [o] \n");
                            printf("           +--------------------------------------------------------+           \n");
                            printf("                                                                                \n");
                            printf("________________________________________________________________________________\n");
                            printf(" HP45TERM / HELP / TIMER                                 [any key] to exit help ");
                            printf("%c[%d;%dH", ESC_CHR, 2, 30);
                            waitChar = noEchoGetchar();                                                                 // show the time mode help screen until a key is pressed
                        }
                        else if (waitChar == 'a' || waitChar == 'A')                                                    // show the release notes screen if key was 'r' or 'R'
                        {
                            printf("%c[%d;%dH", ESC_CHR, 4, 0);
                            printf("________________________________________________________________________________\n");
                            printf("                                                                                \n");
                            printf(" 1/x|y^x   +--------------------------------------------------------+       ['] \n"); 
                            printf(" -------   |                                                        |   ------- \n");
                            printf(" x^2|sqr   |                        HP45TERM                        |   AN  [t] \n");
                            printf(" -------   |             an HP-45 simulator/interpreter             |   ------- \n");
                            printf(" x<>y|n!   |                   by Sarah K. Libman                   |   a%%  [y] \n");
                            printf(" -------   |                                                        |   ------- \n");
                            printf("           | v. 01.02.00s (source release)          date 04-05-2021 |   R   [;] \n");
                            printf(" -------   |                                                        |   ------- \n");
                            printf(" -  [-]    +--------------------------------------------------------+   /gl [9] \n");
                            printf(" -------   | Thank you to HP for making the original calculator &   |   ------- \n");
                            printf(" +  [=]    | to Eric Smith for his work transcribing & elaborating  |     6 [6] \n");
                            printf(" -------   | the HP-45 ROM code from US patents. HP45TERM was       |   ------- \n");
                            printf(" x  [x]    | written from scratch but David Hick's Java emulator    |     3 [3] \n");
                            printf(" -------   | was invaluable in debugging. Any remaining errors are  |   ------- \n");
                            printf(" /  [/]    | all my own work. SKL                                   |   ma- [o] \n");
                            printf("           +--------------------------------------------------------+           \n");
                            printf("                                                                                \n");
                            printf("________________________________________________________________________________\n");
                            printf(" HP45TERM / HELP / ABOUT                                 [any key] to exit help ");
                            printf("%c[%d;%dH", ESC_CHR, 2, 30);
                            waitChar = noEchoGetchar();                                                                 // show the release notes screen until a key is pressed
                        }
                        printScreenBackground(display);                                                                 // restore the screen background ...
                        printFixSciShift();                                                                             // ... and clean up the display section ...
                        manageScreenBackground(display);                                                                // ... and restore the optional items and values which we're currently showing
                        return;
                    }
                    
                    // PRINT THE DISPLAY SETTINGS SCREEN AND RETURN AN INTEGER WHICH ENCODES THEM ON EXIT

                    int displaySettings(int display)                        
                    {
                        bool displayCountLive = ((display & 64) == 64);                                                 // are we showing the rom heatmap (RHM) live
                        bool displaySci = ((display & 32) == 32);                                                       // are we showing data registers (REG) in sci9 format?
                        bool displayStack = ((display & 16) == 16);                                                     // are we showing stack (STK)
                        bool displayRegisters = ((display & 8) == 8);                                                   // are we showing general registers, status bits & R0 (INT)?
                        bool displayData = ((display & 4) == 4);                                                        // are we showing data registers (REG)
                        bool displayCount = ((display & 2) == 2);                                                       // are we showing rom heatmap (RHM)
                        bool displayOps = ((display & 1) == 1);                                                         // are we showing recent operation list (KEY) 
                        char selectChar = 0;
                        printf("%c[%d;%dH", ESC_CHR, 4, 0);
                        printf("[STK] >             ________   [REG] >             ___   [INT] >             ___\n");
                        printf("     [s] to toggle             |    [r] to toggle        |    [i] to toggle     \n");
                        printf("                               |    [f] to toggle format |                      \n");
                        printf("     stack: shows HP-45        |                         |                      \n");
                        printf("     stack of X, Y, Z & T,     |    storage registers:   |    internal regis-   \n");
                        printf("     & also shows lastX        |    can be shown in      |    ters: include     \n");
                        printf("                               |    'raw' format used by |    A-F & M, & R0;    \n");
                        printf("[KEY] >             ________   |    HP-45 or formatted   |    status bits (S)   \n");
                        printf("     [k] to toggle             |    as 'SCI9'            |    show bit number   \n");
                        printf("                               |                         |    in hex if set     \n");
                        printf("     recent key list: shows    [RHM] >             _____________________________\n");
                        printf("     the internal HP-45        |    [h] to toggle                               \n");
                        printf("     keycodes of recent key    |    [l] to toggle live updating (reduced speed) \n");
                        printf("     presses and decodes       |                                                \n");
                        printf("     them into calculator      |    heatmap: HP-45 ops since last keypress;     \n");
                        printf("     operations                |    total per rom & [32 8-byte blocks in ROM];  \n");
                        printf("                               |    X if > 10; live: updates during execution   \n");
                        printf("[ALL]___________________________________________________________________________\n");
                        printf("     [a] to toggle visibility of all sections                                   \n");
                        printf("________________________________________________________________________________\n");
                        printf(" HP45TERM / DISPLAY OPTIONS                            [e]xit and save settings ");
                        while(selectChar != 'e' && selectChar != 'E')                                                   // display current settings until 'e' or 'E' is entered ...
                        {   
                            (displayStack)     ? printf("%c[%d;%dHSHOWN ______", ESC_CHR, 4, 9)   : printf("%c[%d;%dH____ HIDDEN ", ESC_CHR, 4, 9);
                            (displayRegisters) ? printf("%c[%d;%dHSHOWN ______", ESC_CHR, 4, 66)  : printf("%c[%d;%dH____ HIDDEN ", ESC_CHR, 4, 66);
                            if (displayData)
                            {
                                (displaySci)   ? printf("%c[%d;%dHSHOWN (SCI9) ", ESC_CHR, 4, 40) : printf("%c[%d;%dHSHOWN (RAW) _", ESC_CHR, 4, 40);
                            }
                            else
                            {
                                printf("%c[%d;%dH____ HIDDEN _", ESC_CHR, 4, 40);
                            }
                            (displayOps)       ? printf("%c[%d;%dHSHOWN ______", ESC_CHR, 11, 9)  : printf("%c[%d;%dH____ HIDDEN ", ESC_CHR, 11, 9);
                            if (displayCount)
                            {
                                (displayCountLive) ? printf("%c[%d;%dHSHOWN (LIVE) ", ESC_CHR, 14, 40) : printf("%c[%d;%dHSHOWN _______", ESC_CHR, 14, 40);
                            }
                            else
                            {
                                printf("%c[%d;%dH____ HIDDEN _", ESC_CHR, 14, 40);
                            }     
                            printf("%c[%d;%dH", ESC_CHR, 22, 77);
                            selectChar = noEchoGetchar();
                            switch (selectChar)                                                                         // ... and update those settings according to keys pressed
                            {
                                case 's':
                                case 'S':
                                    displayStack = !displayStack;
                                    break;
                                case 'k':
                                case 'K':
                                    displayOps = !displayOps;
                                    break;
                                case 'i':
                                case 'I':
                                    displayRegisters = !displayRegisters;
                                    break;
                                case 'r':
                                case 'R':
                                    displayData = !displayData;
                                    break;
                                case 'h':
                                case 'H':
                                    displayCount = !displayCount;
                                    break;
                                case 'l':
                                case 'L':
                                    displayCountLive = !displayCountLive;
                                    break;
                                case 'a':                                                                               // 'toggle all' sets all to 'shown' if not all currently shown, else sets all to 'not shown'
                                case 'A':
                                    if (displayStack && displayOps && displayRegisters && displayData && displayCount)
                                    {
                                        displayStack = false;
                                        displayOps = false;
                                        displayRegisters = false;
                                        displayData = false;
                                        displayCount = false;
                                    }
                                    else
                                    {
                                        displayStack = true;
                                        displayOps = true;
                                        displayRegisters = true;
                                        displayData = true;
                                        displayCount = true;
                                    }
                                    break;
                                case 'f':
                                case 'F':
                                    displaySci = !displaySci;
                                    break;
                            }
                        }
                        display = 0;                                                                                    // clear display variable and then assign value according to flags set
                        if (displayCountLive)   display = display + 64;
                        if (displaySci)         display = display + 32;
                        if (displayStack)       display = display + 16;
                        if (displayRegisters)   display = display + 8;
                        if (displayData)        display = display + 4;
                        if (displayCount)       display = display + 2;
                        if (displayOps)         display = display + 1;
                        printScreenBackground(display);                                                                 // show the general background again ...
                        printFixSciShift();                                                                             // ... and clean up the display section ...
                        manageScreenBackground(display);                                                                // ... and update optional labels and values
                        return display;
                    }
                    
                    // TOGGLE MINIMAL MODE

                    void toggleMinimalMode(int display)                                                                 // minimal mode turns off all unecessary processing and display functions
                    {
                        minimal_Mode = !minimal_Mode;
                        if (minimal_Mode)
                        {
                            printf("%c[2J", ESC_CHR);
                            printf("%c[%d;%dH", ESC_CHR, 0, 0);
                            printf("                                                                                \n");
                            printf("                                                                                \n");
                            printf("                                                                                \n");
                            printf("________________________________________________________________________________\n");
                            printf("                                                                                \n");
                            printf("                                                                                \n");
                            printf("                                                                                \n");
                            printf("                                                                                \n");
                            printf("                                                                                \n");
                            printf("                                                                                \n");
                            printf("                                                                                \n");
                            printf("                                                                                \n");
                            printf("                                                                                \n");
                            printf("                                                                                \n");
                            printf("                                                                                \n");
                            printf("              non-HP-45 processing is minimized                                 \n");
                            printf("                                                                                \n");
                            printf("              - only the calculator display is visible                          \n");
                            printf("              - the operation list and rom heatmap are not updated              \n");
                            printf("              - the help and display options are not available                  \n");
                            printf("                                                                                \n");
                            printf("                                                                                \n");
                            printf("________________________________________________________________________________\n");	
                            printf(" HP45TERM / MINIMAL MODE                         [m]inimal mode off      [Q]uit ");
                            printDisplay();                                                                             // put the calculator display back
                            printf("%c[%d;%dH", ESC_CHR, 2, 30);
                        }
                        else
                        {
                            for (int i = 0; i < 11; i++)                                                                // clear the (outdated) operation codes for recent key presses
                            {
                                operation_List[i] = 0;
                            }
                            for (int i = 0; i < 8; i++)                                                                 // clear the (outdated) operation count and heatmap
                            {
                                rom_Op_Count[i] = 0;
                                for (int j = 0; j < 32; j++)
                                {
                                    rom_Op_Position[i][j] = 0;
                                }
                            }
                            printScreenTopBackground();                                                                 // put the screen back ...
                            printScreenBackground(display);                                                             
                            manageScreenBackground(display);
                            printDisplay();                                                                             // ... and put the calculator display back
                        }
                        return;
                    }

                    // GET A KEY FROM THE KEYBOARD AND RETURN A KEYCODE

                    int getKey()                                                                                        // the emulator has halted and is waiting for a key press which we get here                                                                                 
                    {
                        int keyPressed = 0;
                        int keyDecoded = 99;
                        printf("%c[%d;%dHwaiting for keypress", ESC_CHR, 2, 58);
                        printf("%c[%d;%dH", ESC_CHR, 2, 30); 
                        keyPressed = noEchoGetchar();                                                                   // get a key
                        if ((keyPressed < 34 && keyPressed != 10 && keyPressed != 13) || keyPressed > 126)              // filter out keys which aren't alphanumeric or enter ...
                            {                                                                                           // ... and tidy up the display if one pressed
                                #if !defined (WINDOWS)                                                                  
                                    while ((keyPressed = noEchoGetchar()) != '\n')                                      // (not Windows) : dealing with the stdin buffer is so very, very, very tedious ...
                                    {                                                                                   // (not Windows) : ( ... in Windows as well as Mac/Linux, just not right here)
                                        printf("%c[%d;%dH[ERROR:NON-ALPHANUMERIC KEY | 'ENTER' TO CONTINUE]", ESC_CHR, 2, 29);  // (not Windows)
                                        printf("%c[%d;%dH", ESC_CHR, 2, 29);                                            // (not Windows)
                                    }                                                                                   // (not Windows)
                                    printf("%c[%d;%dH    [     ] [     ] [     ] [waiting for keypress]", ESC_CHR, 2, 29);      // (not Windows)
                                    printFixSciShift();                                                                 // (not Windows)
                                #endif
                                return 99;                                                                              // return 99 to say we haven't had a valid keypressed
                             }                                                          
                        if (keyPressed == 'Q')    return 98;                                                            // this will cause the program to quit (uppercase to avoid accidental press)
                        if (keyPressed == 'd')    return 97;                                                            // this will cause display options screen to be displayed
                        if (keyPressed == 'h')    return 96;                                                            // this will cause the help screen to be displayed
                        if (keyPressed == 'm')    return 95;                                                            // this will cause minimal mode to be toggled
                        if (keyPressed == 'k')    return 300;                                                           // used when the timer is running to indicate 'continue execution as if no key pressed'
                        for (int i=0; i<39; i++)
                        {
                            if (key_Codes[i][0] == keyPressed)                                                          // otherwise lookup the decoded key value (the byte to which execution will goto next)
                            {
                                keyDecoded = key_Codes[i][1];
                                break;
                            }
                        }
                        printf("%c[%d;%dH      working       ", ESC_CHR, 2, 58);
                        printf("%c[%d;%dH", ESC_CHR, 2, 30);
                        return keyDecoded;                                                                              // this will be 99 if no valid key pressed
                    }

                    // HALT ROM CODE OPERATIONS, UPDATE SCREEN AND PROCESS USER INPUT

                    int userInput(int display)                                                                          // we've stopped processing ROM operations to get a key from the user
                    {                                                                                                   
                        printValues(display);                                                                           // but first! update the screen with any optional values being shown
                        key_Code = 99;                                            
                        while (key_Code == 99)
                        {
                            key_Code = getKey();                                                                        // wait for a key to be pressed and return a code based on that key
                            if (key_Code == 98)                                                                         // 'Q' pressed : quit program
                            {
                                return 256;                                                                             // uses displayMode (wrongly, but conveniently) to tell main that we're quitting
                            }
                            else if (key_Code == 97)                                                                    // 'd' pressed : set display options and then repeat loop on return to get another key
                            {
                                display = displaySettings(display);
                                key_Code = 99;                                
                            }
                            else if (key_Code == 96)                                                                    // 'h' pressed : show help screen and then repeat loop on return to get another key
                            {
                                printHelp(display);
                                key_Code = 99;
                            }
                            else if (key_Code == 95)                                                                    // 'm' pressed : toggle minimal mode 
                            {
                                toggleMinimalMode(display);                                                             
                                return display;                                                                         // don't repeat loop here (with key_Code = 99) because now in minimal mode
                            }
                        }
                        for (int i = 0; i < 8; i++)                                                                     // a calculator key has been pressed : reset number of ops between keypresses counter
                        {
                            rom_Op_Count[i] = 0;
                            if (((display & 64) == 64) && ((display & 2) == 2))                                         // if showing rom op counts and in live mode : clear display prior to continuing
                            {
                                printf("%c[%d;%dH          [                                ]", ESC_CHR, 15+i, 37);
                            }
                            for (int j = 0; j <32 ; j++)
                            {
                                rom_Op_Position[i][j] = false;
                            }
                        }
                        if (key_Code != 300)                                                                            // as long as we're not in the timer with 'no key press' returned (key_Code 300)...
                        {
                            setStatus(0);                                                                               // ... let the calculator know a key has been pressed by setting status bit 0
                            if (key_Code != 0)                                                                          // if it wasn't the shift key ...
                            {
                                for (int i = 9; i >= 0; i--)                                                            // ... update the operations list
                                {
                                    operation_List[i+1] = operation_List[i];
                                }
                                operation_List[0] = key_Code;
                                if (_s[10]) operation_List[0] = operation_List[0] + 100;                                // status bit 10 set when shift pressed, so shifted version of current key : store 100 + code
                                if (timer_Mode) operation_List[0] = operation_List[0] + 300;                            // we're in timer mode so add another 300 to the stored code
                                if (operation_List[1] == 10 && key_Code == 60)                                          // last key was RCL '[' and this one is '?' so we're entering timer mode
                                {
                                    timer_Mode = true;
                                }
                                if (timer_Mode && (key_Code == 62 || key_Code == 35))                                   // we're in timer mode and have pressed 'enter' or '.' so we're leaving timer mode
                                {
                                    timer_Mode = false;
                                }
                            }
                        }
                    return display;                                                                                     // we return display because it may have been changed whilst in this function
                    }

                    // GET A KEY FROM THE KEYBOARD AND RETURN A KEYCODE : MINIMAL MODE

                    int getKeyMinimal()                                                                                 // the emulator has halted and is waiting for a key press which we get here                                                                                 
                    {
                        int keyPressed = 0;
                        int keyDecoded = 99;
                        keyPressed = noEchoGetchar();                                                                   // get a key
                        if ((keyPressed < 34 && keyPressed != 10 && keyPressed != 13) || keyPressed > 126)              // filter out keys which aren't alphanumeric or enter ...
                            {                                                                                           // ... and tidy up the display if one pressed
                                #if !defined (WINDOWS)                                                                  
                                    while ((keyPressed = noEchoGetchar()) != '\n')                                      // (not Windows) : dealing with the stdin buffer is so very, very, very tedious ...
                                    {                                                                                   // (not Windows) : ( ... in Windows as well as Mac/Linux, just not right here)
                                        printf("%c[%d;%dH[ERROR:NON-ALPHANUMERIC KEY | 'ENTER' TO CONTINUE]", ESC_CHR, 2, 29);  // (not Windows)
                                        printf("%c[%d;%dH", ESC_CHR, 2, 29);                                            // (not Windows)
                                    }                                                                                   // (not Windows)
                                    printf("%c[%d;%dH                                                  ", ESC_CHR, 2, 29);      // (not Windows)
                                    printf("%c[%d;%dH", ESC_CHR, 2, 30);
                                #endif
                                return 99;                                                                              // return 99 to say we haven't had a valid keypressed
                             }                                                          
                        if (keyPressed == 'Q')    return 98;                                                            // this will cause the program to quit (uppercase to avoid accidental press)
                        if (keyPressed == 'm')    return 95;                                                            // this will cause minimal mode to be toggled
                        for (int i=0; i<39; i++)
                        {
                            if (key_Codes[i][0] == keyPressed)                                                          // otherwise lookup the decoded key value (the byte to which execution will goto next)
                            {
                                keyDecoded = key_Codes[i][1];
                                break;
                            }
                        }
                        printf("%c[%d;%dH", ESC_CHR, 2, 30);
                        return keyDecoded;                                                                              // this will be 99 if no valid key pressed
                    }

                    // HALT ROM CODE OPERATIONS, UPDATE SCREEN AND PROCESS USER INPUT : MINIMAL MODE

                    int userInputMinimal(int display)                                                                   // we've stopped processing ROM operations to get a key from the user
                    {                                                                                                   
                        key_Code = 99;                                            
                        while (key_Code == 99)
                        {
                            key_Code = getKeyMinimal();                                                                 // wait for a key to be pressed and return a code based on that key
                            if (key_Code == 98)                                                                         // 'Q' pressed : quit program
                            {
                                return 256;                                                                             // uses displayMode (wrongly, but conveniently) to tell main that we're quitting
                            }
                            else if (key_Code == 95)
                            {
                                toggleMinimalMode(display);                                                             // toggle minimal mode
                                return display;                                                                         // don't continue loop here (with key_Code = 99) because no longer in minimal mode
                            }
                        }
                        setStatus(0);                                                                                   // ... let the calculator know a key has been pressed by setting status bit 0
                        return display;                                                                                 // we return display because it may have been changed whilst in this function
                    }

// +----------------------------------------------------------------------------
// +----------------------------------------------------------------------------
// |    RUN THE EMULATION
// +----------------------------------------------------------------------------
// +----------------------------------------------------------------------------

int main()                                                                      
{
    clearRegs();                                                                                    // start with everything zeroed
    clearAllStatus();
    clearDataRegs();
    int byteContents = 0;                                                                           // contents of the current location in the current ROM
    int instruction = 0;                                                                            // instruction at current address
    int parameter = 0;                                                                              // parameter at current address
    bool skipByteNumberIncr = false;                                                                // set true if we do a goto or jumpsub so we don't also increment the byte number
                    int lastRom = 0;                                                                                    // used if heatmap is shown live
                    int lastByte = 0;                                                                                   // used if heatmap is shown live
                    #if defined (WINDOWS)                                                                                 
                        HANDLE termOut = GetStdHandle(STD_OUTPUT_HANDLE);                                               // Windows : following lines set up console to use VT100/ANSI codes
                        DWORD outMode = 0;                                                                              // Windows
                        GetConsoleMode(termOut, &outMode);                                                              // Windows : get the current console mode for output ...
                        DWORD storeOutMode = outMode;                                                                   // Windows : ... and store it
                        outMode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;                                                  // Windows : update mode so control codes translated
                        SetConsoleMode(termOut, outMode);                                                               // Windows : set the new console mode for output
                        HANDLE termIn = GetStdHandle(STD_INPUT_HANDLE);                                                 // Windows : following lines remove need for 'enter' to register character ...
                        DWORD inMode = 0;                                                                               // Windows : ... and allow 'enter' itself to register (as 13, not 10, though)
                        _setmode(_fileno(stdin), _O_BINARY);                                                            // Windows : set input to binary mode to stop CR-LF translation to LF (else problems!)
                        GetConsoleMode(termIn, &inMode);                                                                // Windows : get the current console mode for input ...
                        DWORD storeInMode = inMode;                                                                     // Windows : ... and store it
                        inMode &= ~(ENABLE_LINE_INPUT);                                                                 // Windows : update mode so no need for 'enter' before noEchoGetchar() input processed
                        SetConsoleMode(termIn, inMode);                                                                 // Windows : set the new console mode for input
                        int displayMode = 63;                                                                           // Windows : running fast enough to show everything from the start
                    #elif defined (MACLINUX)                                                                              
                        static struct termios storeTerm, newTerm;                                                       // Mac/Linux : these few lines remove the need for return/EOF/EOL after keypress
                        tcgetattr(STDIN_FILENO, &storeTerm);                                                            // Mac/Linux : get the parameters of the current terminal stdin and store
                        newTerm = storeTerm;                                                                            // Mac/Linux : save current setting
                        newTerm.c_lflag &= ~(ICANON);                                                                   // Mac/Linux : ICANON normally takes care that one line at a time will be processed    
                        newTerm.c_lflag &= ~(ECHO);                                                                     // Mac/Linux : don't echo keypresses
                        tcsetattr(STDIN_FILENO, TCSANOW, &newTerm);                                                     // Mac/Linux : TCSANOW tells tcsetattr to change attributes immediately
                        int displayMode = 63;                                                                           // Mac/Linux : running fast enough to show everything from the start
                    #else
                        int displayMode = 32;                                                                           // otherwise : default storage to show as SCI9 but don't display anything on startup    
                    #endif
                    printf("%c[?25l", ESC_CHR);                                                                         // hide cursor : works on ANSI, not on VT100
                    printScreenTopBackground(); 
                    printScreenBackground(displayMode);                                                             
                    manageScreenBackground(displayMode);
                    for (int i = 0; i < 8; i++)                                                                         // clear the operation heatmap
                    {
                        for (int j = 0; j < 32; j++)
                        {
                            rom_Op_Position[i][j] = 0;
                        }
                    }
    while (true)                                                                                                        // the main loop : everything else happens in here
    {
                    if(!minimal_Mode)                                                                                   // if we're not in minimal mode
                    {
                        rom_Op_Count[current_Rom]++;                                                                    // add to op count for ROM
                        if (rom_Op_Position[current_Rom][current_Byte/8] < 10)
                        {
                            rom_Op_Position[current_Rom][current_Byte/8]++;                                             // update the count for the rom/byte block
                        }
                        if (((displayMode & 64) == 64) && ((displayMode & 2) == 2))                                     // if we're watching heatmap and in live mode
                        {
                            printf("%c[%d;%dH", ESC_CHR, 15+lastRom, 48+(lastByte/8));                                  // go to the last rom/byte block on screen ...
                            if (rom_Op_Position[lastRom][lastByte/8] == 10)                                             // ... and replace the * with its total ops so far
                            {
                                printf("X");                                                                            
                            }
                            else
                            {
                                printf("%d", rom_Op_Position[lastRom][lastByte/8]);                                     
                            }
                            printf("%c[%d;%dHROM%d", ESC_CHR, 15+current_Rom, 37, current_Rom);                         // 'light' the current rom ...
                            printf("%c[%d;%dH*", ESC_CHR, 15+current_Rom, 48+(current_Byte/8));                         // ... and * the show the current rom/byte block
                            lastRom = current_Rom;                                                                      // update last op rom ...
                            lastByte = current_Byte;                                                                    // ... and last op byte
                            #if defined (MACLINUX)                                                                      
                                printf("\n");                                                                           // Mac/Linux : need to flush the buffer to update screen
                                usleep(2500);                                                                           // Mac/Linux : and slow things down if live view enabled
                            #endif
                        }
                    }
        byteContents = _ROM[current_Rom][current_Byte];                                             // get the contents of the current byte in the current rom, to be decoded
        instruction = 255;                                                                          // 255 - instruction type error
        parameter = 255;                                                                            // 255 - parameter type error

        if ((byteContents & 1) == 1)                                                                // flowOp - opType 1 - binary byteContents ends in 1
        {
            instruction = (2 & byteContents) >> 1;                                                  // instruction - coded as --------b- (where b in a bit)
            parameter = (1020 & byteContents) >> 2;                                                 // location - coded as bbbbbbbb--
            switch (instruction)                                                                        
            {
                case 0:                                                                             // --- OPERATION : jumpsub
                    skipByteNumberIncr = jumpSub(parameter);                                        // skipByteNumberIncr set to true
                    break;
                case 1:                                                                             // --- OPERATION : goto
                    skipByteNumberIncr = goTo(parameter);                                           // skipByteNumberIncr set to true if goto executed
                    break;
            }
            _carry = 0;                                                                             // reset carry after operation

        }
        else if ((byteContents & 3) == 2)                                                           // registerOp - opType 2 - binary byteContents ends in 10
        {
            _carry = 0;                                                                             // reset carry before operation
            instruction = (992 & byteContents) >> 5;                                                // instruction - coded as bbbbb----- (could be considered as parameter)
            parameter = (28 & byteContents) >> 2;                                                   // component - coded as -----bbb-- (could be considered as instruction)
            switch (instruction) {
                case 0:                                                                             // --- OPERATION : if b = 0         
                    ifRegZero(REG_B,parameter);
                    break;
                case 1:                                                                             // --- OPERATION : clear b
                    clearReg(REG_B,parameter);
                    break;
                case 2:                                                                             // --- OPERATION : if a >= c
                    ifRegReg(REG_A, REG_C, parameter);
                    break;
                case 3:                                                                             // --- OPERATION : if c >= 1
                    ifRegOne(REG_C, parameter);
                    break;
                case 4:                                                                             // --- OPERATION : b -> c
                    copyReg(REG_B, REG_C, parameter);
                    break;
                case 5:                                                                             // --- OPERATION : 0 - c -> c ()
                    negReg(REG_C, parameter);
                    break;
                case 6:                                                                             // --- OPERATION : clear c
                    clearReg(REG_C, parameter);
                    break;
                case 7:                                                                             // --- OPERATION : 0 - c - 1 -> c
                    negDecReg(REG_C, parameter);
                    break;
                case 8:                                                                             // --- OPERATION : leftShift a
                    lShiftReg(REG_A, parameter);
                    break;
                case 9:                                                                             // --- OPERATION : a -> b
                    copyReg(REG_A,REG_B, parameter);
                    break;
                case 10:                                                                            // --- OPERATION : a - c -> c
                    subRegs(REG_A, REG_C, REG_C, parameter);
                    break;
                case 11:                                                                            // --- OPERATION : decrement c
                    decReg(REG_C, parameter);
                    break;
                case 12:                                                                            // --- OPERATION : c -> a
                    copyReg(REG_C, REG_A, parameter);
                    break;
                case 13:                                                                            // --- OPERATION : if c = 0
                    ifRegZero(REG_C, parameter);
                    break;
                case 14:                                                                            // --- OPERATION : a + c -> c
                    addRegs(REG_A, REG_C, REG_C, parameter);
                    break;
                case 15:                                                                            // --- OPERATION : increment c
                    incReg(REG_C, parameter);
                    break;
                case 16:                                                                            // --- OPERATION : if a >= b
                    ifRegReg(REG_A, REG_B, parameter);
                    break;
                case 17:                                                                            // --- OPERATION : exchange b c
                    exchangeRegs(REG_B, REG_C, parameter);
                    break;
                case 18:                                                                            // --- OPERATION : rightShift c
                    rShiftReg(REG_C, parameter);
                    break;
                case 19:                                                                            // --- OPERATION : if a >= 1
                    ifRegOne(REG_A, parameter);
                    break;
                case 20:                                                                            // --- OPERATION : rightShift b
                    rShiftReg(REG_B, parameter);
                    break;
                case 21:                                                                            // --- OPERATION : c + c -> c
                    addRegs(REG_C, REG_C, REG_C, parameter);
                    break;
                case 22:                                                                            // --- OPERATION : rightShift a
                    rShiftReg(REG_A, parameter);
                    break;
                case 23:                                                                            // --- OPERATION : clear a
                    clearReg(REG_A, parameter);
                    break;
                case 24:                                                                            // --- OPERATION : a - b -> a
                    subRegs(REG_A, REG_B, REG_A, parameter);
                    break;
                case 25:                                                                            // --- OPERATION : exchange a b
                    exchangeRegs(REG_A, REG_B, parameter);
                    break;
                case 26:                                                                            // --- OPERATION : a - c -> a
                    subRegs(REG_A, REG_C, REG_A, parameter);
                    break;
                case 27:                                                                            // --- OPERATION : decrement a
                    decReg(REG_A, parameter);
                    break;
                case 28:                                                                            // --- OPERATION : a + b -> a
                    addRegs(REG_A, REG_B, REG_A, parameter);
                    break;
                case 29:                                                                            // --- OPERATION : exchange a c
                    exchangeRegs(REG_A, REG_C, parameter);
                    break;
                case 30:                                                                            // --- OPERATION : a + c -> a
                    addRegs(REG_A, REG_C, REG_A, parameter);
                    break;
                case 31:                                                                            // --- OPERATION : increment a
                    incReg(REG_A, parameter);
                    break;
            }         
        }
        else if ((byteContents & 15) == 4)                                                          // statusOp - opType 3 - binary byteContents ends in 0100
        {
            _carry = 0;                                                                             // reset carry before operation
            parameter = (960 & byteContents) >> 6;                                                  // status bit - coded as bbbb------
            instruction = (48 & byteContents) >> 4;                                                 // instruction coded as ----bb----
            switch (instruction) {
                case 0:                                                                             // set status bit (i.e. set true)
                    setStatus(parameter);
                    break;
                case 1:                                                                             // check if status bit != 1 (i.e. is false)
                    if (parameter == 0 && _s[8])                                                                        // if bit 8 is true _and_ the ROM code is checking bit 0 then we're entering the loop to check a key press
                    {
                        if (!minimal_Mode)                                                                              // get user input depending on minimal mode
                        {
                            displayMode = userInput(displayMode);                                                       // instead of looping, we halt ROM operations and wait for a key to be pressed (which may change displayMode)
                        }
                        else
                        {
                            displayMode = userInputMinimal(displayMode);                                                // same as above but less processing
                        }
                        if (displayMode == 256)                                                                         // user input has chosen to exit the program
                        {
                            printf("%c[?25h", ESC_CHR);                                                                 // show cursor : works on ANSI not on VT100
                            #if defined (MACLINUX)                                                                      
                                tcsetattr( STDIN_FILENO, TCSANOW, &storeTerm);                                          // Mac/Linux : restore the old terminal settings
                            #elif defined (WINDOWS)                                                                     
                                SetConsoleMode(termOut, storeOutMode);                                                  // Windows : restore original console mode for output
                                _setmode(_fileno(stdin), _O_TEXT);                                                      // Windows : switch back to text input mode on stdin 
                                SetConsoleMode(termIn, storeInMode);                                                    // Windows : restore original console mode for input   
                            #endif 
                            printGoodbye();
                            exit(0);                        
                        }
                    }                                                                               
                    ifSBitZero(parameter);                                                          // check the status bit
                    break;
                case 2:                                                                             // --- OPERATION : clear status bit (i.e. set false)
                    clearStatus(parameter);
                    break;
                case 3:                                                                             // --- OPERATION : clear all status bits (i.e. set all false)
                    clearAllStatus();
                    break;
            }
        }
        else if ((byteContents & 15) == 12)                                                         // pointerOp - opType 4 - binary byteContents ends in 1100
        {
            _carry = 0;                                                                             // reset carry before operation
            instruction = (48 & byteContents) >> 4;                                                 // instruction - coded as ----bb----
            parameter = (960 & byteContents) >> 6;                                                  // value - coded as bbbb------
            switch (instruction) {
                case 0:                                                                             // --- OPERATION : value -> p       
                    setP(parameter);
                    break;
                case 1:                                                                             // --- OPERATION : decrement p      
                    decP();
                    break;
                case 2:                                                                             // --- OPERATION : if p != value
                    ifPNotValue(parameter);
                    break;
                case 3:                                                                             // --- OPERATION : increment p
                    incP();
                    break;
            }
        }
        else if ((byteContents & 63) == 16)                                                         // romOp - opType 5 - binary byteContents ends in 010000
        {
            _carry = 0;                                                                             // reset carry before operation
            instruction = (64 & byteContents) >> 6;                                                 // instruction - coded as ---b------
            parameter = (896 & byteContents) >> 7;                                                  // rom number - coded as bbb-------
            switch (instruction) {
                case 0:                                                                             // --- OPERATION : selectRom
                    selectRom(parameter);
                    break;
                case 1:                                                                             // --- OPERATION : keys -> romAddress (technically a flowOP)
                    skipByteNumberIncr = keyGoTo();                                                 // returns true so we don't increment the byte number
                    break;
            }
        }
        else if ((byteContents & 63) == 24)                                                         // constantOp - opType 6 - binary byteContents ends in 011000
        {
            _carry = 0;                                                                             // reset carry before operation
            instruction = 0;                                                                        // same for all constantOps
            parameter = (960 & byteContents) >> 6;                                                  // parameter coded as bbbb------
            loadConstant(parameter);                                                                // --- OPERATION : loadConstant to register C at nibble P, and decrement pointer P
        }
        else if ((byteContents & 1023) == 0)                                                        // nOp - opType 7 - binary byteContents are 0000000000
        {
            _carry = 0;                                                                             // reset carry before operation
            instruction = 0;                                                                        // same for all nOps
            parameter = 0;                                                                          // same for all nOps
            nOp();                                                                                  // --- OPERATION : nOp
        }
        else if ((byteContents & 7) == 0)                                                           // otherOp - opType 8 - binary byteContents ends in 000 but not 010000 and not 011000 and not 0000000000
        {
            _carry = 0;                                                                             // reset carry before operation
            instruction = (1016 & byteContents) >> 3;                                               // instruction coded as bbbbbbb---
            parameter = 0;                                                                          // same for all otherOps
            switch (instruction) {
                case 5:                                                                             // --- OPERATION : (display) displayToggle
                    displayToggle();
                    printDisplay();                                                                                     // print the updated display
                    break;
                case 6:                                                                             // --- OPERATION : (flow) return
                    ret();
                    skipByteNumberIncr = true;                                                      // ret() returns to byte after last-jump-from byte so no need to increment
                    break;
                case 21:                                                                            // --- OPERATION : (register) exchange c m (always full word)
                    exchangeRegs(REG_C, REG_M, C_W);
                    break;
                case 37:                                                                            // --- OPERATION : (stack) c -> stack
                    pushC();
                    break;
                case 53:                                                                            // --- OPERATION : (stack) stack -> a
                    popA();
                    break;
                case 69:                                                                            // --- OPERATION : (display) displayOff
                    displayOff();
                    printDisplay();                                                                                     // print the updated display
                    break;
                case 78:                                                                            // --- OPERATION : (data) c -> data_Address (from nibble 12)
                    setDataAddress();
                    break;
                case 85:                                                                            // --- OPERATION : (register) m -> c (always full word)
                    copyReg(REG_M, REG_C, C_W);
                    break;
                case 94:                                                                            // --- OPERATION : (data) c -> data (always full word)
                    cToData();
                    break;
                case 95:                                                                            // --- OPERATION : (data) data -> c
                    dataToC();
                    break;
                case 101:                                                                           // --- OPERATION : (stack) rotateDown
                    rotateDown();
                    break;
            }
        }        
        if (skipByteNumberIncr)                                                                     // if byte number updated by flow operation then don't also increment
        {
            skipByteNumberIncr = false;
        }
        else
        {
            current_Byte++;
        }
        if (current_Byte > 255)                                                                     // if at the end of a ROM, go back to the start and carry on (!)
        {
            current_Byte = 0;
        }    
    }
    return 0;
}