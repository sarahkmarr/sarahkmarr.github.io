Hi, and thanks for downloading HP-1973 for MacOS. Please read the following to ensure the simulator works for you.

The simulator was coded and run on a Mac with a 1920x1080 screen. I don't have access to multiple Macs with different screens, but when a friend tried the simulator on her modern MacBook Air (rather than mine, which is from 2010), the execution list and current values pane did not display correctly as there was not enough vertical space on the screen. 

This version therefore uses a shorter execution list, in order to avoid this problem.

Additionally, to ensure the downloaded code runs, the preference files are part of the application itself, rather than being separate files. (If you'd like to make changes to them, they are separate in the Python source version.)

I'm working to solve this problem in a better manner, but in the meantime you're not losing any information or functionality when running the MacOS standalone version.

Sarah Libman

