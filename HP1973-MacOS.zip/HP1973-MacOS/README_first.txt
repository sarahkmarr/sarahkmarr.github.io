Hi, and thanks for downloading HP-1973 for MacOS. Please read the following to ensure the simulator works for you.

The simulator was coded and run on a Mac with a 1920x1080 screen. I don't have access to multiple Macs with different screens, but when a friend tried the simulator on her modern MacBook Air (rather than mine, which is from 2010), the execution list and current values pane did not display correctly as there was not enough vertical space on the screen. As a result I added a preference which reduces the height of the list. There are two preference files in the distribution, hp1973_prefs_normal.json and hp1973_prefs_short.json.

My suggestion is that you leave the files alone initially and try the simulator: it will use the '_normal' file and show a warning message on the calculator-ROM select screen to remind you that it's doing that. If everything displays correctly, then just rename hp1973_prefs_normal.json to hp1973_prefs.json and that will get rid of the warning message. However, if you find that the execution list and current values are not displaying correctly then rename hp1973_prefs_short.json to hp1973_prefs.json instead and all should be well.

Sarah Libman

