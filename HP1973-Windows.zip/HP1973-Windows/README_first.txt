Hi, and thanks for downloaded HP-1973 for Windows. Please read the following to ensure the simulator works for you.

The standalone Windows version of the simulator was prepared in Windows 11, and tested on Windows 10, on 1920x1080 screens.

CHANGING THE SCREEN MAGNIFICATION

On some machines, Windows defaults to showing the screen at 125% magnification, which makes the simulator too large for a 1920x1080 screen. You can fix this by going into display settings and, under 'Scale and layout', changing this to 100%.

RENAMING THE PREFERENCE FILE

I found that the execution list and current values pane did not display correctly (on a Mac) when there was not enough vertical space on the screen, so I added a preference which reduces the height of the list. In the 'Code' folder (which is in the same folder as this README), there are two files — hp1973_prefs_normal.json and hp1973_prefs_short.json.

My suggestion is that you leave the files alone initially and try the simulator: it will use the '_normal' file and show a warning message on the calculator-ROM select screen to remind you that it's doing that. If everything displays correctly, then just rename hp1973_prefs_normal.json to hp1973_prefs.json and that will get rid of the warning message. However, if you find that the execution list and current values are not displaying correctly then rename hp1973_prefs_short.json to hp1973_prefs.json instead and all should be well.

RUNNING THE SIMULATOR

To run the simulator, run HP1973.bat (found in the same folder as this README) by double-clicking it, as for a normal app.

Sarah Libman