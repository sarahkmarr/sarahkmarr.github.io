# ----------------------------------------------------------------------------------------
# HP-1973 (A 50th Anniversary Electronic Slide Rule)
#          a simulator of HP-35, HP-45 and HP-80 calculators
#          by Sarah Libman
#          version 1.0.0
#          ideally, downloaded from sarahkmarr.com
#          made available under a "you know, just be nice about it: use it, play
#          with it, tweak it, but don't pretend you wrote it, don't host it
#          elsewhere and don't try to make money from it" licence
# ----------------------------------------------------------------------------------------

version = "1.00.00"


# ----------------------------------------------------------------------------------------
#  CALCULATOR : everything needed to simulate the calculator given a calculator
#               definition file in json format
#-----------------------------------------------------------------------------------------

from numpy import array2string, flip, roll, zeros, array, array_equal
from os import path as ospath
from platform import system as platformName
from sys import argv as sysargv

""" registers and components
----------------------------
7 internal registers, named A to F and M. (Here we use an array numbered 0 to
6). Each register contains 14 4-byte nibbles (here we use integers) numbered
13 (left) to 0 (right) which each hold a values between 0 and 9. (Here our
registers are numbered 0 on the left to 13 on the right until displaying the
registers).

The registers are accessed in ranges called components. There are 8 components:
P  Pointer (nibble indicated by a pointer) [P]
M  Mantissa [12, 11, ..., 3]
X  Exponent [2, 1, 0]
W  Word (entire register) [13, 12, ..., 0]
WP Word up to (including) pointer nibble [P, P-1, ..., 0]
MS Mantissa and Sign [13, 12, ..., 3]
XS Exponent Sign [2]  : 0 if positive and 9 if negative (may hold other values)
S  Mantissa Sign [13] : 0 if positive and 9 if negative (may hold other values)
"""

                    # a few global constants to keep things neat for internal registers...
r_a = 0; r_b = 1; r_c = 2; r_d = 3; r_e = 4; r_f = 5; r_m = 6
                                                          # ...and components of registers
c_p = 0; c_m = 1; c_x = 2; c_w = 3; c_wp = 4; c_ms = 5; c_xs = 6; c_s = 7

""" ROMs
--------
The calculator's code is split into ROMs of 26 addresses, Each address contains
a 10-bit bytes The HP-35 has 3 ROMs, the HP-80 has 7, and the HP-45 has 8. Each
byte decodes to an an instruction and parameters. A set of rom enable bits
(the ROE) determines which ROM is enabled, and for a given address it is the
byte contents of this ROM which are decoded and executed.
    Instructions include program branching (goTo, jumpSub, ...),
register changes, status bit updates, etc. Parameters include registers,
the pointer, status bits, byte and ROM addresses, etc. The 'split' between
instruction and parameter is different for different types of instruction.
    Execution passes from ROM to ROM via the selectROM instruction, which sets
the current ROM's ROE bit low, and the new ROM's ROE bit high. Execution
continues at the next address after the selectROM instruction (now decoded
from the new ROM).
    The return address keeps a record of the byte executing the most recent
jumpSub instruction.
"""

class ROM:
    """ the ROMs of the calculator, populated with byte values from a file """    
    def __init__(self, calculator_name, rom_version, calculator_file):
        self.roms = []
        self.populateRoms(calculator_name, rom_version, calculator_file)
        self.rom_enabled = zeros(len(self.roms), int)
        self.rom_enabled[0] = 1                                 # start with ROM 0 enabled
        self.current_address = 0                                      # start at address 0
        self.next_address = 0
        self.return_address = 0

    def populateRoms(self, calculator_name, rom_version, calculator_file):
        """ read file with ROMs' contents and decode each byte into an
        instruction and associated parameters """
        try:
            with open(ospath.join(ospath.dirname(sysargv[0]),calculator_file),
                      'r', newline='', encoding="utf-8") as cf:
                    calculator = jload(cf)   
        except FileNotFoundError:
            raise SystemExit(("Sorry, but the calculator definitions file,\n"
                              f"{calculator_file}, cannot be found. It\n"
                              "should be in the same directory as the HP-1973\n"
                              "executable."))
        for each_rom in calculator[calculator_name]["rom_versions"][rom_version]["roms"]:
            self.roms.append([])
            for byte in calculator[calculator_name]["rom_versions"][rom_version]["roms"][each_rom]:
                self.roms[int(each_rom)].append(int(byte))

""" key presses
---------------
When a key is pressed on the calculator it is translated into a key code. This
key code is an address. The calculator executes a keyboard entry instruction
with and execution jumps to that address in the current ROM. (The 'shift' and
'arc' keys work by changing the ROM in which the keyboard entry instruction is
executed.)
"""

class KeyDecoder:
    """ a dictionary which links a calculator key to an address """
    def __init__(self, calculator_name, calculator_file):
        self.keycode = 0
        try:
            with open(ospath.join(ospath.dirname(sysargv[0]),calculator_file),
                      'r', newline='', encoding="utf-8") as cf:
                calculator = jload(cf)
        except FileNotFoundError:
            raise SystemExit(("Sorry, but the calculator definitions file,\n"
                              f"{calculator_file}, cannot be found. It\n"
                              "should be in the same directory as the HP-1973\n"
                              "executable."))
        self.keycodes = calculator[calculator_name]["keycodes"]

"""internal registers
---------------------
See note above about internal registers. In addition, when the calculator is
waiting for a key press, the stack is held in internal registers as follows:
T: register F
Z: register E
Y: register D
X: register C
In the HP-45, nibble 1 of register M is 0 if in FIX mode, or 1 if in SCI mode.
Nibble 2 of register M holds the associated FIX or SCI value.
"""

class InternalRegisters:
    """ an array of 7 internal registers each with 14 integer entries """
    def __init__(self):
        self.internal = zeros((7,14), int)

""" storage registers
---------------------
The HP-45 (but not the HP-35 or HP-80) has 10 'R' registers. (We set them up
for all calculators, but do not use them when not needed.) 9 of these, R1 to
R9, are accessible by the user, but the other, R0, is not. The form of each
register and associated components is the same as for internal registers.
    When the calculator is waiting for a key press, storage register 0 holds
the 'last X' value.
"""

class StorageRegisters:
    """ an array of 10 storage registers each with 14 integer entries """
    def __init__(self):
        self.storage = zeros((10,14), int)    

""" the status register
-----------------------
The status register consists of 12 bits which are set 1 (true) or 0 (false).
"""

class StatusRegister:
    """ a status register with 12 interger entries """
    def __init__(self):
        self.status = zeros(12, int)

""" pointer, components and data address
----------------------------------------
The P and WP components depend on the value of the pointer, P. (Here we update
those components when P changes. We also calculate the start and end points of
a given component.)
    On the HP-45 (but not the HP-35 or HP-80), the data address gives the
number of the storage register to be used when transferring the W component of
internal register C to a storage register, or vice versa. (We set up a data
address for all calculators, but do not use it when not needed.)
"""

class Memory(InternalRegisters, StorageRegisters, StatusRegister):
    """ combine the registers with an array defining register components and
    pointers to replicate calculator 'memory' and implement methods to manage
    components """
    def __init__(self):
        InternalRegisters.__init__(self)
        StorageRegisters.__init__(self)
        StatusRegister.__init__(self)    
        self.nibbles = [[0,0],[3,12],[0,2],[0,13],[0,0],[3,13],[2,2],[13,13]]
        self.data_address = 0
        self.pointer = 0
    
    def updateNibbles(self):
        """ update high and low nibbles for updated pointer """
        self.nibbles[c_p][0] = self.pointer
        self.nibbles[c_p][1] = self.pointer
        self.nibbles[c_wp][0] = 0
        self.nibbles[c_wp][1] = self.pointer

    def startEnd(self, params, type="slice"):
        """ given a component, return the start and end+1 nibbles as a slice or
        a range, or return just the start or end+1 nibble: end nibble has 1
        added to compensate for exclusion when used in slice or range """
        if type == "slice":
            start_end = slice(self.nibbles[params][0], self.nibbles[params][1]+1)
        elif type == "range":
            start_end = range(self.nibbles[params][0], self.nibbles[params][1]+1)
        elif type == "start":
            start_end = self.nibbles[params][0]
        elif type == "end":
            start_end = self.nibbles[params][1]+1
        return start_end

""" the display
---------------
The HP-45 display uses internal registers A & B to determine its contents.
Three methods of display decoding are implemented here. The help file for the
simulator explains this in additional detail. 
"""

class DisplayAndMemory(Memory):
    """ add display flags and methods to memory (since display is defined)
    by contents of registers) and implement method to derive display
    contents from registers """
    def __init__(self):
        Memory.__init__(self)
        self.display_enabled = 0                         # start with the display disabled

    def authDisplay(self, low_battery=False):
        """ this method copies the logic in the calculator as closely as
        possible, using bitwise processing and resulting in an array of
        segments to be lit on the display - comments are minimal but the help
        file of the simulator has a huge amount of information explaining
        this - some code is strictly unnecessary but is there to keep close to
        the calculator logic """
        regA_buffer = zeros(4, int)                   # referred to as A' in the help text
        regB_buffer = zeros(1, int)                   # referred to as B' in the help text
                                            # prepare 56-'bit' arrays of A and B registers
        regA_bits = zeros(56, int)
        regB_bits = zeros(56, int)
        for bit in range(56):
            regA_bits[bit] = self.internal[r_a][int(bit/4)] >> (bit%4) & 1
            regB_bits[bit] = self.internal[r_b][int(bit/4)] >> (bit%4) & 1
                                                                         # five data lines
        data_lines = [0,0,0,0,0]
        d_A = 0; d_B = 1; d_C = 2; d_D = 3; d_E = 4 
                                                                  # 7+1 segments per digit
        segments = zeros(8, int)
        s_a = 0; s_b = 1; s_c = 2; s_d = 3; s_e = 4; s_f = 5; s_g = 6; s_dp = 7
                         # a 15x8 array holding all the segment information for the display
        digit_segments = zeros((15, 8), int)
                 # a 'shift register' array holding 0s except for a 1 at the current digit
        cathodes = zeros(15, int)

        last_bit = 0                               # used to stop after all bits processed
        current_bit = 0                   # the bit we're processing in the current T-step
        point_flag = 0                                         # is a decimal point needed
        sign_flag = 0                                   # are we dealing with a sign digit
                                                               # intialize external pulses
        sync_pulse_falling_edge = 0                        # set at start of T4 (not used)
        start_pulse_rising_edge = 0                        # set at start of T4
        start_pulse_rising_edge = 0                        # set at start of T1
        start_pulse_falling_edge = 0                       # set at start of T1
        start_pulse_falling_edge = 0                       # set at start of T2
        is_pulse_rising_edge = 0                           # set at start of T3 (not used)
        is_pulse_rising_edge = 0                           # set at start of T4 (not used)
        i_s_pulse_falling_edge = 0                         # set at start of T4
        i_s_pulse_falling_edge = 0                         # set at start of T1
        sync_pulse_rising_edge = 0                         # set at start of T1 (not used)
        sync_pulse_rising_edge = 0                         # set at start of T2 (not used)
        sync_pulse_falling_edge = 0                        # set at start of T3 (not used)

                            # we are not looping like the calculator so we need to process
                            # the previous T4 step to get ready for our first T1 step
        match current_bit:
            case 0:
                sync_pulse_falling_edge = 0                # set at start of T4 (not used)
                start_pulse_rising_edge = 1                # set at start of T4
            case 1:
                start_pulse_rising_edge = 0                # set at start of T1
                start_pulse_falling_edge = 1               # set at start of T1
            case 2: start_pulse_falling_edge = 0           # set at start of T2
            case 11: is_pulse_rising_edge = 1              # set at start of T3 (not used)
            case 12:
                is_pulse_rising_edge = 0                   # set at start of T4 (not used)
                i_s_pulse_falling_edge = 1                 # set at start of T4
            case 13: i_s_pulse_falling_edge = 0            # set at start of T1
            case 45: sync_pulse_rising_edge = 1            # set at start of T1 (not used)
            case 46: sync_pulse_rising_edge = 0            # set at start of T2 (not used)
            case 55: sync_pulse_falling_edge = 1           # set at start of T3 (not used)

        # pre-our-loop T4 -----------------------------------------------------
                                                                            # check pulses
        if start_pulse_falling_edge == 1:
            cathodes = zeros(15,int)
            cathodes[14] = 1
        sign_flag = start_pulse_rising_edge | i_s_pulse_falling_edge
                                                                        # fill regB buffer
        regB_buffer = regB_bits[55]
                                                             # display - low battery point
        if low_battery:
            segments[s_dp] = 1
                          # display - save segments for current position and shift to next
        digit_segments = digit_segments | cathodes.reshape(-1,1)*segments
        segments = zeros(8, int)
        cathodes = roll(cathodes, 1)
        if cathodes[14] == 1:
            cathodes[14] = 0
                                                              # prepare - fill regA buffer 
        regA_buffer = \
            regA_bits[52:56] | regB_buffer | (not self.display_enabled) | sign_flag
                                     # keep sign flag high if should be showing minus sign     
        sign_flag = sign_flag & regA_bits[52] & regA_bits[55] \
                              & (not regB_buffer) & self.display_enabled
                                                       # process & display - decimal point
        if point_flag & self.display_enabled:
            data_lines [0,1,0,0,1]
            segments[s_dp] = data_lines[d_E]
            digit_segments = digit_segments | cathodes.reshape(-1,1)*segments
            cathodes = roll(cathodes, 1)
            if cathodes[14] == 1:
                cathodes[14] = 0
            segments = zeros(8, int)

        # ---------------------------------------------------------------------
                                                                              # clock tick
        regA_bits = roll(regA_bits, -1)
        regB_bits = roll(regB_bits, -1)
        current_bit = (current_bit + 1) % 56
                                                                         # external pulses
        match current_bit:
            case 0:
                sync_pulse_falling_edge = 0                # set at start of T4 (not used)
                start_pulse_rising_edge = 1                # set at start of T4
            case 1:
                start_pulse_rising_edge = 0                # set at start of T1
                start_pulse_falling_edge = 1               # set at start of T1
            case 2: start_pulse_falling_edge = 0           # set at start of T2
            case 11: is_pulse_rising_edge = 1              # set at start of T3 (not used)
            case 12:
                is_pulse_rising_edge = 0                   # set at start of T4 (not used)
                i_s_pulse_falling_edge = 1                 # set at start of T4
            case 13: i_s_pulse_falling_edge = 0            # set at start of T1
            case 45: sync_pulse_rising_edge = 1            # set at start of T1 (not used)
            case 46: sync_pulse_rising_edge = 0            # set at start of T2 (not used)
            case 55: sync_pulse_falling_edge = 1           # set at start of T3 (not used)

                                                            # the main display update loop
        while current_bit >= last_bit:
            last_bit = current_bit

            # T1 --------------------------------------------------------------
                                                                            # check pulses
            if start_pulse_falling_edge == 1:
                cathodes = zeros(15,int)
                cathodes[14] = 1
            sign_flag = sign_flag | start_pulse_rising_edge | i_s_pulse_falling_edge
                                                                        # fill regB buffer
            regB_buffer = regB_bits[55]
                                                                    # display - data lines
            match regA_buffer.tolist():
                case [0,0,0,0]: data_lines = [1,0,1,1,0]
                case [1,0,0,0]: data_lines = [0,0,1,0,0]
                case [0,1,0,0]: data_lines = [1,0,0,1,1]
                case [1,1,0,0]: data_lines = [1,0,1,0,1]
                case [0,0,1,0]: data_lines = [0,0,1,0,1]
                case [1,0,1,0]: data_lines = [1,0,1,0,1]
                case [0,1,1,0]: data_lines = [1,0,1,1,1]
                case [1,1,1,0]: data_lines = [1,0,1,0,0]
                case [0,0,0,1]: data_lines = [1,0,1,1,1]
                case [1,0,0,1]: data_lines = [1,0,1,0,1]
                case [1,1,1,1]: data_lines = [0,0,0,0,0]
                                                                    # display - minus sign
            data_lines[d_E] = data_lines[d_E] | sign_flag
                                                                  # display - anode driver
            segments[s_e] = data_lines[d_D]
            segments[s_g] = data_lines[d_E]

            # -----------------------------------------------------------------
                                                                              # clock tick
            regA_bits = roll(regA_bits, -1)
            regB_bits = roll(regB_bits, -1)
            current_bit = (current_bit + 1) % 56
                                                                         # external pulses
            match current_bit:
                case 0:
                    sync_pulse_falling_edge = 0            # set at start of T4 (not used)
                    start_pulse_rising_edge = 1            # set at start of T4
                case 1:
                    start_pulse_rising_edge = 0            # set at start of T1
                    start_pulse_falling_edge = 1           # set at start of T1
                case 2: start_pulse_falling_edge = 0       # set at start of T2
                case 11: is_pulse_rising_edge = 1          # set at start of T3 (not used)
                case 12:
                    is_pulse_rising_edge = 0               # set at start of T4 (not used)
                    i_s_pulse_falling_edge = 1             # set at start of T4
                case 13: i_s_pulse_falling_edge = 0        # set at start of T1
                case 45: sync_pulse_rising_edge = 1        # set at start of T1 (not used)
                case 46: sync_pulse_rising_edge = 0        # set at start of T2 (not used)
                case 55: sync_pulse_falling_edge = 1       # set at start of T3 (not used)

            # T2 --------------------------------------------------------------
                                                                            # check pulses
            if start_pulse_falling_edge == 1:
                cathodes = zeros(15,int)
                cathodes[14] = 1
            sign_flag = sign_flag | start_pulse_rising_edge | i_s_pulse_falling_edge
                                                                        # fill regB buffer
            regB_buffer = regB_bits[55]
                                                     # processing - set decimal point flag
            point_flag = regB_buffer
                                                                    # display - data lines
            match regA_buffer.tolist():
                case [0,0,0,0]: data_lines = [1,1,1,1,1]
                case [1,0,0,0]: data_lines = [0,1,1,0,0]
                case [0,1,0,0]: data_lines = [1,1,0,1,0]
                case [1,1,0,0]: data_lines = [1,1,1,1,0]
                case [0,0,1,0]: data_lines = [0,1,1,0,1]
                case [1,0,1,0]: data_lines = [1,0,1,1,1]
                case [0,1,1,0]: data_lines = [1,0,1,1,1]
                case [1,1,1,0]: data_lines = [1,1,1,0,0]
                case [0,0,0,1]: data_lines = [1,1,1,1,1]
                case [1,0,0,1]: data_lines = [1,1,1,1,1]
                case [1,1,1,1]: data_lines = [0,0,0,0,0]
                                                                  # display - anode driver           
            segments[s_c] = data_lines[d_C]
            segments[s_a] = data_lines[d_A]
            segments[s_d] = data_lines[d_D]
            segments[s_f] = data_lines[d_E]

            # -----------------------------------------------------------------
                                                                              # clock tick
            regA_bits = roll(regA_bits, -1)
            regB_bits = roll(regB_bits, -1)
            current_bit = (current_bit + 1) % 56
                                                                         # external pulses
            match current_bit:
                case 0:
                    sync_pulse_falling_edge = 0            # set at start of T4 (not used)
                    start_pulse_rising_edge = 1            # set at start of T4
                case 1:
                    start_pulse_rising_edge = 0            # set at start of T1
                    start_pulse_falling_edge = 1           # set at start of T1
                case 2: start_pulse_falling_edge = 0       # set at start of T2
                case 11: is_pulse_rising_edge = 1          # set at start of T3 (not used)
                case 12:
                    is_pulse_rising_edge = 0               # set at start of T4 (not used)
                    i_s_pulse_falling_edge = 1             # set at start of T4
                case 13: i_s_pulse_falling_edge = 0        # set at start of T1
                case 45: sync_pulse_rising_edge = 1        # set at start of T1 (not used)
                case 46: sync_pulse_rising_edge = 0        # set at start of T2 (not used)
                case 55: sync_pulse_falling_edge = 1       # set at start of T3 (not used)

            # T3 --------------------------------------------------------------
                                                                            # check pulses
            if start_pulse_falling_edge == 1:
                cathodes = zeros(15,int)
                cathodes[14] = 1
            sign_flag = sign_flag | start_pulse_rising_edge | i_s_pulse_falling_edge
                                                                        # fill regB buffer
            regB_buffer = regB_bits[55]
                                                                    # display - data lines
            match regA_buffer.tolist():
                case [0,0,0,0]: data_lines = [0,1,1,0,0]
                case [1,0,0,0]: data_lines = [0,1,1,0,0]
                case [0,1,0,0]: data_lines = [0,1,0,0,0]
                case [1,1,0,0]: data_lines = [0,1,1,0,0]
                case [0,0,1,0]: data_lines = [0,1,1,0,0]
                case [1,0,1,0]: data_lines = [0,0,1,0,0]
                case [0,1,1,0]: data_lines = [0,0,0,0,0]
                case [1,1,1,0]: data_lines = [0,1,1,0,0]
                case [0,0,0,1]: data_lines = [0,1,1,0,0]
                case [1,0,0,1]: data_lines = [0,1,1,0,0]
                case [1,1,1,1]: data_lines = [0,0,0,0,0]
                                                                  # display - anode driver
            segments[s_b] = data_lines[d_B]

            # -----------------------------------------------------------------
                                                                              # clock tick
            regA_bits = roll(regA_bits, -1)
            regB_bits = roll(regB_bits, -1)
            current_bit = (current_bit + 1) % 56
                                                                         # external pulses
            match current_bit:
                case 0:
                    sync_pulse_falling_edge = 0            # set at start of T4 (not used)
                    start_pulse_rising_edge = 1            # set at start of T4
                case 1:
                    start_pulse_rising_edge = 0            # set at start of T1
                    start_pulse_falling_edge = 1           # set at start of T1
                case 2: start_pulse_falling_edge = 0       # set at start of T2
                case 11: is_pulse_rising_edge = 1          # set at start of T3 (not used)
                case 12:
                    is_pulse_rising_edge = 0               # set at start of T4 (not used)
                    i_s_pulse_falling_edge = 1             # set at start of T4
                case 13: i_s_pulse_falling_edge = 0        # set at start of T1
                case 45: sync_pulse_rising_edge = 1        # set at start of T1 (not used)
                case 46: sync_pulse_rising_edge = 0        # set at start of T2 (not used)
                case 55: sync_pulse_falling_edge = 1       # set at start of T3 (not used)

            # T4 --------------------------------------------------------------
                                                                            # check pulses
            if start_pulse_falling_edge == 1:
                cathodes = zeros(15,int)
                cathodes[14] = 1
            sign_flag = start_pulse_rising_edge | i_s_pulse_falling_edge
                                                                        # fill regB buffer
            regB_buffer = regB_bits[55]
                                                             # display - low battery point
            if low_battery:
                segments[s_dp] = 1
                          # display - save segments for current position and shift to next
            digit_segments = digit_segments | cathodes.reshape(-1,1)*segments
            segments = zeros(8, int)
            cathodes = roll(cathodes, 1)
            if cathodes[14] == 1:
                cathodes[14] = 0
                                                              # prepare - fill regA buffer 
            regA_buffer = \
                regA_bits[52:56] | regB_buffer | (not self.display_enabled) | sign_flag
                                     # keep sign flag high if should be showing minus sign     
            sign_flag = sign_flag & regA_bits[52] & regA_bits[55] \
                                  & (not regB_buffer) & self.display_enabled
                                                       # process & display - decimal point
            if point_flag & self.display_enabled:
                data_lines = [0,1,0,0,1]
                segments[s_dp] = data_lines[d_E]
                digit_segments = digit_segments | cathodes.reshape(-1,1)*segments
                cathodes = roll(cathodes, 1)
                if cathodes[14] == 1:
                    cathodes[14] = 0
                segments = zeros(8, int)

            # -----------------------------------------------------------------
                                                                              # clock tick
            regA_bits = roll(regA_bits, -1)
            regB_bits = roll(regB_bits, -1)
            current_bit = (current_bit + 1) % 56
                                                                         # external pulses
            match current_bit:
                case 0:
                    sync_pulse_falling_edge = 0          # set at start of T4
                    start_pulse_rising_edge = 1          # set at start of T4
                case 1:
                    start_pulse_rising_edge = 0          # set at start of T1
                    start_pulse_falling_edge = 1         # set at start of T1
                case 2: start_pulse_falling_edge = 0     # set at start of T2
                case 11: is_pulse_rising_edge = 1        # set at start of T3
                case 12:
                    is_pulse_rising_edge = 0             # set at start of T4
                    i_s_pulse_falling_edge = 1           # set at start of T4
                case 13: i_s_pulse_falling_edge = 0      # set at start of T1
                case 45: sync_pulse_rising_edge = 1      # set at start of T1
                case 46: sync_pulse_rising_edge = 0      # set at start of T2
                case 55: sync_pulse_falling_edge = 1     # set at start of T3

        return digit_segments

    def fastDisplay(self):
        """ this method replaces the output of the authDisplay method, but as
        a display string rather than a digit/segment array """
        display = [" "," "," "," "," "," "," "," "," "," "," "," "," "," "," "]
        digit = 15
        nibble = 13
        if self.display_enabled == 1:
            if self.internal[r_a][nibble] == 9 \
                                    and (self.internal[r_b][nibble] & 8) != 8:
                display[15-digit] = "-"
            digit = 1
            for nibble in range(0,13):     
                if digit != 15:
                    if (self.internal[r_b][nibble] & 8) == 8:
                        digit += 1
                    else:
                        if (self.internal[r_b][nibble] & 2) == 2:
                            display[15-digit] = "."
                            digit += 1
                        if digit != 15:
                            if nibble == 2:
                                if self.internal[r_a][nibble] == 9:
                                    display[15-digit] = "-"
                            else:
                                display[15-digit] = f"{self.internal[r_a][nibble]}"
                            digit += 1
            if digit == 14 and self.internal[r_b][13] == 2:
                display[1] = "."
        return ''.join(display)
    
    def approxDisplay(self):
        """ this method is a less accurate representation of the calculator's
        processing - normal results will be displayed correctly but interim
        garbage screens, as seen on the HP-80, will not """
        display = [" "," "," "," "," "," "," "," "," "," "," "," "," "," "," "]
        point_step = 0
        if self.display_enabled == 1:
            for digit, nibble in enumerate(range(14)[::-1]):
                if (self.internal[r_b][nibble] & 8) != 8:
                    if nibble in (2,13):
                        if self.internal[r_a][nibble] == 9:
                            display[digit+point_step] = "-"
                    else:
                        display[digit+point_step] = f"{self.internal[r_a][nibble]}"
                    if (self.internal[r_b][nibble] & 2) == 2:
                        point_step = 1
                        display[digit+point_step] = "."
        return ''.join(display)
    
""" carry
---------
The carry bit is set high if an instruction results in a carry, or if a condition tests
false. Otherwise it is set low. A branch instruction will not execute if the carry bit is
high.
"""

class Flags:
    """ set up flag to represent carry flag """
    def __init__(self):
        self.carry = 0

""" decoding a byte
-------------------
The byte content of each address is decoded when that address is ready to be executed.
This is done rather than decoding everything before beginning calculator operations
because it is closer to the working of the calculators themselves, and allows for the ROE
to 'AND' with the byte values from each of the ROMs, thus selecting the correct byte value
for execution.
    Decoding the byte contents is a combination of logical and shift operations to
determine the instruction and parameters encoded by that byte.
"""

class ByteDecoder:
    "decode a byte into an instruction and parameters"

    def decodeByte(self, byte_value):
        """returns a tuple of one string and one list of integers representing
        (instruction, [parameters])"""
        if (byte_value & 1) == 1:
            instruction = (2 & byte_value) >> 1
            parameters = (1020 & byte_value) >> 2
            match instruction:
                case 0: decoded_byte = ("jumpSub", [parameters])
                case 1: decoded_byte = ("goTo", [parameters])
        elif (byte_value & 3) == 2:
            instruction = (992 & byte_value) >> 5
            parameters = (28 & byte_value) >> 2
            match instruction:
                case 0: decoded_byte = ("ifRegZero", [r_b, parameters])
                case 1: decoded_byte = ("clearReg", [r_b, parameters])
                case 2: decoded_byte = ("ifRegReg", [r_a, r_c, parameters])
                case 3: decoded_byte = ("ifRegOne", [r_c, parameters])
                case 4: decoded_byte = ("copyReg", [r_b, r_c, parameters])
                case 5: decoded_byte = ("negReg", [r_c, parameters])
                case 6: decoded_byte = ("clearReg", [r_c, parameters])
                case 7: decoded_byte = ("negDecReg", [r_c, parameters])
                case 8: decoded_byte = ("lShiftReg", [r_a, parameters])
                case 9: decoded_byte = ("copyReg", [r_a, r_b, parameters])
                case 10: decoded_byte = ("subRegs", [r_a, r_c, r_c, parameters])
                case 11: decoded_byte = ("decReg", [r_c, parameters])
                case 12: decoded_byte = ("copyReg", [r_c, r_a, parameters])
                case 13: decoded_byte = ("ifRegZero", [r_c, parameters])
                case 14: decoded_byte = ("addRegs", [r_a, r_c, r_c, parameters])
                case 15: decoded_byte = ("incReg", [r_c, parameters])
                case 16: decoded_byte = ("ifRegReg", [r_a, r_b, parameters])
                case 17: decoded_byte = ("exchangeRegs", [r_b, r_c, parameters])
                case 18: decoded_byte = ("rShiftReg", [r_c, parameters])
                case 19: decoded_byte = ("ifRegOne", [r_a, parameters])
                case 20: decoded_byte = ("rShiftReg", [r_b, parameters])
                case 21: decoded_byte = ("addRegs", [r_c, r_c, r_c, parameters])
                case 22: decoded_byte = ("rShiftReg", [r_a, parameters])
                case 23: decoded_byte = ("clearReg", [r_a, parameters])
                case 24: decoded_byte = ("subRegs", [r_a, r_b, r_a, parameters])
                case 25: decoded_byte = ("exchangeRegs", [r_a, r_b, parameters])
                case 26: decoded_byte = ("subRegs", [r_a, r_c, r_a, parameters])
                case 27: decoded_byte = ("decReg", [r_a, parameters])
                case 28: decoded_byte = ("addRegs", [r_a, r_b, r_a, parameters])
                case 29: decoded_byte = ("exchangeRegs", [r_a, r_c, parameters])
                case 30: decoded_byte = ("addRegs", [r_a, r_c, r_a, parameters])
                case 31: decoded_byte = ("incReg", [r_a, parameters])
        elif (byte_value & 15) == 4 :
            instruction = (48 & byte_value) >> 4
            parameters = (960 & byte_value) >> 6
            match instruction:
                case 0: decoded_byte = ("setStatus", [parameters])
                case 1: decoded_byte = ("ifSBitZero", [parameters])
                case 2: decoded_byte = ("clearStatus", [parameters])
                case 3: decoded_byte = ("clearAllStatus", [])
        elif (byte_value & 15) == 12 :
            instruction = (48 & byte_value) >> 4
            parameters = (960 & byte_value) >> 6
            match instruction:
                case 0: decoded_byte = ("setP", [parameters])
                case 1: decoded_byte = ("decP", [])
                case 2: decoded_byte = ("ifPNotValue", [parameters])
                case 3: decoded_byte = ("incP", [])
        elif (byte_value & 63) == 16 :
            instruction = (64 & byte_value) >> 6
            parameters = (896 & byte_value) >> 7
            match instruction:
                case 0: decoded_byte = ("selectRom", [parameters])
                case 1: decoded_byte = ("keyGoTo", [])
        elif (byte_value & 63) == 24 :
            instruction = 0
            parameters = (960 & byte_value) >> 6
            decoded_byte = ("loadConstant", [parameters])
        elif (byte_value & 1023) == 0 :
            instruction = 0
            parameters = 0
            decoded_byte = ("nOp", [])
        elif (byte_value & 7) == 0:
            instruction = (1016 & byte_value) >> 3
            parameters = 0
            match instruction:
                case 5: decoded_byte = ("displayToggle", [])
                case 6: decoded_byte = ("ret", [])
                case 21: decoded_byte = ("exchangeRegs", [r_c, r_m, c_w])
                case 37: decoded_byte = ("pushC", [])
                case 53: decoded_byte = ("popA", [])
                case 69: decoded_byte = ("displayOff", [])
                case 78: decoded_byte = ("setDataAddress", [])
                case 85: decoded_byte = ("copyReg", [r_m, r_c, c_w])
                case 94: decoded_byte = ("cToData", [])
                case 95: decoded_byte = ("dataToC", [])
                case 101: decoded_byte = ("rotateDown", [])
                case 117: decoded_byte = ("clearAllRegs", [])
        return decoded_byte

"""the processor 
----------------
The processor combines all the above parts of the calculator together with a
set of methods each of which executes one type of calculator instruction.
"""

class Processor(ROM, KeyDecoder, DisplayAndMemory, Flags, ByteDecoder):
    """ combine ROMs, keys, display, memory, carry flag and byte decoder with
    methods covering each calculator instruction """
    def __init__(self, calculator_name, rom_version, calculator_file):
        ROM.__init__(self, calculator_name, rom_version, calculator_file)
        KeyDecoder.__init__(self, calculator_name, calculator_file)
        DisplayAndMemory.__init__(self)
        Flags.__init__(self)
                                     # this flag is a hook for a minimal calculator
                                     # implementation and isn't used in the main simulator
        self.display_and_input = False
                                     # end of intercept flag

               # pointer operations ------------------------------------------------------ 

    def setP(self, params):
        """ store value in pointer -- implements VALUE -> P """
        self.pointer = params[0]
        self.updateNibbles()
        self.carry = 0

    def incP(self, params):
        """ increment pointer -- implements INCREMENT P """
        self.pointer = (self.pointer + 1) & 15                   # loop back to 0 after 15
        self.updateNibbles()
        self.carry = 0
    
    def decP(self, params):
        """ decrement pointer -- implements DECREMENT P """
        self.pointer = (self.pointer - 1) & 15                  # loop back to 15 after 0
        self.updateNibbles()
        self.carry = 0

    def ifPNotValue(self, params):
        """ compare pointer to value and set last_true to true if not equal,
        else false -- implements IF P != VALUE """
        if self.pointer != params[0]:
            self.carry = 0
        else:
            self.carry = 1

               # register operations -----------------------------------------------------

    def clearAllRegs(self, params):
        """ clear all components of all internal regs -- implements
        CLEAR REGISTERS (not used in HP-45) """
        self.internal.fill(0)
        self.carry = 0

    def clearReg(self, params):
        """ clear component of int reg -- implements CLEAR A or CLEAR B
        or CLEAR C """
        reg = params[0]
        start_end = self.startEnd(params[1])
        self.internal[reg][start_end] = 0
        self.carry = 0

    def copyReg(self, params):
        """ copy component of int reg 1 to int reg 2 -- implements A -> B or
        B -> C or C -> A or M -> C """
        reg_1 = params[0]
        reg_2 = params[1]
        start_end = self.startEnd(params[2])
        self.internal[reg_2][start_end] = self.internal[reg_1][start_end]
        self.carry = 0

    def exchangeRegs(self, params):
        """ exchange component of int reg 1 and int reg 2 -- implements
        EXCHANGE A B or EXCHANGE A C or EXCHANGE B C or EXCHANGE C M """
        reg_1 = params[0]
        reg_2 = params[1]
        start_end = self.startEnd(params[2])
        self.internal[reg_1][start_end], self.internal[reg_2][start_end] \
                    = self.internal[reg_2][start_end], \
                        self.internal[reg_1][start_end].copy()
        self.carry = 0

    def addRegs(self, params):
        """ add component of int reg 1 to int reg 2 and store result in
        int reg 3 -- implements A + B -> A or A + C -> A or A + C -> C or
        C + C -> C """
        self.carry = 0
        reg_1 = params[0]
        reg_2 = params[1]
        reg_3 = params[2]
        start_end = self.startEnd(params[3], "range")
        for nibble in start_end:
            self.internal[reg_3][nibble] = (self.internal[reg_1][nibble] 
                                + self.internal[reg_2][nibble] + self.carry)
            if self.internal[reg_3][nibble] >= 10:
                self.internal[reg_3][nibble] -= 10
                self.carry = 1
            else:
                self.carry = 0

    def subRegs(self, params):
        """ subtract component of int reg 2 from int reg 1 and store result in
        int reg 3 -- implements A - B -> A or A - C -> A or A - C -> C """
        self.carry = 0
        reg_1 = params[0]
        reg_2 = params[1]
        reg_3 = params[2]
        start_end = self.startEnd(params[3], "range")
        for nibble in start_end:
            self.internal[reg_3][nibble] = (self.internal[reg_1][nibble]
                                - self.internal[reg_2][nibble] - self.carry)
            if self.internal[reg_3][nibble] < 0:
                self.internal[reg_3][nibble] += 10
                self.carry = 1
            else:
                self.carry = 0

    def incReg(self, params):
        """ increment component of int reg -- implements INCREMENT A or
        INCREMENT C """
        self.carry = 1
        reg = params[0]
        start = self.startEnd(params[1], "start")
        end = self.startEnd(params[1], "end")
        nibble = start
        while self.carry == 1 and nibble < end:
            self.internal[reg][nibble] += self.carry
            if self.internal[reg][nibble] == 10:
                self.internal[reg][nibble] = 0
            else:
                self.carry = 0
            nibble += 1

    def decReg(self, params):
        """ decrement component of int reg -- implements DECREMENT A
        or DECREMENT C """
        self.carry = 1
        reg = params[0]
        start = self.startEnd(params[1], "start")
        end = self.startEnd(params[1], "end")
        nibble = start
        while self.carry == 1 and nibble < end:
            self.internal[reg][nibble] -= self.carry
            if self.internal[reg][nibble] == -1:
                self.internal[reg][nibble] = 9
            else:
                self.carry = 0
            nibble += 1

    def negReg(self, params):
        """ negate component of int reg (ten's complement) -- implements
        0 - C -> C """
        self.carry = 0
        reg = params[0]
        start_end = self.startEnd(params[1], "range")
        for nibble in start_end:
            self.internal[reg][nibble] = 0 - self.internal[reg][nibble] - self.carry
            if self.internal[reg][nibble] < 0:
                self.internal[reg][nibble] += 10
                self.carry = 1
            else:
                self.carry = 0

    def negDecReg(self, params):
        """ negate and decrement component of int reg (nine's complement) --
        implements 0 - C - 1 -> C """
        reg = params[0]
        start_end = self.startEnd(params[1], "range")
        for nibble in start_end:
            self.internal[reg][nibble] = 9 - self.internal[reg][nibble]
        self.carry = 0

    def rShiftReg(self, params):
        """ shift component of int reg to right -- implements RIGHTSHIFT A or 
        RIGHTSHIFT B or RIGHTSHIFT C (note that this Python code shifts to left
        because actual HP-45 index runs left (0) to right (13) """
        reg = params[0]
        start_end = self.startEnd(params[1])
        end = self.startEnd(params[1], "end")
        self.internal[reg][start_end] = roll(self.internal[reg][start_end], -1)
        self.internal[reg][end-1] = 0
        self.carry = 0

    def lShiftReg(self, params):
        """ shift component of int reg to left -- implements LEFTSHIFT A 
        (note that this Python code shifts to right because actual HP-45 index
        runs left (0) to right (13) """
        reg = params[0]
        start_end = self.startEnd(params[1])
        start = self.startEnd(params[1], "start")
        self.internal[reg][start_end] = roll(self.internal[reg][start_end], 1)
        self.internal[reg][start] = 0
        self.carry = 0

    def ifRegZero(self, params):
        """ set last_true to true if component of int reg = 0, else false \ 
        implements IF B = 0 or IF C = 0 """
        reg = params[0]
        start_end = self.startEnd(params[1])
        if any(self.internal[reg][start_end]):
            self.carry = 1
        else:
            self.carry = 0

    def ifRegReg(self, params):
        """ compare component of int reg 1 to int reg 2 and set last_true to
        true if 1 >= 2, else false -- implements IF A >= B or IF A >= C """
        reg_1 = params[0]
        reg_2 = params[1]
        start_end = self.startEnd(params[2])
        reg_1_flipped_component = flip(self.internal[reg_1][start_end])
        reg_2_flipped_component = flip(self.internal[reg_2][start_end])
        reg_int_1 = int(array2string(reg_1_flipped_component,
                                                        separator='')[1:-1])
        reg_int_2 = int(array2string(reg_2_flipped_component,
                                                        separator='')[1:-1])
        if reg_int_1 < reg_int_2:
            self.carry = 1
        else:
            self.carry = 0

    def ifRegOne(self, params):
        """ set last_true to true if component of int reg >= 1, else false --
        implements IF A >= 1 or IF C >= 1 """
        reg = params[0]
        start_end = self.startEnd(params[1])
        if not any(self.internal[reg][start_end]):
            self.carry = 1
        else:
            self.carry = 0

    def pushC(self, params):
        """ push int reg C onto stack (E->F, D->E, C->D) using whole word
        component -- implements C -> STACK """
        self.internal[r_f] = self.internal[r_e]
        self.internal[r_e] = self.internal[r_d]
        self.internal[r_d] = self.internal[r_c]
        self.carry = 0

    def popA(self, params):
        """ pop stack into int reg A (D->A, E->D, F->E) using whole word
        component -- implements STACK -> A """
        self.internal[r_a] = self.internal[r_d]
        self.internal[r_d] = self.internal[r_e]
        self.internal[r_e] = self.internal[r_f]
        self.carry = 0

    def rotateDown(self, params):
        """ rotate down (D->C, E->D, F->E and original C->F) using whole word
        component -- implements ROTATEDOWN (note rotate direction is 'down'
        because of the way internal regs act as the user stack"""
        self.internal[r_c:r_f+1] = \
                            roll(self.internal[r_c:r_f+1], -1, axis=0)
        self.carry = 0

    def loadConstant(self, params):
        """ load constant value to int reg C nibble at pointer and decrement
        pointer -- implements LOADCONSTANT """
        value = params[0]
        if (self.pointer < 14):
            self.internal[r_c][self.pointer] = value
        self.decP([])
        self.carry = 0

               # status operations -------------------------------------------------------

    def clearAllStatus(self, params):
        """ set all status bits to false -- implements CLEAR ALL STATUSBITS """
        self.status.fill(0)
        self.carry = 0

    def clearStatus(self, params):
        """ set status bit to false -- implements CLEAR STATUSBIT """
        bit = params[0]
        self.status[bit] = 0
        self.carry = 0

    def setStatus(self, params):
        """ set status bit to true -- implements SET STATUSBIT """
        bit = params[0]
        self.status[bit] = 1
        self.carry = 0

    def ifSBitZero(self, params):
        """ set last_true to true if status bit is false, else set last_true
        to false -- implements IF STATUSBIT !=1 """
        bit = params[0]
        self.carry = self.status[bit]
                                     # this intercept is a hook for a minimal calculator
                                     # implementation and isn't used in the main simulator
        if bit == 0 and self.status[8] == True:
            self.display_and_input = True
                                     # end of intercept

               # data/storage operations -------------------------------------------------

    def setDataAddress(self, params):
        """ use int reg C nibble 12 to set data address for read/write --
        implements C -> DATAADDRESS """
        self.data_address = self.internal[r_c][12]
        self.carry = 0

    def dataToC(self, params):
        """ read storage reg at current data address into int reg c using
        whole word component -- implements DATA -> C """
        self.internal[r_c] = self.storage[self.data_address]
        self.carry = 0

    def cToData(self, params):
        """ write int reg C into storage reg at current data address using
        whole word component -- implements C -> DATA """
        self.storage[self.data_address] = self.internal[r_c]
        self.carry = 0

               # flow operations ---------------------------------------------------------

    def selectRom(self, params):
        """ select rom to use -- implements SELECTROM """
        self.rom_enabled.fill(0)
        self.rom_enabled[params[0]] = 1
        self.carry = 0

    def goTo(self, params):
        """ set new current byte location after checking carry and last_true --
        implements GOTO """
        if self.carry == 0:
            self.next_address = params[0]
        self.carry = 0

    def jumpSub(self, params):
        """ set new current byte location and store jump-from location --
        implements JUMPSUB """
        self.return_address = (self.current_address + 1) % 256
        self.next_address = params[0]
        self.carry = 0

    def keyGoTo(self, params):
        """ goto location of current keycode in current rom -- implements
        KEYS -> ROMADDRESS """
        self.next_address = self.keycode
        self.carry = 0
    
    def ret(self, params):
        """ set new current byte location to location after last jumpsub
        instruction -- implements RETURN """
        self.next_address = self.return_address
        self.carry = 0

               # display operations ------------------------------------------------------

    def displayOff(self, params):
        """ turn display off -- implements DISPLAYOFF """
        self.display_enabled = 0
        self.carry = 0

    def displayToggle(self, params):
        """ toggle display on/off -- implements DISPLAYTOGGLE """
        self.display_enabled = (self.display_enabled + 1) % 2
        self.carry = 0

               # nop operation -----------------------------------------------------------

    def nOp(self, params):
        """ no operation - do nothing and continue -- implements NOP """
        self.carry = 0

""" the calculator
------------------
Running the processor involves (1) decoding the byte content of the current
address in the ROM eneabled by the ROE, (2) executing the instruction with its
parameters and updating the state of the calculator accordingly, (3) pointing
to the next address (in a new ROM if a ROM select instruction has been
executed). Repeat. If the instruction has not set a specific next address then
the next address is the taken to be the current address + 1. If incrementing
the address exceeds the last address available (255), execution loops back to
address 0.
"""

class Calculator(Processor):
    """ create a full calculator by taking the processor and adding a method
    which calls the method with the same name as the instruction at the 
    current byte, passing it the parameters required, and then pointing to the
    next byte for execution """
    def __init__(self, calculator_name, rom_version, calculator_file):
        Processor.__init__(self, calculator_name, rom_version, calculator_file)
        self.power_on = 1                                    # the calculator is turned on

    def processByte(self):
        """ process byte"""
        if self.power_on:
            self.current_address = self.next_address      # move execution to next address
            byte_value = 0
            for number, rom in enumerate(self.roms): # select byte contents of enabled ROM
                byte_value += self.rom_enabled[number] * rom[self.current_address]
            decoded_byte = self.decodeByte(byte_value)          # decode the byte contents
            instruction = decoded_byte[0]
            parameters = decoded_byte[1]
            function_call = getattr(self, instruction)       # identify the method to call
            function_call(parameters)       # call that method/instruction with parameters
            if self.next_address == self.current_address:      # if no new next address...
                self.next_address = (self.current_address + 1) % 256      # ...set default

    def powerSwitch(self, switch_position):
        """ turn the calculator on and off """
        self.power_on = switch_position
        if switch_position == 0:
            self.rom_enabled.fill(0)
            self.rom_enabled[0] = 1
            self.current_address = 0
            self.next_address = 0
            self.return_address = 0
            self.keycode = 0
            self.internal.fill(0)
            self.storage.fill(0)
            self.status.fill(0)
            self.data_address = 0
            self.pointer = 0
            self.display_enabled = 0
            self.carry = 0





# ----------------------------------------------------------------------------------------
#  GUI : an interface to the calculator which shows additional information and allows for
#        a deeper understanding of its processing
#        the code has been designed to separate the core calculator from the interface
#        additions: this is not the most efficient way to proceed, and leads to some
#        code repetition, but it allows for a minimal gui interface to be written in a
#        few lines, and a calculator can be instantiated with no additional 'cruft' built
#        into it
#-----------------------------------------------------------------------------------------

                   # the following 4 lines are required for the standalone Windows version
                   # so that tcl and tk can be found within the included embedded Python
                   # distribution: they are not needed if executing under a full Python
                   # installation, but must be uncommented for use with the embedded
                   # standalone Windows version
                                                                                   # start
if platformName() == "Windows":
    from os import environ as osenviron
    osenviron['TCL_LIBRARY'] = "tcl8.6"
    osenviron['TK_LIBRARY'] = "tk8.6"
                                                                                     # end

from numpy import dot
from time import sleep
from json import load as jload
import tkinter as tk

class AugmentedCalculator(Calculator):
    """ a 'wrapper' for the calculator which adds variables, and methods used
    by the simulator to show additional information and provide extra (non-
    calculator) functionality """
    def __init__(self, calculator_name, rom_version, definitions, calc_file):
        """ bring together the calculator and additional variables and methods """
                                                          # initialise the core calculator    
        Calculator.__init__(self, calculator_name, rom_version, calc_file)
               # variables which hold calc state prior to execution of current instruction
        self.ac_last_address = 0 
        self.ac_last_short_instruction = ""
        self.ac_last_parameters = [0,0,0,0]
        self.ac_last_display_enabled = False
        self.ac_last_internal = zeros((7,14), int)
        self.ac_last_storage = zeros((10,14), int)
        self.ac_last_status = zeros(12, int)
        self.ac_last_rom_enabled = zeros(len(self.rom_enabled), int)
        self.ac_last_rom_enabled[0] = 1
        self.ac_last_return_address = 0
        self.ac_last_pointer = 0
        self.ac_last_data_address = 0
        self.ac_last_carry = 0
        definition = definitions[calculator_name]  # limit definition to chosen calculator
        self.ac_roms = self.ac_PopulateACROMS(definition, rom_version) # decoded ROM array
                         # calculator and rom details and rom hash checks, in a dictionary
        self.ac_information_dict = definition["rom_versions"][rom_version]["info_dict"]
        self.ac_name = calculator_name                          # short name of calculator
                                                # does the selected ROM contain known bugs
        self.ac_known_bugs = self.ac_information_dict["known_bugs"]
                                    # flags idenitifying capabilities of chosen calculator
        self.ac_shift_status_bit = definition["info"]["shift_status_bit"]
        self.ac_shift_key_text = definition["info"]["shift_key_text"]
        self.ac_fix_sci_support = definition["info"]["fix_sci_support"]
        self.ac_storage_support = definition["info"]["storage_support"]
        self.ac_lastx_support = definition["info"]["lastx_support"]
        self.ac_deg_rad_gra_support = definition["info"]["deg_rad_gra_support"]
        self.ac_data_address_support = definition["info"]["data_address_support"]
        self.ac_display_garbage = definition["info"]["display_garbage"]
        self.ac_m_register_sci = definition["info"]["m_register_sci"]
                                # details of key-wait loop locations for chosen calculator
        self.ac_calc_info_flags = [self.ac_shift_status_bit,   # used in setting calc info
                                   self.ac_shift_key_text,
                                   self.ac_fix_sci_support,
                                   self.ac_deg_rad_gra_support]
        self.ac_kl_rom = definition["keyloop"]["keyloop_rom"]
        self.ac_kl_start_address = definition["keyloop"]["keyloop_start_address"]
        self.ac_kl_exit_address = definition["keyloop"]["keyloop_exit_address"]
        try:
            self.ac_tl_rom = definition["keyloop"]["timerloop_rom"]
            self.ac_tl_start_address = definition["keyloop"]["timerloop_start_address"]
            self.ac_tl_exit_address = definition["keyloop"]["timerloop_exit_address"]
        except:
            self.ac_tl_rom = 999
            self.ac_tl_start_address = 999
            self.ac_tl_exit_address = 999
                                                       # various properties of chosen ROMs
        self.ac_rom_count = len(self.rom_enabled)
        self.ac_rom_numbers = range(self.ac_rom_count)
        self.ac_rom_byte_count = len(self.ac_roms[0])
        self.ac_total_byte_count = self.ac_rom_count * self.ac_rom_byte_count
                                              # current and next ROM: used rather than ROE
        self.ac_current_rom = 0
        self.ac_next_rom = 0

    def ac_PopulateACROMS(self, definition, rom_version):
        """ create an array filled with ROM contents which is already decoded
        into instruction, readable instruction and parameters, and adds
        subroutine names for addresses """
                              # each raw byte is converted into:
                              # raw byte, long instruction, parameters, short instruction,
                              #                               byte routine, branch routine
                              # '>' at the start of long instruction shifts right in list
                              # '$' is replaced with parameter padded with spaces
                              # '@' is replaced with parameter, no padding
                              # '#' is replaced with parameter padded with zeroes
        decoded_roms = []
        for each_rom in definition["rom_versions"][rom_version]["roms"]:
            decoded_roms.append([])
            for byte in definition["rom_versions"][rom_version]["roms"][each_rom]:
                decoded_roms[int(each_rom)].append([int(byte),"",[],"","",""])
        components = ("P","M","X","W","WP","MS","XS","S")
        label_dict = definition["rom_versions"][rom_version]["subroutines"]
        for rom_number, rom in enumerate(decoded_roms):
            for byte_number, byte in enumerate(rom):
                raw_byte = byte[0]
                                             # add subroutine label for address, if exists
                label = label_dict.get(f"{rom_number}{byte_number:>03}", "")
                byte[4] = f"{label[:6]}"
                if (raw_byte & 1) == 1:
                    instruction = (2 & raw_byte) >> 1
                    parameters = (1020 & raw_byte) >> 2
                                                 # add subroutine label for branch address
                    subroutine = label_dict.get(f"{rom_number}{parameters:>03}", "")
                    byte[5] = f"{subroutine[:6]}"
                    match instruction:
                        case 0: byte[1:4] = [">jumpsub @",[parameters], "jumpSub"]
                        case 1: byte[1:4] = [">   goto @",[parameters], "goTo"]
                elif (raw_byte & 3) == 2:
                    instruction = (992 & raw_byte) >> 5
                    parameters = (28 & raw_byte) >> 2
                    parameters = components[parameters]
                    match instruction:
                        case 0: byte[1:4] = [">0 ≥ B[$]", [parameters], "ifRegZero"]
                        case 1: byte[1:4] = ["0 -----> B[$]", [parameters], "clearReg"]
                        case 2: byte[1:4] = [">A ≥ C[$]", [parameters], "ifRegReg"]
                        case 3: byte[1:4] = [">C[$] ≥ 1", [parameters], "ifRegOne"]
                        case 4: byte[1:4] = ["B -----> C[$]", [parameters], "copyReg"]
                        case 5: byte[1:4] = ["0 - C -> C[$]", [parameters], "negReg"]
                        case 6: byte[1:4] = ["0 -----> C[$]", [parameters], "clearReg"]
                        case 7: byte[1:4] = ["0-C-1 -> C[$]", [parameters], "negDecReg"]
                        case 8: byte[1:4] = ["shft A[$] lft", [parameters], "lShiftReg"]
                        case 9: byte[1:4] = ["A -----> B[$]", [parameters], "copyReg"]
                        case 10: byte[1:4] = ["A - C -> C[$]", [parameters], "subRegs"]
                        case 11: byte[1:4] = ["C - 1 -> C[$]", [parameters], "decReg"]
                        case 12: byte[1:4] = ["C -----> A[$]", [parameters], "copyReg"]
                        case 13: byte[1:4] = [">0 ≥ C[$]", [parameters], "ifRegZero"]
                        case 14: byte[1:4] = ["A + C -> C[$]", [parameters], "addRegs"]
                        case 15: byte[1:4] = ["C + 1 -> C[$]", [parameters], "incReg"]
                        case 16: byte[1:4] = [">A ≥ B[$]", [parameters], "ifRegReg"]
                        case 17: byte[1:4] = ["B <----> C[$]", [parameters], "exchangeRegs"]
                        case 18: byte[1:4] = ["shft C[$] rgt", [parameters], "rShiftReg"]
                        case 19: byte[1:4] = [">A[$] ≥ 1", [parameters], "ifRegOne"]
                        case 20: byte[1:4] = ["shft B[$] rgt", [parameters], "rShiftReg"]
                        case 21: byte[1:4] = ["C + C -> C[$]", [parameters], "addRegs"]
                        case 22: byte[1:4] = ["shft A[$] rgt", [parameters], "rShiftReg"]
                        case 23: byte[1:4] = ["0 -----> A[$]", [parameters], "clearReg"]
                        case 24: byte[1:4] = ["A - B -> A[$]", [parameters], "subRegs"]
                        case 25: byte[1:4] = ["A <----> B[$]", [parameters], "exchangeRegs"]
                        case 26: byte[1:4] = ["A - C -> A[$]", [parameters], "subRegs"]
                        case 27: byte[1:4] = ["A - 1 -> A[$]", [parameters], "decReg"]
                        case 28: byte[1:4] = ["A + B -> A[$]", [parameters], "addRegs"]
                        case 29: byte[1:4] = ["A <----> C[$]", [parameters], "exchangeRegs"]
                        case 30: byte[1:4] = ["A + C -> A[$]", [parameters], "addRegs"]
                        case 31: byte[1:4] = ["A + 1 -> A[$]", [parameters], "incReg"]
                elif (raw_byte & 15) == 4 :
                    instruction = (48 & raw_byte) >> 4
                    parameters = (960 & raw_byte) >> 6
                    match instruction:
                        case 0: byte[1:4] = ["S: 1 --> S[#]", [parameters], "setStatus"]
                        case 1: byte[1:4] = [">S[#] ≠ 1", [parameters], "ifSBitZero"]
                        case 2: byte[1:4] = ["S: 0 --> S[#]", [parameters], "clearStatus"]
                        case 3: byte[1:4] = ["S: 0 ----> all", [], "clearAllStatus"]
                elif (raw_byte & 15) == 12 :
                    instruction = (48 & raw_byte) >> 4
                    parameters = (960 & raw_byte) >> 6
                    match instruction:
                        case 0: byte[1:4] = ["P: set P to #", [parameters], "setP"]
                        case 1: byte[1:4] = ["P: decrement", [], "decP"]
                        case 2: byte[1:4] = [">P ≠ #", [parameters], "ifPNotValue"]
                        case 3: byte[1:4] = ["P: increment", [], "incP"]
                elif (raw_byte & 63) == 16 :
                    instruction = (64 & raw_byte) >> 6
                    parameters = (896 & raw_byte) >> 7
                    match instruction:
                        case 0: byte[1:4] = ["select ROM @", [parameters], "selectRom"]
                        case 1: byte[1:4] = ["KEYBOARD entry", [], "keyGoTo"]
                elif (raw_byte & 63) == 24 :
                    instruction = 0
                    parameters = (960 & raw_byte) >> 6
                    byte[1:4] = ["@ -----> C[P ]", [parameters], "loadConstant"]
                elif (raw_byte & 1023) == 0 :
                    instruction = 0
                    parameters = 0
                    byte[1:4] = ["no operation", [], "nOp"]
                elif (raw_byte & 7) == 0:
                    instruction = (1016 & raw_byte) >> 3
                    parameters = 0
                    match instruction:
                        case 5: byte[1:4] = ["DISP toggle", [], "displayToggle"]
                        case 6: byte[1:4] = [">return", [], "ret"]
                        case 21: byte[1:4] = ["C <----> M[W ]", [], "exchangeRegs"]
                        case 37: byte[1:4] = ["push C", [], "pushC"]
                        case 53: byte[1:4] = ["pop A", [], "popA"]
                        case 69: byte[1:4] = ["DISPLAY off", [], "displayOff"]
                        case 78: byte[1:4] = ["C[12] ----> DA", [], "setDataAddress"]
                        case 85: byte[1:4] = ["M -----> C[W ]", [], "copyReg"]
                        case 94: byte[1:4] = ["C[W ] --> DATA", [], "cToData"]
                        case 95: byte[1:4] = ["DATA --> C[W ]", [], "dataToC"]
                        case 101: byte[1:4] = ["rotate down", [], "rotateDown"]
                        case 117: byte[1:4] = ["clear REGS", [], "clearAllRegs"]
        return decoded_roms

    def ac_InternalRegsDict(self):
        """ return a dictionary of (internal reg name, content string) tuples"""
        this_dict = {}
        names = ["A", "B", "C", "D", "E", "F", "M"]
        for name, contents in zip(names, self.internal):
            formatted_contents = array2string(flip(contents), \
                                                        separator='')[1:-1]
            this_dict[name] = formatted_contents
        return this_dict

    def ac_StorageRegsDict(self):
        """ return a dictionary of (storage reg name, content string) tuples"""
        this_dict = {}
        names = ["R0", "R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8", "R9"]
        for name, contents in zip(names, self.storage):
            formatted_contents = array2string(flip(contents), \
                                                        separator='')[1:-1]
            this_dict[name] = formatted_contents
        return this_dict

    def ac_StatusString(self, high_to_low):
        """ return a string of the status bits with a low bit shown as _ and a 
        high bit shown by its bit number : high_to_low set in pref file """
        this_string = ""
        names = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b"]
        for bit in range(12):
            if self.status[bit] == 1:
                this_string += names[bit]
            else:
                this_string += "_"
        if high_to_low:
            this_string = this_string[::-1]
        return this_string
    
    def ac_StatusStringBinary(self, high_to_low):
        """ return a string of the status bits with a low bit shown as 0 and a 
        high bit shown as 1 : high_to_low set in pref file """
        this_string = array2string(self.status, separator='')[1:-1]
        if high_to_low:
            this_string = this_string[::-1]
        return this_string
    
    def ac_ROEString(self, high_to_low):
        """ return a string of the ROE with a low bit shown as _ and a 
        high bit shown by its ROM number : high_to_low set in pref file """
        this_string = ""
        names = ["0", "1", "2", "3", "4", "5", "6", "7"]
        for bit in range(self.ac_rom_count):
            if self.rom_enabled[bit] == 1:
                this_string += names[bit]
            else:
                this_string += "_"
        if high_to_low:
            this_string = this_string[::-1]
        return this_string
    
    def ac_ROEStringBinary(self, high_to_low):
        """ return a string of the ROE with a low bit shown as 0 and a 
        high bit shown as 1 : high_to_low set in pref file """
        this_string = array2string(self.rom_enabled, separator='')[1:-1]
        if high_to_low:
            this_string = this_string[::-1]
        return this_string

    def ac_CurrentROMValue(self):
        """ return the number of the currently enabled ROM """
        this_value = dot(self.ac_rom_numbers, self.rom_enabled)
        return this_value

    def ac_Label(self, rom, address):
        """ return the label of the current ROM/byte """
        this_string = self.ac_roms[rom][address][4]
        return this_string

    def ac_RawByteValue(self, rom, address):
        """ return the raw byte contents of the (current) ROM/address """
        this_value = self.ac_roms[rom][address][0]
        return this_value
    
    def ac_InstructionString(self, rom, address):
        """ return the instruction string at the (current) ROM/address """
        this_string = self.ac_roms[rom][address][1]
        return this_string
    
    def ac_ShortInstructionString(self, rom=None, address=None):
        """ return the short instruction string at the (current) ROM/address"""
        if rom == None:
            rom = self.ac_current_rom
        if address == None:
            address = self.current_address
        this_string = self.ac_roms[rom][address][3]
        return this_string

    def ac_ParameterList(self, rom=None, address=None):
        """ return a list of parameters at the (current) ROM/address"""
        if rom == None:
            rom = self.ac_current_rom
        if address == None:
            address = self.current_address
        this_list = self.ac_roms[rom][address][2]
        return this_list

    def ac_BranchLabel(self, rom, address):
        """ return the label of branch address in (current) parameters """
        if rom == None:
            rom = self.ac_current_rom
        if address == None:
            address = self.current_address
        this_string = self.ac_roms[rom][address][5]
        return this_string

    def ac_CurrentValsTuple(self, just_turned_on, base, toBase):
        """ return a current values tuple in a given base using calculator
        variables: pointer, carry, data address, return address, keycode,
        display enabled """
        if just_turned_on:
            keycode = "---"
        else:                                  # edge case: base changed during background
                                                 # loop so avoid dummy keycode being shown
            if self.keycode >= 300:
                keycode = toBase(self.keycode-300, base)
            else:
                keycode = toBase(self.keycode, base)
        return (self.pointer, self.carry, self.data_address,
                toBase(self.return_address, base), keycode,
                self.display_enabled)

    def ac_CopyCurrenttoLast(self):
        """ copy the calculator state to the last calculator state before
        executing the next instruction """
        self.ac_last_address = self.current_address
        self.ac_last_short_instruction = self.ac_ShortInstructionString()
        self.ac_last_parameters = self.ac_ParameterList()
        self.ac_last_display_enabled = self.display_enabled
        self.ac_last_internal = self.internal.copy()
        self.ac_last_storage = self.storage.copy()
        self.ac_last_status = self.status.copy()
        self.ac_last_rom_enabled = self.rom_enabled.copy()
        self.ac_last_return_address = self.return_address
        self.ac_last_pointer = self.pointer
        self.ac_last_data_address = self.data_address
        self.ac_last_carry = self.carry

class SimPreferences:
    """ preferences read from the simulator (not calculator) prefs file and
    unchanged during execution """
    def __init__(self, sp_file):
                # flag is used to determine if user has manually corrected prefs file name 
        self.using_normal_prefs = False
        try:
            with open(ospath.join(ospath.dirname(sysargv[0]),sp_file), 'r',
                      newline='', encoding="utf-8") as pf:
                preferences = jload(pf)
                                     # prefs file isn't found so fall back to _normal file
        except FileNotFoundError:
            sp_file = sp_file[:sp_file.index(".")]+"_normal.json"
            self.using_normal_prefs = True
            try:
                with open(ospath.join(ospath.dirname(sysargv[0]),sp_file), 'r',
                        newline='', encoding="utf-8") as pf:
                    preferences = jload(pf)
                                                     # no _normal file either so error out
            except FileNotFoundError:   
                error_text = tk.Text(root, font=("",16), width=40, wrap='word',
                                    padx=20, pady=20)
                error_text.pack()
                error_text.insert(tk.END, 
                        ("There are no valid preference files available. The"
                        " files hp1973_prefs_[OS].json or "
                        "hp1973_prefs_[OS]_normal.json should be in the same "
                        "folder as the HP-1973 executable.\n\nYou can close "
                        "this window using the usual button in the window's "
                        "title bar."))
                error_text.config(state=tk.DISABLED)
                root.update_idletasks()
                root.mainloop()
                raise SystemExit(("Sorry, but the simulator preferences file\n"
                                f"cannot be found.\nIt should be in the same "
                                "directory as\nthe HP-1973 executable."))
                                                     # 'high-level' subsets used elsewhere
        self.calc = preferences["calculator"]
        self.prefs = preferences["preferences"]
        self.format = preferences["format"]
        self.bindings = preferences["bindings"]
        self.themes = preferences["themes"]
        self.menus = preferences["menus"]
                            # if _normal prefs file being used, override 'prompt_for_calc'
        if self.using_normal_prefs:
            self.calc["prompt_for_calc"] = True
                                         # preferences which don't change during execution
        self.prevent_sci_view_for_r0 = self.prefs["prevent_sci_view_for_r0"]
                                                # short list is used for some screen-types
        self.short_list = self.prefs["short_list"]
        if self.short_list:
            self.list_height = self.prefs["short_list_height"]
        else:
            self.list_height = self.prefs["list_height"]
                                                   # preferences used during key-wait loop
        self.keyloop_interval = self.prefs["keyloop_interval"]
        self.keyloop_normal_bpi = self.prefs["keyloop_normal_bytes_per_interval"]
        self.keyloop_timer_bpi = self.prefs["keyloop_timer_bytes_per_interval"]
        self.always_loop_keywait = self.prefs["always_loop_keywait"]
        self.timer_flicker_tweak = self.prefs["timer_flicker_tweak"]
        self.always_loop_keywait = self.prefs["always_loop_keywait"]
                                                                         # simulator title
        self.title = ("HP-1973 (A 50th Anniversary Electronic Slide Rule)")
                                                                    # status and ROE order
        self.show_status_high_to_low = self.prefs["show_status_high_to_low"]
        self.show_roe_high_to_low = self.prefs["show_roe_high_to_low"]
            # replace colour names in theme with "#nnnnnn" strings using colour dictionary
            # and populate preferences for themes: names, count, initial theme number
        colour_dict = preferences["colour_dictionary"]
        self.theme_names = []
        self.theme_count = 0
        for name, settings in self.themes.items():
            self.theme_names.append(name)
            for gui_item, gui_colour in settings.items():
                if not isinstance(gui_colour, (tuple, list)):
                    if gui_colour[0:1] != "#":
                        new_colour = colour_dict[gui_colour]
                        settings.update({gui_item:new_colour})
                else:
                    colour_list = []
                    for colour in gui_colour:
                        if colour[0:1] != "#":
                            colour_list.append(colour_dict[colour])
                        else:
                            colour_list.append(colour)
                    settings.update({gui_item:colour_list})
            self.theme_count += 1
        try:
            self.theme_initial_number = self.theme_names.index(self.prefs["initial_theme"])
        except:
            self.theme_initial_number = 0
                   # load the help file and save for use in menu creation and showing help
        help_file_name = self.prefs["help_file"]
        try:
            with open(ospath.join(ospath.dirname(sysargv[0]),help_file_name),
                      'r', newline='', encoding="utf-8") as pf:
                self.help_file = jload(pf)
        except FileNotFoundError:
            error_text = tk.Text(root, font=("",16), width=40, wrap='word',
                                 padx=20, pady=20)
            error_text.pack()
            error_text.insert(tk.END, 
                    ("There is no valid help file available."
                     "\n\nThe file hp1973_help.json should be in the same "
                     "folder as the HP1973 executable.\n\nYou can close this "
                     "window using the usual button in the window's title "
                     "bar."))
            error_text.config(state=tk.DISABLED)
            root.update_idletasks()
            root.mainloop()
            raise SystemExit((f"Sorry, but the help file, {help_file_name},\n"
                              "cannot be found. It should be in the same\n"
                              "directory as the HP-1973 executable."))
        for page in self.help_file:
            self.help_file[page]["main"] = page.replace('\n', ' ') \
                                           + f"\n{'-'*len(page)}\n\n" \
                                           + self.help_file[page]["main"]
        self.help_file["About"]["main"] = \
            self.help_file["About"]["main"].replace('cvnnnn',version)

class SimFlags:
    """ values relating to simulator execution which change during execution """
    def __init__(self, prefs, theme_initial_number, theme_names,
                 storage_support):
        """ populate initial flag values """
                                           # preferences which can change during execution
        self.map_active = prefs["initial_map_active"]
        self.list_mode = prefs["initial_list_mode"]
        self.scrollbar = prefs["initial_list_scrollbar"]
        self.keyboard_mode = prefs["initial_keyboard_mode"]%3
        self.sci_view = prefs["initial_sci_view_mode"]
        self.base = prefs["initial_base"]
        self.binary = prefs["initial_content_binary"]
        if prefs["initial_zero_as_dot"]:
            self.zero_swap = "•"
        else:
            self.zero_swap = "0"
        self.update_mode = prefs["initial_update_mode"]%3
        if self.list_mode == 0 and self.update_mode == 2:
            self.update_mode = 0
        self.theme_current_number = theme_initial_number
        self.theme_current_name = theme_names[theme_initial_number]
        self.display_mode = prefs["initial_display_mode"]
        self.low_battery = prefs["initial_low_battery"]
                                               # other flags, not from the preference file
        self.help_window_active = False              # stops multiple help windows opening
        self.power_on = True
        self.just_turned_on = True         # used in list to show turned on instead of key
                                  # how many lines in start text of list - done in flags
                                  # not preferences because depends on selected calculator
        if storage_support:
            self.list_start_lines = 12
        else:
            self.list_start_lines = 9


    def flagTuple(self):
        """ returns the current values of all the flags displayed in the simulator gui """
                         # additional '0' in list is from a deleted flag - keeps remaining
                         # flags in same position in list for use in alreay written code
        flag_tuple = (self.map_active, self.list_mode, self.scrollbar,
                      self.keyboard_mode, self.sci_view, self.base,
                      self.binary, self.zero_swap, self.update_mode,
                      self.power_on, self.theme_current_name,
                      0, self.help_window_active,
                      self.display_mode, self.low_battery)
        return flag_tuple

class Keyloop:
    """ flags and methods used in controlling the key-wait loop """
    def __init__(self):
        """ initialize the key-wait loop flags """
        self.cycle_count = 0                   # how many times has loop run in foreground
        self.total_loops_to_show = 2                 # how many loops to run in foreground
        self.loops_running = 0              # how many loops are running in the background

    def reset(self):
        """ reset the key-wait loop flags (except loops_running) """
        self.cycle_count = 0
        self.total_loops_to_show = 2

class CalcAndROMSelect:
    """ the initial screen which allows the user to select a calculator/ROM
    version to use """
    def __init__(self, format, theme, default_type, default_rom, definitions,
                 using_normal_prefs):
                             # set up the layout, formatting and theme: we set theme here
                             # because do not have mechanism for choosing themes, etc. yet
        self.layout()
        self.format(format)
        self.bg = theme["rom_details_background"]
        self.fg = theme["rom_details_font"]
        self.fg_bugged = theme["rom_details_font_bugged"]
        self.theme(self.bg, self.fg)
                                                                    # initialize variables
        self.selected_calculator = ""
        self.selected_rom_version = ""
        calc_rom_list = []
        current_calc_rom = 0
        calc_rom_count = 0
        bugged_rom = False
        non_bugged_rom = False
                             # create a list containing information for each calc-ROM pair
        for calc in definitions:
            for rom_v in definitions[calc]["rom_versions"]:
                calc_rom_list.append(definitions[calc]["rom_versions"][rom_v]["info_dict"])
                if calc == default_type and rom_v == default_rom:
                    current_calc_rom = calc_rom_count
                if definitions[calc]["rom_versions"][rom_v]["info_dict"]["known_bugs"]:
                    bugged_rom = True         # need to know if we have any bugged ROMs...
                else:
                    non_bugged_rom = True                     # ...and any non-bugged ROMS
                calc_rom_count += 1
                              # only give option to show bugged roms if have both bugged
                              # and non-bugged ROM versions and default ROM isn't a bugged
                              # ROM : otherwise show all ROM versions
        if non_bugged_rom and bugged_rom \
                         and not calc_rom_list[current_calc_rom]["known_bugs"]:
            show_bugged_roms_button = True
            show_bugged_roms = False
        else:
            show_bugged_roms_button = False
            show_bugged_roms = True
               # call nextROMversion with previous ROM so get current ROM when incremented
        self.nextROMVersion(calc_rom_list, (current_calc_rom-1)%calc_rom_count,
                            calc_rom_count, using_normal_prefs,
                            show_bugged_roms, show_bugged_roms_button)

    def layout(self):
        """ layout of the select calculator and ROM window """
        self.frame = tk.Frame(root, bg="#000", highlightthickness=1,
                              borderwidth=0)
                                                       # label: calculator and ROM details
        self.info_string = tk.StringVar()
        self.label = tk.Label(self.frame, textvariable=self.info_string,
                        height=15, anchor="nw", justify=tk.LEFT,
                        padx=0, pady=0)
        self.label.grid(row=0, column=0, columnspan=3, sticky="new")
                                 # button: show bugged ROMs (not initially added to frame)
        self.show_bugged_roms_button = tk.Button(self.frame,
                                                 text="Show Bugged ROMs",
                                                 width=18)
                                                           # button: next calc-ROM version
        self.next_rom_button = tk.Button(self.frame,
                                         text="Show Next ROM", width=18)
        self.next_rom_button.grid(row=1, column=1)
                                                         # button: select current calc-ROM
        self.select_rom_button = tk.Button(self.frame,
                                           text="Select This ROM", width=18)
        self.select_rom_button.grid(row=1, column=2)
                                                                    # label: bottom spacer
        self.lower_label = tk.Label(self.frame, text="",
                        height=2, anchor="nw", justify=tk.CENTER, padx=0, pady=0)
        self.lower_label.grid(row=2, column=0, columnspan=3, sticky="new")
               # make sure the buttons are spaced the same with/without bugged ROMs button
        self.frame.grid_columnconfigure(0, weight=1, uniform="uniform")
        self.frame.grid_columnconfigure(1, weight=1, uniform="uniform")
        self.frame.grid_columnconfigure(2, weight=1, uniform="uniform")
                                                                       # display the frame
        self.frame.grid(row=0, column=0, sticky="new")

    def format(self, format):
        """ format the items """
        a_font = format["rom_details"]["font"]
        a_font_size = format["rom_details"]["font_size"]
        a_width = format["calc_rom_select"]["width"]
        self.label.config(font=(a_font, a_font_size))
        self.lower_label.config(font=(a_font, a_font_size))
        self.label.config(width=a_width)
        self.label.config(height = 22)
        self.lower_label.config(width=a_width)

    def theme(self, a_bg, a_fg):
        """ apply theme to items """
        self.frame.config(bg=a_bg, highlightbackground=a_fg)
        self.label.config(bg=a_bg, fg=a_fg)
        self.lower_label.config(bg=a_bg, fg=a_fg)
        self.next_rom_button.config(highlightbackground=a_bg)
        self.select_rom_button.config(highlightbackground=a_bg)
        self.show_bugged_roms_button.config(highlightbackground=a_bg)

    def nextROMVersion(self, calc_rom_list, current_calc_rom, calc_rom_count,
                       using_normal_prefs, show_bugged_roms,
                       show_bugged_roms_button):
        if show_bugged_roms_button:
            self.show_bugged_roms_button.grid(row=1, column=0)
        else:
            self.show_bugged_roms_button.grid_forget()
                                # move on to the next calc-ROM pair, or loop back to first
        current_calc_rom = (current_calc_rom + 1) % calc_rom_count
                    # if we're not showing bugged ROMs, skip until hit next non-bugged ROM
        while (not show_bugged_roms) and calc_rom_list[current_calc_rom]["known_bugs"]:
            current_calc_rom = (current_calc_rom + 1) % calc_rom_count
        self.setDetails(calc_rom_list[current_calc_rom], using_normal_prefs)
                    # bind 'show bugged ROMs' button to call this method with previous ROM
                    # (so shows same ROM after increment), with show_bugged_ROMs set true)
        self.show_bugged_roms_button.bind("<Button-1>",
            lambda event: self.nextROMVersion(calc_rom_list,
                                        (current_calc_rom-1)%calc_rom_count,
                                        calc_rom_count,
                                        using_normal_prefs,
                                        show_bugged_roms=True,
                                        show_bugged_roms_button=False))
                                                # bind next ROM button to call this method
        self.next_rom_button.bind("<Button-1>",
            lambda event: self.nextROMVersion(calc_rom_list, current_calc_rom,
                                              calc_rom_count,
                                              using_normal_prefs,
                                              show_bugged_roms,
                                              show_bugged_roms_button))
                                 # update the selected calculator-ROM after each increment
        self.selected_calculator = calc_rom_list[current_calc_rom]["calculator"]
        self.selected_rom_version = calc_rom_list[current_calc_rom]["rom_version"]

    def setDetails(self, info_dict, using_normal_prefs):
        """ use the calculator-ROM's info dictionary to populate the pane"""
        information_string = " "*110 + "\n"                               # sets the width
                       # put some extra text if the prefs file hasn't been manually chosen
        if using_normal_prefs:
            information_string += (
             "                  PLEASE READ THE README FILE INCLUDED WITH THE "
             "DISTRIBUTION FOR YOUR OPERATING SYSTEM. The simulator is\n"
             "                  currently using the ..._normal.json "
             "preference file which may cause display issues on some screens."
             "\n"
             "                  This message "
             "will be removed when the correct preference file has been "
             "renamed.\n"
             "                  ----------------------------------------------"
             "--------------------------------------------------------"
             "\n\n\n")
        information_string += (f"     Calculator : {info_dict['long_name']}\n"
                            f"     ROM Version: {info_dict['rom_version']}")
                                            # change the font colour if ROM has known bugs
        if info_dict["known_bugs"]:
            self.frame.config(highlightbackground=self.fg_bugged)
        else:
            self.frame.config(highlightbackground=self.fg)
                                                            # add information line by line
        information_string += "\n\n"
        for line in info_dict["information"]:
            information_string += f"                  {line}\n"
                                                                # update information label        
        self.info_string.set(information_string)

    def hide(self):
        """ hide the select calculator-ROM frame once calculator-ROM selected """
        self.frame.grid_forget()

class Display:
    """ the calculator display of the simulator, together with its title and
    information line """
    def __init__(self, format, calculator_rom):
        """ set up frame with layout and format """
        self.digit_colour = "#000"
        self.digit_outline = "#000"
        self.layout(calculator_rom)
        self.format(format)

    def layout(self, calculator_rom):
        """ outer frame holds display title and frame - frame holds display
        canvas and information strings """
                                                                                  # frames
        self.outer_frame = tk.Frame(root, bg="#000", 
                        highlightthickness=0, borderwidth=0)
        self.outer_frame.grid(row=0, column=1, pady=(10,0), sticky="new")
        self.frame = tk.Frame(self.outer_frame, bg="#000",
                        highlightthickness=1, borderwidth=0,
                        highlightbackground="#000", padx=10, pady=10)
        self.frame.grid(row=1, column=0, padx=0, pady=0, sticky="nw")
                                                                                   # title
        self.display_title = tk.Label(self.outer_frame,
                        text=calculator_rom, anchor="nw", justify=tk.LEFT,
                        height=1, padx=0, pady=0, highlightthickness=0,
                        borderwidth=0, bg="#000", fg="#000")
        self.display_title.grid(row=0, column=0, sticky="w", padx=0, pady=2)
                                                                          # display canvas
        self.canvas = tk.Canvas(self.frame, highlightthickness=0,
                                borderwidth=0, bg="#000")
        self.canvas.grid(row=0, column=0, columnspan=3)
                                                                             # information
        self.info_string_l = tk.StringVar()
        self.info_label_l = tk.Label(self.frame,
                        textvariable=self.info_string_l, height=1, anchor="nw",
                        width="29", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000")
        self.info_label_l.grid(row=1, column=0, sticky="nw")
        self.info_string_r = tk.StringVar()
        self.info_label_r = tk.Label(self.frame,
                        textvariable=self.info_string_r, height=1, anchor="ne",
                        width="29", justify=tk.RIGHT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000")
        self.info_label_r.grid(row=1, column=1, sticky="ne")
        self.status_string = tk.StringVar()
        self.status_label = tk.Label(self.frame,
                        textvariable=self.status_string, height=1, anchor="ne",
                        width="10", justify=tk.RIGHT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000")
        self.status_label.grid(row=1, column=2, sticky="ne")

    def format(self, format):
        """ format the items """
                                                                                   # title
        self.display_title.config(font=(format["calc_info"]["font"],
                                     format["calc_info"]["font_size"]))
                                                                        # display segments
        self.segment_height = format["display"]["segment_height"]
        self.segment_width = format["display"]["segment_width"]
        self.segment_breadth = format["display"]["segment_breadth"]
        self.digit_separation = format["display"]["digit_separation"]
        self.left = format["display"]["left"]
        self.right = format["display"]["right"]
        self.top = format["display"]["top"]
        self.bottom = format["display"]["bottom"]
                                                                          # display canvas
        canvas_height = self.top + (2*self.segment_height) \
                                    + (3*self.segment_breadth) + self.bottom
        canvas_width = self.left + ((self.segment_width  \
                                    + (2*self.segment_breadth) \
                                    + self.digit_separation) * 15) \
                                    - self.digit_separation + self.right \
                                    + self.segment_breadth
        self.canvas.config(height = canvas_height, width = canvas_width)
                                                                             # information
        self.info_label_l.config(font=(format["calc_info"]["font"],
                                     format["calc_info"]["font_size"]))
        self.info_label_r.config(font=(format["calc_info"]["font"],
                                     format["calc_info"]["font_size"]))
        self.status_label.config(font=(format["calc_info"]["font"],
                                     format["calc_info"]["font_size"]))
        
    def theme(self, theme):
        """ apply theme """
                                                                                  # frames
        self.outer_frame.config(bg=theme["display_frame_background"])
        self.frame.config(bg=theme["display_frame_background"],
                                highlightbackground=theme["display_font"])
                                                                                   # title
        self.display_title.config(bg=theme["display_frame_background"],
                                fg=theme["calc_info_font"])
                                                                        # display segments
        self.digit_colour = theme["display_font"]
        self.digit_outline = theme["display_font_dark"]
                                                                          # display canvas
        self.canvas.config(bg=theme["display_frame_background"])
                                                                             # information
        self.info_label_l.config(bg=theme["display_frame_background"],
                                fg=theme["calc_info_font"])
        self.info_label_r.config(bg=theme["display_frame_background"],
                                fg=theme["calc_info_font"])
        status = self.status_label.cget("text")
        if status == "READY":                                                                                                                                          
            self.status_label.config(bg=theme["working_background"],
                                    fg=theme["status_ready"])
        elif status == "WAITING":                                                                                                                                            
            self.status_label.config(bg=theme["working_background"],
                                    fg=theme["status_waiting"])
        else:                                                                                                                                        
            self.status_label.config(bg=theme["working_background"],
                                    fg=theme["status_working"])

    def updateFromDigits(self, display_string):
        """ convert a display string into segments on the display """
        display_segments = zeros((15,8), int)
        for digit, character in enumerate(display_string[::-1]):
            match character:
                case "0": segments = array([1,1,1,1,1,1,0,0])
                case "1": segments = array([0,1,1,0,0,0,0,0])
                case "2": segments = array([1,1,0,1,1,0,1,0])
                case "3": segments = array([1,1,1,1,0,0,1,0])
                case "4": segments = array([0,1,1,0,0,1,1,0])
                case "5": segments = array([1,0,1,1,0,1,1,0])
                case "6": segments = array([1,0,1,1,1,1,1,0])
                case "7": segments = array([1,1,1,0,0,0,0,0])
                case "8": segments = array([1,1,1,1,1,1,1,0])
                case "9": segments = array([1,1,1,1,0,1,1,0])
                case "-": segments = array([0,0,0,0,0,0,1,0])
                case ".": segments = array([0,0,0,0,0,0,0,1])
                case " ": segments = array([0,0,0,0,0,0,0,0])
            display_segments[digit] = segments
        self.update(display_segments)

    def update(self, display_segments):
        """ convert a digit/segment array into segments on the display """
        self.clear()
        position = 0
        for digit in roll(display_segments,1,0):       # roll so start with leftmost digit
            self.segments(position, digit)
            position = (position - 1) % 15

    def segments(self, position, digit):
        """ draw lit segments in current digit """
        x = self.left + (position * (self.segment_width \
                      + (2*self.segment_breadth) + self.digit_separation))
        y = self.top
        b = self.segment_breadth
        h = self.segment_height
        w = self.segment_width
        segment_positions = ((x, y, x+b+w, y+b),
                             (x+b+w, y, x+w+b+b, y+b+h+b),
                             (x+b+w, y+b+h+b, x+w+b+b, y+b+h+b+h+b),
                             (x, y+b+h+b+h, x+b+w, y+b+h+b+h+b),
                             (x, y+b+h+b, x+b, y+b+h+b+h),
                             (x, y+b, x+b, y+b+h+b),
                             (x+b, y+b+h, x+b+w, y+b+h+b),
                             (x+b+w-(3*b), y+b+h+b+h-(3*b), x+b+w-b, y+b+h+b+h-b))
        for segment_number, segment in enumerate(digit):
            if segment == 1:
                self.canvas.create_rectangle(
                    segment_positions[segment_number][0],
                    segment_positions[segment_number][1],
                    segment_positions[segment_number][2],
                    segment_positions[segment_number][3],
                    outline = self.digit_outline,
                    fill = self.digit_colour)

    def clear(self):
        """ clear the display """
        self.canvas.delete("all")

    def updateCalcInfo(self, m_reg, status, calc_info_flags, display_mode):
        """ update centre and left calc info beneath the display """
        shift_bit = calc_info_flags[0]
        shift_text = calc_info_flags[1]
        fix_sci_support = calc_info_flags[2]
        drg_support = calc_info_flags[3]
        fix_sci = shift = deg_rad_grd = ""
        if fix_sci_support == "m_register":                      # int reg M used by HP-45
            if m_reg[1] == 0:
                fix_sci = f"FIX {m_reg[2]}"
            else:
                fix_sci = f"SCI {m_reg[2]}"
        elif fix_sci_support == "status_bits":                 # status bits used by HP-80
            fix_sci_value = (status[1] + (2*status[2]) + (4*status[3]))
            if fix_sci_value < 7:
                fix_sci = f"FIX {fix_sci_value}"
            else:
                fix_sci = f"SCI  "
        else:                                       # otherwise no fix_sci showing (HP-35)
            fix_sci = "     "
                                                        # show deg/rad/gra status on HP-45     
        if drg_support:
            if m_reg[13] == 9:
                deg_rad_grd = "DEG"
            elif m_reg[13] == 0:
                deg_rad_grd = "RAD"
            elif m_reg[13] == 1:
                deg_rad_grd = "GRA"
        else:
            deg_rad_grd = "   "
                                                                       # show shift status
        if status[shift_bit]:                        # 10 for HP-35, HP-45, 7 for HP-80...
            shift = shift_text      # ...but HP-80 shift text empty as S[7] used elsewhere
        info_string_r = f"{deg_rad_grd}     {fix_sci}     {shift:<5}"
        self.info_string_r.set(info_string_r)
                                             # show warning on left if approx display mode
        if display_mode == 2:
            info_string_l = "APPROXIMATE DISPLAY MODE"
        else:
            info_string_l = ""
        self.info_string_l.set(info_string_l)
    
    def updateStatus(self, status, theme):
        """ update the simulator status at the lower right of the display """
        self.status_string.set(status)
        self.theme(theme)                      # different statuses have different colours
        root.update_idletasks()                             # make sure the screen updates

class FlagSettings:
    """ the frame which contains the calculator info, calculator display and
    simulator flags """
    def __init__(self, format):
        """ set up frame with layout and format, and show """
        self.layout()
        self.format(format)

    def layout(self):
        """ layout of the display and flags pane """
        sim_column_widths = (11, 7, 10, 7, 10, 9, 8, 6)
                                                                                   # frame
        self.frame = tk.Frame(root, bg="#000", highlightthickness=1,
                        borderwidth=0, highlightbackground="#000",
                        padx=10, pady=10)
        self.frame.grid(row=1, column=1, sticky="sw", padx=0, pady=0)
                                                                             # left column
                                                                                     # map
        self.sim_t_map_label = tk.Label(self.frame, text="[R]OM map",
                        height=1, anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[0])
        self.sim_t_map_label.grid(row=0, column=0, sticky="n")
        self.sim_map_string = tk.StringVar()
        self.sim_map_label = tk.Label(self.frame,
                        textvariable=self.sim_map_string, height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[1])
        self.sim_map_label.grid(row=0, column=1, sticky="n")
                                                                                    # list
        self.sim_t_list_label = tk.Label(self.frame, text="[L]ist", height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[0])
        self.sim_t_list_label.grid(row=1, column=0, sticky="n")
        self.sim_list_string = tk.StringVar()
        self.sim_list_label = tk.Label(self.frame,
                        textvariable=self.sim_list_string, height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[1])
        self.sim_list_label.grid(row=1, column=1, sticky="n")
                                                                               # scrollbar
        self.sim_t_scrollbar_label = tk.Label(self.frame, text="[S]croll",
                        height=1, anchor="w", justify=tk.LEFT, padx=0,
                        pady=0, highlightthickness=0, borderwidth=0,
                        bg="#000", fg="#000",  width=sim_column_widths[0])
        self.sim_t_scrollbar_label.grid(row=2, column=0, sticky="n")
        self.sim_scrollbar_string = tk.StringVar()
        self.sim_scrollbar_label = tk.Label(self.frame,
                        textvariable=self.sim_scrollbar_string, height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[1])
        self.sim_scrollbar_label.grid(row=2, column=1, sticky="n")
                                                                                # keyboard
        self.sim_t_keyboard_label = tk.Label(self.frame, text="[K]eyboard",
                        height=1, anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[0])
        self.sim_t_keyboard_label.grid(row=3, column=0, sticky="n")
        self.sim_keyboard_string = tk.StringVar()
        self.sim_keyboard_label = tk.Label(self.frame,
                        textvariable=self.sim_keyboard_string, height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[1])
        self.sim_keyboard_label.grid(row=3, column=1, sticky="n")
                                                                      # centre left column
                                                                                  # format
        self.sim_t_format_label = tk.Label(self.frame,
                        text="[F]ormat", height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[2])
        self.sim_t_format_label.grid(row=0, column=2, sticky="n")
        self.sim_format_string = tk.StringVar()
        self.sim_format_label = tk.Label(self.frame,
                        textvariable=self.sim_format_string, height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[3])
        self.sim_format_label.grid(row=0, column=3, sticky="n")
                                                                                    # base
        self.sim_t_base_label = tk.Label(self.frame, text="[B]ase", height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[2])
        self.sim_t_base_label.grid(row=1, column=2, sticky="n")
        self.sim_base_string = tk.StringVar()
        self.sim_base_label = tk.Label(self.frame,
                        textvariable=self.sim_base_string, height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[3])
        self.sim_base_label.grid(row=1, column=3, sticky="n")
                                                                                 # content
        self.sim_t_content_label = tk.Label(self.frame, text="[C]ontent",
                        height=1, anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[2])
        self.sim_t_content_label.grid(row=2, column=2, sticky="n")
        self.sim_content_string = tk.StringVar()
        self.sim_content_label = tk.Label(self.frame,
                        textvariable=self.sim_content_string, height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[3])
        self.sim_content_label.grid(row=2, column=3, sticky="n")
                                                                                    # zero
        self.sim_t_zero_label = tk.Label(self.frame, text="[Z]ero", height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[2])
        self.sim_t_zero_label.grid(row=3, column=2, sticky="n")
        self.sim_zero_string = tk.StringVar()
        self.sim_zero_label = tk.Label(self.frame,
                        textvariable=self.sim_zero_string, height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[3])
        self.sim_zero_label.grid(row=3, column=3, sticky="n")
                                                                     # centre right column
                                                                                  # update
        self.sim_t_update_label = tk.Label(self.frame, text="[U]pdate",
                        height=1, anchor="w", justify=tk.LEFT, padx=0,
                        pady=0, highlightthickness=0, borderwidth=0,
                        bg="#000", fg="#000", width=sim_column_widths[4])
        self.sim_t_update_label.grid(row=0, column=4, sticky="n")
        self.sim_update_string = tk.StringVar()
        self.sim_update_label = tk.Label(self.frame,
                        textvariable=self.sim_update_string, height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[5])
        self.sim_update_label.grid(row=0, column=5, sticky="n")
                                                                                 # display
        self.sim_t_display_label = tk.Label(self.frame, text="[D]isplay",
                        height=1, anchor="w", justify=tk.LEFT, padx=0,
                        pady=0, highlightthickness=0, borderwidth=0,
                        bg="#000", fg="#000", width=sim_column_widths[4])
        self.sim_t_display_label.grid(row=1, column=4, sticky="n")
        self.sim_display_string = tk.StringVar()
        self.sim_display_label = tk.Label(self.frame,
                        textvariable=self.sim_display_string, height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[5])
        self.sim_display_label.grid(row=1, column=5, sticky="n")
                                                                                   # power
        self.sim_t_power_label = tk.Label(self.frame, text="[P]ower",
                        height=1, anchor="w", justify=tk.LEFT, padx=0,
                        pady=0, highlightthickness=0, borderwidth=0,
                        bg="#000", fg="#000", width=sim_column_widths[4])
        self.sim_t_power_label.grid(row=2, column=4, sticky="n")
        self.sim_power_string = tk.StringVar()
        self.sim_power_label = tk.Label(self.frame,
                        textvariable=self.sim_power_string, height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[5])
        self.sim_power_label.grid(row=2, column=5, sticky="n")
                                                                                 # battery
        self.sim_t_battery_label = tk.Label(self.frame, text="Batter[Y]",
                        height=1, anchor="w", justify=tk.LEFT, padx=0,
                        pady=0, highlightthickness=0, borderwidth=0,
                        bg="#000", fg="#000", width=sim_column_widths[4])
        self.sim_t_battery_label.grid(row=3, column=4, sticky="n")
        self.sim_battery_string = tk.StringVar()
        self.sim_battery_label = tk.Label(self.frame,
                        textvariable=self.sim_battery_string, height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[5])
        self.sim_battery_label.grid(row=3, column=5, sticky="n")
                                                                            # right column
                                                                                   # theme
        self.sim_t_theme_label = tk.Label(self.frame, text="[T]heme",
                        height=1, anchor="w", justify=tk.LEFT, padx=0,
                        pady=0, highlightthickness=0, borderwidth=0,
                        bg="#000", fg="#000", width=sim_column_widths[6])
        self.sim_t_theme_label.grid(row=0, column=6, sticky="n")
        self.sim_theme_string = tk.StringVar()
        self.sim_theme_label = tk.Label(self.frame,
                        textvariable=self.sim_theme_string, height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[7])
        self.sim_theme_label.grid(row=0, column=7, sticky="n")
                                                              # calculator-rom information
        self.sim_t_info_label = tk.Label(self.frame, text="[I]nfo",
                        height=1, anchor="w", justify=tk.LEFT, padx=0,
                        pady=0, highlightthickness=0, borderwidth=0,
                        bg="#000", fg="#000", width=sim_column_widths[6])
        self.sim_t_info_label.grid(row=1, column=6, sticky="n")
                                                                                    # help
        self.sim_t_help_label = tk.Label(self.frame, text="[H]elp", height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[6])
        self.sim_t_help_label.grid(row=2, column=6, sticky="n")
        self.sim_help_string = tk.StringVar()
        self.sim_help_label = tk.Label(self.frame,
                        textvariable=self.sim_help_string, height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[7])
        self.sim_help_label.grid(row=2, column=7, sticky="n")
                                                                                    # quit
        self.sim_t_quit_label = tk.Label(self.frame, text="[Q]uit", height=1,
                        anchor="w", justify=tk.LEFT, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000", width=sim_column_widths[6])
        self.sim_t_quit_label.grid(row=3, column=6, sticky="n")

    def format(self, format):
        """ format the items """
                                                                             # left column
        self.sim_t_map_label.config(font=(format["sim_info"]["font"],
                                          format["sim_info"]["font_size"]))
        self.sim_map_label.config(font=(format["sim_info"]["font"],
                                        format["sim_info"]["font_size"]))
        self.sim_t_list_label.config(font=(format["sim_info"]["font"],
                                           format["sim_info"]["font_size"]))
        self.sim_list_label.config(font=(format["sim_info"]["font"],
                                         format["sim_info"]["font_size"]))
        self.sim_t_scrollbar_label.config(font=(format["sim_info"]["font"],
                                                format["sim_info"]["font_size"]))
        self.sim_scrollbar_label.config(font=(format["sim_info"]["font"],
                                              format["sim_info"]["font_size"]))
        self.sim_t_keyboard_label.config(font=(format["sim_info"]["font"],
                                               format["sim_info"]["font_size"]))
        self.sim_keyboard_label.config(font=(format["sim_info"]["font"],
                                             format["sim_info"]["font_size"]))
                                                                      # centre left column
        self.sim_t_format_label.config(font=(format["sim_info"]["font"],
                                             format["sim_info"]["font_size"]))
        self.sim_format_label.config(font=(format["sim_info"]["font"],
                                           format["sim_info"]["font_size"]))
        self.sim_t_base_label.config(font=(format["sim_info"]["font"],
                                           format["sim_info"]["font_size"]))
        self.sim_base_label.config(font=(format["sim_info"]["font"],
                                         format["sim_info"]["font_size"]))
        self.sim_t_content_label.config(font=(format["sim_info"]["font"],
                                              format["sim_info"]["font_size"]))
        self.sim_content_label.config(font=(format["sim_info"]["font"],
                                            format["sim_info"]["font_size"]))
        self.sim_t_zero_label.config(font=(format["sim_info"]["font"],
                                           format["sim_info"]["font_size"]))
        self.sim_zero_label.config(font=(format["sim_info"]["font"],
                                         format["sim_info"]["font_size"]))
                                                                     # centre right column
        self.sim_t_update_label.config(font=(format["sim_info"]["font"],
                                             format["sim_info"]["font_size"]))
        self.sim_update_label.config(font=(format["sim_info"]["font"],
                                           format["sim_info"]["font_size"]))
        self.sim_t_display_label.config(font=(format["sim_info"]["font"],
                                           format["sim_info"]["font_size"]))
        self.sim_display_label.config(font=(format["sim_info"]["font"],
                                           format["sim_info"]["font_size"]))
        self.sim_t_power_label.config(font=(format["sim_info"]["font"],
                                            format["sim_info"]["font_size"]))
        self.sim_power_label.config(font=(format["sim_info"]["font"],
                                          format["sim_info"]["font_size"]))
        self.sim_t_battery_label.config(font=(format["sim_info"]["font"],
                                             format["sim_info"]["font_size"]))
        self.sim_battery_label.config(font=(format["sim_info"]["font"],
                                           format["sim_info"]["font_size"]))
                                                                            # right column
        self.sim_t_theme_label.config(font=(format["sim_info"]["font"],
                                            format["sim_info"]["font_size"]))
        self.sim_theme_label.config(font=(format["sim_info"]["font"],
                                          format["sim_info"]["font_size"]))
        self.sim_t_info_label.config(font=(format["sim_info"]["font"],
                                             format["sim_info"]["font_size"]))
        self.sim_t_help_label.config(font=(format["sim_info"]["font"],
                                           format["sim_info"]["font_size"]))
        self.sim_help_label.config(font=(format["sim_info"]["font"],
                                           format["sim_info"]["font_size"]))
        self.sim_t_quit_label.config(font=(format["sim_info"]["font"],
                                           format["sim_info"]["font_size"]))
        
    def theme(self, theme, flag_tuple, storage_support, m_register_sci):
        """ apply theme """
                                                                                   # frame
        self.frame.config(bg=theme["display_frame_background"],
                          highlightbackground=theme["sim_info_label_font"]) 
                                                                             # left column   
        self.sim_t_map_label.config(bg=theme["display_frame_background"],
                                    fg=theme["sim_info_label_font"])
        if flag_tuple[0]:
            self.sim_map_label.config(bg=theme["display_frame_background"],
                                      fg=theme["sim_info_on_font"])
        else:
            self.sim_map_label.config(bg=theme["display_frame_background"],
                                      fg=theme["sim_info_off_font"])
        self.sim_t_list_label.config(bg=theme["display_frame_background"],
                                     fg=theme["sim_info_label_font"])
        if flag_tuple[1] != 0:
            self.sim_list_label.config(bg=theme["display_frame_background"],
                                       fg=theme["sim_info_options_font"])
        else:
            self.sim_list_label.config(bg=theme["display_frame_background"],
                                       fg=theme["sim_info_off_font"])
        if flag_tuple[1] != 0:
            self.sim_t_scrollbar_label.config(bg=theme["display_frame_background"],
                                            fg=theme["sim_info_label_font"])
        else:
            self.sim_t_scrollbar_label.config(bg=theme["display_frame_background"],
                                            fg=theme["sim_info_label_disabled"])
        if flag_tuple[2]:
            self.sim_scrollbar_label.config(bg=theme["display_frame_background"],
                                            fg=theme["sim_info_on_font"])
        else:
            self.sim_scrollbar_label.config(bg=theme["display_frame_background"],
                                            fg=theme["sim_info_off_font"])
        self.sim_t_keyboard_label.config(bg=theme["display_frame_background"],
                                         fg=theme["sim_info_label_font"])
        if flag_tuple[3] != 0:
            self.sim_keyboard_label.config(bg=theme["display_frame_background"],
                                           fg=theme["sim_info_options_font"])
        else:
            self.sim_keyboard_label.config(bg=theme["display_frame_background"],
                                           fg=theme["sim_info_off_font"])
                                                                      # centre left column
        if storage_support or m_register_sci:
            self.sim_t_format_label.config(bg=theme["display_frame_background"],
                                        fg=theme["sim_info_label_font"])
        else:
            self.sim_t_format_label.config(bg=theme["display_frame_background"],
                                        fg=theme["sim_info_label_disabled"])
        self.sim_format_label.config(bg=theme["display_frame_background"],
                                     fg=theme["sim_info_options_font"])
        self.sim_t_base_label.config(bg=theme["display_frame_background"],
                                    fg=theme["sim_info_label_font"])
        self.sim_base_label.config(bg=theme["display_frame_background"],
                                   fg=theme["sim_info_options_font"])
        if flag_tuple[1] != 0:
            self.sim_t_content_label.config(bg=theme["display_frame_background"],
                                            fg=theme["sim_info_label_font"])
        else:
            self.sim_t_content_label.config(bg=theme["display_frame_background"],
                                            fg=theme["sim_info_label_disabled"])
        self.sim_content_label.config(bg=theme["display_frame_background"],
                                      fg=theme["sim_info_options_font"])
        self.sim_t_zero_label.config(bg=theme["display_frame_background"],
                                     fg=theme["sim_info_label_font"])
        self.sim_zero_label.config(bg=theme["display_frame_background"],
                                   fg=theme["sim_info_options_font"])
                                                                     # centre right column
        self.sim_t_update_label.config(bg=theme["display_frame_background"],
                                       fg=theme["sim_info_label_font"])
        self.sim_update_label.config(bg=theme["display_frame_background"],
                                     fg=theme["sim_info_options_font"])
        self.sim_t_display_label.config(bg=theme["display_frame_background"],
                                          fg=theme["sim_info_label_font"])    
        self.sim_display_label.config(bg=theme["display_frame_background"],
                                    fg=theme["sim_info_options_font"])
        self.sim_t_power_label.config(bg=theme["display_frame_background"],
                                      fg=theme["sim_info_label_font"])
        if flag_tuple[9] == 1:                     
            self.sim_power_label.config(bg=theme["display_frame_background"],
                                        fg=theme["sim_info_on_font"])
        else:
            self.sim_power_label.config(bg=theme["display_frame_background"],
                                        fg=theme["sim_info_off_font"])  
        if flag_tuple[13] == 0:
            self.sim_t_battery_label.config(bg=theme["display_frame_background"],
                                            fg=theme["sim_info_label_font"])
        else:
            self.sim_t_battery_label.config(bg=theme["display_frame_background"],
                                            fg=theme["sim_info_label_disabled"])
        if flag_tuple[14]:
            self.sim_battery_label.config(bg=theme["display_frame_background"],
                                         fg=theme["sim_info_off_font"])
        else:
            self.sim_battery_label.config(bg=theme["display_frame_background"],
                                         fg=theme["sim_info_on_font"])
                                                                            # right column
        self.sim_t_theme_label.config(bg=theme["display_frame_background"],
                                      fg=theme["sim_info_label_font"])
        self.sim_theme_label.config(bg=theme["display_frame_background"],
                                    fg=theme["sim_info_options_font"])
        self.sim_t_info_label.config(bg=theme["display_frame_background"],
                                       fg=theme["sim_info_label_font"])
        self.sim_t_help_label.config(bg=theme["display_frame_background"],
                                      fg=theme["sim_info_label_font"])
        if flag_tuple[12]:
            self.sim_help_label.config(bg=theme["display_frame_background"],
                                         fg=theme["sim_info_on_font"])
        else:
            self.sim_help_label.config(bg=theme["display_frame_background"],
                                         fg=theme["sim_info_off_font"])
        self.sim_t_quit_label.config(bg=theme["display_frame_background"],
                                       fg=theme["sim_info_label_font"])
        
    def updateFlags(self, theme, flag_tuple, storage_support, m_register_sci):
        """ update the simulator flags """
                                                                             # left column
        if flag_tuple[0]:
            self.sim_map_string.set("ON")
        else:
            self.sim_map_string.set("OFF")
        if flag_tuple[1] == 0:
            self.sim_list_string.set("OFF")
        elif flag_tuple[1] == 1:
            self.sim_list_string.set("INS")
        else:
            self.sim_list_string.set("ROM")
        if flag_tuple[1] != 0:
            if flag_tuple[2]:
                self.sim_scrollbar_string.set("ON")
            else:
                self.sim_scrollbar_string.set("OFF")
        else:
            self.sim_scrollbar_string.set("")
        if flag_tuple[3] == 0:
            self.sim_keyboard_string.set("OFF")
        elif flag_tuple[3] == 1:
            self.sim_keyboard_string.set("LEFT")
        else:
            self.sim_keyboard_string.set("RIGHT")
                                                                      # centre left column
        if storage_support or m_register_sci:
            if flag_tuple[4]:
                self.sim_format_string.set("SCI9")
            else:
                self.sim_format_string.set("RAW")
        else:
            self.sim_format_string.set("")
        if flag_tuple[5] == 0:
            value_string = "DEC"
        elif flag_tuple[5] == 1:
            value_string = "HEX"
        elif flag_tuple[5] == 2:
            value_string = "OCT"
        self.sim_base_string.set(value_string)
        if flag_tuple[1] != 0:
            if flag_tuple[6]:
                self.sim_content_string.set("BIN")
            else:
                self.sim_content_string.set(value_string)
        else:
            self.sim_content_string.set("")
        self.sim_zero_string.set(flag_tuple[7]*3)
                                                                     # centre right column
        if flag_tuple[8] == 0:
            self.sim_update_string.set("END")
        elif flag_tuple[8] == 1:
            self.sim_update_string.set("LIVE")
        else:
            self.sim_update_string.set("STEP")
        if flag_tuple[13] == 0:
            self.sim_display_string.set("AUTH")
        elif flag_tuple[13] == 1:
            self.sim_display_string.set("FAST")
        else:
            self.sim_display_string.set("APPROX")
        if flag_tuple[9] == 1:
            self.sim_power_string.set("ON")
        else:
            self.sim_power_string.set("OFF")
        if flag_tuple[13] == 0:
            if flag_tuple[14]:
                self.sim_battery_string.set("LOW")
            else:
                self.sim_battery_string.set("NORMAL")
        else:
            self.sim_battery_string.set("")
                                                                            # right column
        self.sim_theme_string.set(flag_tuple[10].upper()[:6])
        if flag_tuple[12]:
            self.sim_help_string.set("ON")
        else:
            self.sim_help_string.set("OFF")
        self.theme(theme, flag_tuple, storage_support, m_register_sci)

class Internals:
    """ the stack, working indicator, storage registers, internal registers,
    status bits, ROE, and current address """
    def __init__(self, reg_format, lastx_support):
        """ set everything up with layout and format, and show """
        self.layout(lastx_support)
        self.format(reg_format)

    def layout(self, lastx_support):
        """ layout of various components of internals - 'working' refers to 
        current values frame and contents """
                                                                # stack and working frames
        self.stack_work_frame = tk.Frame(root, bg="#000",
                                         highlightthickness=0, borderwidth=0,
                                         padx=0, pady=0)
        self.stack_work_frame.grid(row=0, column=2, rowspan=2, sticky="nsw",
                                   padx=(20,0), pady=(10,0))
        self.stack_frame = tk.Frame(self.stack_work_frame, bg="#000", 
                                    highlightthickness=1, borderwidth=0,
                                    highlightbackground="#000", padx=10,
                                    pady=10)
        self.stack_frame.grid(row=1, column=0, padx=0, pady=0)
        self.working_frame = tk.Frame(self.stack_work_frame, bg="#000", 
                                      highlightthickness=1, borderwidth=0,
                                      highlightbackground="#f00", padx=10,
                                      pady=10)                            
        self.working_frame.grid(row=3, column=0, padx=0, pady=0, sticky="sw")
                                                              # stack and working contents
        self.stack_title = tk.Label(self.stack_work_frame, anchor="nw",
                                    justify=tk.LEFT, height=1, padx=0, pady=0,
                                    highlightthickness=0, borderwidth=0,
                                    bg="#000", fg="#000")
        if lastx_support:
            self.stack_title.config(text="STACK & LASTx")
        else:
            self.stack_title.config(text="STACK")
        self.stack_title.grid(row=0, column=0, sticky="nw", padx=0, pady=2)
        self.stack_string = tk.StringVar()
        self.stack_label = tk.Label(self.stack_frame,
                                    textvariable=self.stack_string,
                                    anchor="nw", justify=tk.LEFT, height=4,
                                    width=21, padx=0, pady=0,
                                    highlightthickness=0, borderwidth=0,
                                    bg="#000", fg="#000")
        self.stack_label.grid(row=0, column=0, sticky="nw")
        self.lastx_string = tk.StringVar()
        self.lastx_label = tk.Label(self.stack_frame,
                                    textvariable=self.lastx_string,
                                    anchor="nw", justify=tk.LEFT, height=1,
                                    width=21, padx=0, pady=0,
                                    highlightthickness=0, borderwidth=0,
                                    bg="#000", fg="#000")
        self.lastx_label.grid(row=1, column=0, sticky="nw")
        self.working_title = tk.Label(self.stack_work_frame, text="VALUES",
                                      anchor="nw", justify=tk.LEFT, height=1,
                                      padx=0, pady=0, highlightthickness=0,
                                      borderwidth=0, bg="#000", fg="#000")
        self.working_title.grid(row=2, column=0, sticky="sw", padx=0,
                                pady=(0,2))
        self.working_string = tk.StringVar()
        self.working_label = tk.Label(self.working_frame,
                                      textvariable=self.working_string,
                                      anchor="nw", justify=tk.LEFT, height=2,
                                      width=21, padx=0, pady=1,
                                      highlightthickness=0, borderwidth=0,
                                      bg="#000", fg="#000")
        self.working_label.grid(row=0, column=0, sticky="nw")
        self.stack_work_frame.rowconfigure(2, weight=1)
                                                                       # storage registers
        self.sto_frame = tk.Frame(root, bg="#000", highlightthickness=0,
                                  borderwidth=0)
        self.sto_frame.grid(row=0, column=3, rowspan=2, sticky="ne",
                            padx=(20,0), pady=(10,0))
        self.sto_title = tk.Label(self.sto_frame, text="STORAGE REGISTERS",
                                  anchor="nw", justify=tk.LEFT, height=1,
                                  padx=0, pady=0, highlightthickness=0,
                                  borderwidth=0, bg="#000", fg="#000")
        self.sto_title.grid(row=0, column=0, sticky="nw", padx=0, pady=2)
        self.sto_values_frame = tk.Frame(self.sto_frame, bg="#000", 
                                         highlightthickness=1, borderwidth=0,
                                         highlightbackground="#000", padx=10,
                                         pady=10)
        self.sto_values_frame.grid(row=1, column=0, padx=0)
        self.sto_string = tk.StringVar()
        self.sto_label = tk.Label(self.sto_values_frame,
                                  textvariable=self.sto_string, anchor="nw",
                                  justify=tk.LEFT, height=10, width=18,
                                  padx=0, pady=0, highlightthickness=0,
                                  borderwidth=0, bg="#000", fg="#000")
        self.sto_label.grid(row=0, column=0)
                                             # internal registers, status, ROE and address
        self.int_frame = tk.Frame(root, bg="#000", 
                                         highlightthickness=0, borderwidth=0)
        self.int_frame.grid(row=0, column=4, rowspan=2, sticky="ne",
                            padx=(20,0), pady=(10,0))
        self.int_title = tk.Label(self.int_frame,
                        text="INTERNAL REGISTERS", anchor="nw",
                        justify=tk.LEFT, height=1, padx=0, pady=0,
                        highlightthickness=0, borderwidth=0, bg="#000",
                        fg="#000")
        self.int_values_frame = tk.Frame(self.int_frame, bg="#000", 
                                         highlightthickness=1, borderwidth=0,
                                         highlightbackground="#000", padx=10,
                                         pady=10)
        self.int_string = tk.StringVar()
        self.int_label = tk.Label(self.int_values_frame,
                                  textvariable=self.int_string, anchor="nw",
                                  justify=tk.LEFT, height=10, padx=0, pady=0,
                                  highlightthickness=0, borderwidth=0,
                                  bg="#000", fg="#000")
        self.int_title.grid(row=0, column=0, sticky="nw", padx=0, pady=2)
        self.int_label.grid(row=0, column=0)
        self.int_values_frame.grid(row=1, column=0, padx=0)

    def format(self, reg_format):
        """ format the items """
                                                                # stack, lastx and working
        self.stack_title.config(font=(reg_format["font"], reg_format["font_size"]))
        self.stack_label.config(font=(reg_format["font"], reg_format["font_size"]))
        self.lastx_label.config(font=(reg_format["font"], reg_format["font_size"]))
        self.working_title.config(font=(reg_format["font"], reg_format["font_size"]))
        self.working_label.config(font=(reg_format["font"], reg_format["font_size"]))
                                                                       # storage registers
        self.sto_title.config(font=(reg_format["font"], reg_format["font_size"]))
        self.sto_label.config(font=(reg_format["font"], reg_format["font_size"]))
                                             # internal registers, status, ROE and address
        self.int_title.config(font=(reg_format["font"], reg_format["font_size"]))
        self.int_label.config(font=(reg_format["font"], reg_format["font_size"]))

    def theme(self, theme, storage_support, lastx_support):
        """ apply theme """
                                                                # stack, lastx and working
        self.stack_work_frame.config(bg=theme["stack_info_background"])
        self.stack_title.config(bg=theme["stack_info_background"],
                                fg=theme["stack_info_font"])
        self.stack_frame.config(bg=theme["stack_info_background"],
                                highlightbackground=theme["stack_info_font"]) 
        self.stack_label.config(bg=theme["stack_info_background"],
                                fg=theme["stack_info_font"])
        if lastx_support:
            self.lastx_label.config(bg=theme["stack_info_background"],
                                fg=theme["stack_info_font"])
        else:
            self.lastx_label.config(bg=theme["stack_info_background"],
                                fg=theme["lastx_info_disabled"])
        self.working_title.config(bg=theme["stack_info_background"],
                                fg=theme["working_font"])
        self.working_frame.config(bg=theme["working_background"],
                                highlightbackground=theme["working_font"])                                                                         
        self.working_label.config(bg=theme["working_background"],
                                fg=theme["working_font"])
                                                                       # storage registers
        if storage_support:
            self.sto_frame.config(bg=theme["sto_info_background"],
                                    highlightbackground=theme["sto_info_font"]) 
            self.sto_title.config(bg=theme["sto_info_background"],
                                    fg=theme["sto_info_font"])
            self.sto_values_frame.config(bg=theme["sto_info_background"],
                                    highlightbackground=theme["sto_info_font"]) 

            self.sto_label.config(bg=theme["sto_info_background"],
                                fg=theme["sto_info_font"])
        else:
            self.sto_frame.config(bg=theme["sto_info_background"],
                                    highlightbackground=theme["sto_info_disabled"]) 
            self.sto_title.config(bg=theme["sto_info_background"],
                                    fg=theme["sto_info_disabled"])
            self.sto_values_frame.config(bg=theme["sto_info_background"],
                                    highlightbackground=theme["sto_info_disabled"]) 
            self.sto_label.config(bg=theme["sto_info_background"],
                                fg=theme["sto_info_disabled"])
                                                                      # internal registers
        self.int_frame.config(bg=theme["int_info_background"],
                                highlightbackground=theme["int_info_font"]) 
        self.int_values_frame.config(bg=theme["int_info_background"],
                                highlightbackground=theme["int_info_font"]) 
        self.int_title.config(bg=theme["int_info_background"],
                                fg=theme["int_info_font"])
        self.int_label.config(bg=theme["int_info_background"],
                              fg=theme["int_info_font"])
                                       # updateRegisters is done in main class because
                                       # requires access to so many variables, flags, etc.

    def regToSci(self, reg_string):
        """ convert a register string to SCI9 format """
        sci_reg_string = ""
        if reg_string[0] == "9":                                           # mantissa sign
            sci_reg_string += "-"
        else:
            sci_reg_string += " "
        sci_reg_string += reg_string[1] + "."              # first digit and decimal point
        sci_reg_string += reg_string[2:11]                              # rest of mantissa
        if reg_string[11] != "9":                                               # exponent
            sci_reg_string += " " + reg_string[12:14]
        else:
            exponent = (100 - int(reg_string[12:14]))%100         # can have ...900 during 
            sci_reg_string += "-" + str(exponent).rjust(2,"0")    # calculations for e^-00
        return sci_reg_string

class Map:
    """ the ROM map which shows which addresses have been used during the 
    current calculator operation """
    def __init__(self, format, rom_count, rom_byte_count, active):
        """ initialize variables, set up layout and format and show if shown
        at start """
        self.start_rom = 0
        self.start_byte = 0
        self.keycode_rom = 0
        self.layout()
        self.format(format, rom_count, rom_byte_count)
        self.showHide(active)

    def layout(self):
        """ layout of map components """
                                                                                   # frame
        self.frame = tk.Frame(root, borderwidth = 0, highlightthickness = 0,
                              bg="#000", padx=0)
                                                                            # canvas (map)
        self.canvas = tk.Canvas(self.frame, borderwidth = 0,
                                highlightthickness = 0, bg="#000")
        self.canvas.grid(row=0, column=0)

    def format(self, format, rom_count, rom_byte_count):
        """ format the items """
        self.rom_height = format["map"]["rom_height"]                  # height of ROM bar
        self.rom_separator = format["map"]["rom_separator"]       # space between ROM bars
        self.byte_width = format["map"]["byte_width"]                   # width of address
        self.byte_separator = format["map"]["byte_separator"]    # space between addresses
        self.rom_bg_colours = ["#000" for i in range(8)]          # dark colour of ROM bar
        self.rom_fg_colours = ["#000" for i in range(8)]      # bright colour of used byte
        self.rom_keycode_byte_colour = "#000"           # colour of byte of keyboard entry
        self.start_byte_fill = "#000"          # fill colour of first byte after key press
        self.number_of_roms = rom_count
                                                                            # canvas (map)
        self.total_height = ((self.rom_height + self.rom_separator) \
                                     * self.number_of_roms) - self.rom_separator + 1
        self.total_width = ((self.byte_width + self.byte_separator) * rom_byte_count) \
                                    - self.byte_separator + 1
        self.canvas.config(height=self.total_height)
        self.canvas.config(width=self.total_width)

    def theme(self, theme, active):
        """ apply theme """
                                                                                   # frame
        self.frame.config(bg=theme["map_background"])
                                                                            # canvas (map)
        self.canvas.config(bg=theme["map_background"])
        self.rom_bg_colours = theme["map_rom_background"]
        self.rom_fg_colours = theme["map_rom"]
        self.rom_keycode_byte_colour = theme["rom_keycode_byte"]
        self.start_byte_fill = theme["rom_start_byte"]
        if active:
            self.clear()

    def clear(self):
        self.canvas.delete("all")
        self.keycode_rom = 10      # set high so not inadvertently used until set properly  
        for rom in range(self.number_of_roms):
            self.canvas.create_rectangle(                              # draw ROM bar from
                0,                                                                  # left 
                (rom * (self.rom_height + self.rom_separator)),           # top of ROM bar
                self.total_width,                                                #to right
                (rom * (self.rom_height + self.rom_separator)) + self.rom_height,  #bottom
                outline = self.rom_bg_colours[rom],
                fill = self.rom_bg_colours[rom])

    def update(self, current_rom, current_address, instruction, next_rom, keycode):
        """ update the ROM map with an executed byte """
        if instruction == "keyGoTo":
            self.keycode_rom = current_rom         # identify ROM of keyboard entry branch
         # get default colour for byte (select ROM will have set this to next ROM already)
        outline_colour = self.rom_fg_colours[next_rom]
        fill_colour = self.rom_fg_colours[next_rom]      # fill colour defaults to outline
        if current_rom == self.start_rom and current_address == self.start_byte:
            fill_colour = self.start_byte_fill           # change fill if first byte of op
        elif current_rom == self.keycode_rom and current_address == keycode:
            outline_colour = fill_colour = self.rom_keycode_byte_colour   #keycode colours
        self.canvas.create_rectangle(
            (current_address * (self.byte_width + self.byte_separator)),
            (current_rom * (self.rom_height + self.rom_separator)),
            (current_address * (self.byte_width + self.byte_separator)) \
                                                            + self.byte_width,
            (current_rom * (self.rom_height + self.rom_separator)) \
                                                            + self.rom_height,
            outline = outline_colour,
            fill = fill_colour)

    def setStart(self, start_rom, start_byte):
        """ set the start_rom and start_byte for the current operation"""
        self.start_rom = start_rom
        self.start_byte = start_byte

    def showHide(self, active):
        """ show or hide the components of the ROM map """
        if active:
            self.frame.grid(row=2, column=1, columnspan=4, sticky="new",
                            pady=(10,0))
            self.clear()
            root.update_idletasks()
        else:
            self.frame.grid_forget()

class List:
    """ the list pane which shows details of an operation, instruction by 
    instruction """
    def __init__(self, format, list_height, mode, sbar, short_list):
        """ initialize variables and set up layout and format, and show if shown
        at start """
        self.ins_number = 0
        self.return_string = ""
        self.initial_height = list_height     # starting height: list height is reduced...
        self.list_height = list_height                      # ...if stepping buttons shown
        self.layout(short_list)
        self.format(format, short_list)
        self.showHide(mode)
        self.showHideScroll(sbar)

    def layout(self, short_list):
        """ layout of list components """
                                                                             # outer frame
        self.outer_frame = tk.Frame(root, bg="#000", highlightthickness=0,
                                    borderwidth=0)
                                                                # current values - pointer
        self.pointer_val = tk.StringVar()
        self.pointer_frame = tk.Frame(self.outer_frame, bg="#000",
                                      highlightthickness=1,
                                      highlightbackground="#000",
                                      borderwidth=0, padx=10, pady=10)
        self.pointer_label = tk.Label(self.pointer_frame,
                                      textvariable=self.pointer_val,
                                      borderwidth=0, highlightthickness=0,
                                      width=19, anchor="w", justify=tk.LEFT,
                                      bg="#000", fg="#000")
        self.pointer_label.grid(row=0,column=0, sticky="nw")
        self.pointer_frame.grid(row=0,column=0, padx=0, pady=(0,7),
                                sticky="nsw")
                                                                  # current values - carry
        self.carry_val = tk.StringVar()
        self.carry_frame = tk.Frame(self.outer_frame, bg="#000",
                                    highlightthickness=1,
                                    highlightbackground="#000",
                                    borderwidth=0, padx=10, pady=10)
        self.carry_label = tk.Label(self.carry_frame,
                                    textvariable=self.carry_val,
                                    borderwidth=0, highlightthickness=0,
                                    width=19, anchor="nw", justify=tk.LEFT,
                                    bg="#000", fg="#000")
        self.carry_label.grid(row=0,column=0, sticky="nw")
        self.carry_frame.grid(row=1,column=0, padx=0, pady=7, sticky="nsw")
                                                           # current values - data address
        self.data_add_val = tk.StringVar()
        self.data_add_frame = tk.Frame(self.outer_frame, bg="#000",
                                       highlightthickness=1,
                                       highlightbackground="#000",
                                       borderwidth=0, padx=10, pady=10)
        self.data_add_label = tk.Label(self.data_add_frame,
                                       textvariable=self.data_add_val,
                                       borderwidth=0, highlightthickness=0,
                                       width=19, anchor="nw", justify=tk.LEFT,
                                       bg="#000", fg="#000")
        self.data_add_label.grid(row=0,column=0, sticky="nw")
        self.data_add_frame.grid(row=2,column=0, padx=0, pady=7, sticky="nsw")
                                                         # current values - return address
        self.ret_add_val = tk.StringVar()
        self.ret_add_frame = tk.Frame(self.outer_frame, bg="#000",
                                      highlightthickness=1,
                                      highlightbackground="#000",
                                      borderwidth=0, padx=10, pady=10)
        self.ret_add_label = tk.Label(self.ret_add_frame,
                                      textvariable=self.ret_add_val,
                                      borderwidth=0, highlightthickness=0,
                                      width=19, anchor="nw", justify=tk.LEFT,
                                      bg="#000", fg="#000")
        self.ret_add_label.grid(row=0,column=0, sticky="nw")
        self.ret_add_frame.grid(row=3,column=0, padx=0, pady=7, sticky="nsw")
                                                                # current values - keycode
        self.keycode_val = tk.StringVar()
        self.keycode_frame = tk.Frame(self.outer_frame, bg="#000",
                                      highlightthickness=1,
                                      highlightbackground="#000",
                                      borderwidth=0, padx=10, pady=10)
        self.keycode_label = tk.Label(self.keycode_frame,
                                      textvariable=self.keycode_val,
                                      borderwidth=0, highlightthickness=0,
                                      width=19, anchor="nw", justify=tk.LEFT,
                                      bg="#000", fg="#000")
        self.keycode_label.grid(row=0,column=0, sticky="nw")
        self.keycode_frame.grid(row=4,column=0, padx=0, pady=7, sticky="nsw")
                                                        # current values - display enabled
        self.disp_en_val = tk.StringVar()
        self.disp_en_frame = tk.Frame(self.outer_frame, bg="#000",
                                      highlightthickness=1,
                                      highlightbackground="#000",
                                      borderwidth=0, padx=10, pady=10)
        self.disp_en_label = tk.Label(self.disp_en_frame,
                                      textvariable=self.disp_en_val,
                                      borderwidth=0, highlightthickness=0,
                                      width=19, anchor="nw", justify=tk.LEFT,
                                      bg="#000", fg="#000")
        self.disp_en_label.grid(row=0,column=0, sticky="nw")
        self.disp_en_frame.grid(row=5,column=0, padx=0, pady=(7,0),
                                sticky="nsw")
                                                 # current values - word select components
        self.component_title = tk.Label(self.outer_frame, text="WORD SELECT",
                                        borderwidth=0, highlightthickness=0,
                                        height=1, justify=tk.LEFT, bg="#000",
                                        anchor="sw",  fg="#000")
                                       # we don't show the components if the list is short 
        if not short_list:
            self.component_title.grid(row=6, column=0, sticky="sw", padx=0, pady=5)
            self.component_list = tk.StringVar()
            self.component_frame = tk.Frame(self.outer_frame, bg="#000",
                                            highlightthickness=1,
                                            highlightbackground="#000",
                                            borderwidth=0, padx=10, pady=10)
            self.component_label = tk.Label(self.component_frame,
                                            textvariable=self.component_list,
                                            borderwidth=0, highlightthickness=0,
                                            width=19, anchor="nw", justify=tk.LEFT,
                                            bg="#000", fg="#000")
            self.component_label.grid(row=0,column=0, sticky="sw")
            self.component_frame.grid(row=7,column=0, padx=0, pady=(5,0),
                                    sticky="sw")
                                                                           # list - frames
        self.list_frame = tk.Frame(self.outer_frame, bg="#000",
                                   highlightthickness=1,
                                   highlightbackground="#000",
                                   highlightcolor="#000",
                                   borderwidth=0, padx=10, pady=10)
        self.list_frame.grid(row=0, column=1, rowspan=8, sticky="ne")
        self.ot_frame = tk.Frame(self.list_frame, bg="#000",
                                 highlightthickness=1,
                                 highlightbackground="#000", borderwidth=0,
                                 padx=0, pady=5)
        self.ot_frame.grid(row=0, column=1, sticky="new", padx=4) 
                                                                      # list - left spacer
                                # also maintains list height constant when stepping on/off
        self.lefthand = tk.Label(self.list_frame, text="",
                        borderwidth=0, highlightthickness=0, width=2,
                        justify=tk.LEFT, bg="#000", anchor="ne", fg="#000")
        self.lefthand.grid(row=1, column=0, rowspan=2, sticky="ne")
                                                                        # list - title bar
        self.list_title_string = tk.StringVar()
        self.ot_label = tk.Label(self.ot_frame,
                                 textvariable=self.list_title_string,
                                 borderwidth=0, highlightthickness=1,
                                 height=1, justify=tk.LEFT, bg="#000",
                                 anchor="nw",  fg="#000")
        self.ot_label.grid(row=0, column=0, sticky="nw")
                                                                   # list - execution list
        self.listbox = tk.Listbox(self.list_frame, justify=tk.LEFT, borderwidth=0,
                        highlightthickness=0, bg="#000", fg="#000", width=144)
        self.listbox.grid(row=1, column=1, sticky="nw")
                                                                     # list - right spacer
        self.righthand = tk.Label(self.list_frame, text="",
                        borderwidth=0, highlightthickness=0,  width=2,
                        justify=tk.LEFT, bg="#000", anchor="ne",  fg="#000")
        self.righthand.grid(row=0, column=2, sticky="nw")
                                                                        # list - scrollbar 
        self.scrollbar = tk.Scrollbar(self.list_frame, orient="vertical", width=11)
        self.scrollbar.config(command=self.listbox.yview)
        self.listbox.config(yscrollcommand=self.scrollbar.set)
                                                                # stepping buttons - frame
        self.stepping_frame = tk.Frame(self.list_frame, bg="#000",
                                       highlightthickness=0,
                                       highlightbackground="#000",
                                       borderwidth=0, padx=10, pady=0)
                                   # stepping buttons - first row: number-of-steps buttons
        self.buttons = []
        for i in range(7):
            step = (((i%2)*4)+1) * (10**(int(i/2)))     # 1,5,10,50,100,500,1000 (for fun)
            button = tk.Button(self.stepping_frame, text=f"{step}")
            button.grid(row=0, column=i, pady=1)
            self.buttons.append((button, step))
        button = tk.Button(self.stepping_frame, text="run to end")     # run to end button
        button.grid(row=0, column=7)
        self.buttons.append((button, 99999))
                                # stepping buttons - second row: instruction-based buttons
        button = tk.Button(self.stepping_frame, text="reg update")
        button.grid(row=1, column=0, pady=1)
        self.buttons.append((button, 2001))
        button = tk.Button(self.stepping_frame, text="reg shift")
        button.grid(row=1, column=1, pady=1)
        self.buttons.append((button, 2002))
        button = tk.Button(self.stepping_frame, text="push/pop/rot")
        button.grid(row=1, column=2, pady=1)
        self.buttons.append((button, 2003))
        button = tk.Button(self.stepping_frame, text="data/storage")
        button.grid(row=1, column=3, pady=1)
        self.buttons.append((button, 2004))
        button = tk.Button(self.stepping_frame, text="constant")
        button.grid(row=1, column=4, pady=1)
        self.buttons.append((button, 2005))
        button = tk.Button(self.stepping_frame, text="goto")
        button.grid(row=1, column=5, pady=1)
        self.buttons.append((button, 2006))
        button = tk.Button(self.stepping_frame, text="subroutine")
        button.grid(row=1, column=6, pady=1)
        self.buttons.append((button, 2007))
        button = tk.Button(self.stepping_frame, text="rom select")
        button.grid(row=1, column=7, pady=1)
        self.buttons.append((button, 2008))
                                 # stepping buttons - third row: instruction-based buttons
        button = tk.Button(self.stepping_frame, text="pointer")
        button.grid(row=2, column=0, pady=1)
        self.buttons.append((button, 3001))
        button = tk.Button(self.stepping_frame, text="status")
        button.grid(row=2, column=1, pady=1)
        self.buttons.append((button, 3002))
        button = tk.Button(self.stepping_frame, text="display")
        button.grid(row=2, column=2, pady=1)
        self.buttons.append((button, 3003))
        button = tk.Button(self.stepping_frame, text="key entry")
        button.grid(row=2, column=3, pady=1)
        self.buttons.append((button, 3004))
        button = tk.Button(self.stepping_frame, text="nop")
        button.grid(row=2, column=4, pady=1)
        self.buttons.append((button, 3005))
                                                # stepping buttons - third row: conditions
        button = tk.Button(self.stepping_frame, text="reg query")
        button.grid(row=2, column=5, pady=1)
        self.buttons.append((button, 3006))
        button = tk.Button(self.stepping_frame, text="carry 0 to 1")
        button.grid(row=2, column=6, pady=1)
        self.buttons.append((button, 3007))
        button = tk.Button(self.stepping_frame, text="P≠n false")
        button.grid(row=2, column=7, pady=1)
        self.buttons.append((button, 3008))
                                                # stepping buttons - space buttons equally
        self.stepping_frame.grid_columnconfigure(0, weight=1, uniform="uniform")
        self.stepping_frame.grid_columnconfigure(1, weight=1, uniform="uniform")
        self.stepping_frame.grid_columnconfigure(2, weight=1, uniform="uniform")
        self.stepping_frame.grid_columnconfigure(3, weight=1, uniform="uniform")
        self.stepping_frame.grid_columnconfigure(4, weight=1, uniform="uniform")
        self.stepping_frame.grid_columnconfigure(5, weight=1, uniform="uniform")
        self.stepping_frame.grid_columnconfigure(6, weight=1, uniform="uniform")
        self.stepping_frame.grid_columnconfigure(7, weight=1, uniform="uniform")
                                       # make sure word select is at bottom of values list
        self.outer_frame.rowconfigure(6, weight=1)
                      # make sure title bar and list fill width of window (less scrollbar)
        self.outer_frame.columnconfigure(1, weight=1)

    def format(self, format, short_list):
        """ format items """
                                                                          # current values
        self.pointer_label.config(font=(format["current_values"]["font"],
                                        format["current_values"]["font_size"]))
        self.carry_label.config(font=(format["current_values"]["font"],
                                        format["current_values"]["font_size"]))
        self.data_add_label.config(font=(format["current_values"]["font"],
                                        format["current_values"]["font_size"]))
        self.ret_add_label.config(font=(format["current_values"]["font"],
                                        format["current_values"]["font_size"]))
        self.keycode_label.config(font=(format["current_values"]["font"],
                                        format["current_values"]["font_size"]))
        self.disp_en_label.config(font=(format["current_values"]["font"],
                                        format["current_values"]["font_size"]))
                                       # we don't show the components if the list is short 
        if not short_list:
            self.component_title.config(font=(format["current_values"]["font"],
                                            format["current_values"]["font_size"]))
            self.component_label.config(font=(format["current_values"]["font"],
                                            format["current_values"]["font_size"]))
                                                                      # list - left spacer
        self.lefthand.config(font=(format["list"]["font"],
                                   format["list"]["font_size"]),
                                   height=self.initial_height+3)  # +3 as list adds height
                                                                     # list - right spacer
        self.righthand.config(font=(format["list"]["font"],
                                  format["list"]["font_size"]))
                                                                        # list - title bar
        self.ot_label.config(font=(format["list"]["font"],
                                   format["list"]["font_size"]))
                                                                   # list - execution list
        self.listbox.config(font=(format["list"]["font"],
                                  format["list"]["font_size"]),
                                  height=self.list_height)
                                                                     # list - right spacer
        self.righthand.config(font=(format["list"]["font"],
                                  format["list"]["font_size"]))
                                                                        # stepping buttons
        for button,_ in self.buttons:
            button.config(font=(format["stepping_buttons"]["button_font"],
                                format["stepping_buttons"]["button_font_size"]), \
                                width=format["stepping_buttons"]["button_width"])

    def theme(self, theme, data_address_support, short_list):
        """ apply theme """
                                                                             # outer frame
        self.outer_frame.config(bg=theme["window_background"])
                                                                          # current values
        self.pointer_frame.config(bg=theme["list_background"],
                                highlightbackground=theme["current_text_font"])
        self.pointer_label.config(bg=theme["list_background"],
                                  fg=theme["current_text_font"])
        self.carry_frame.config(bg=theme["list_background"],
                                highlightbackground=theme["current_text_font"])
        self.carry_label.config(bg=theme["list_background"],
                                fg=theme["current_text_font"])
        if data_address_support:
            self.data_add_frame.config(bg=theme["list_background"],
                                highlightbackground=theme["current_text_font"])
            self.data_add_label.config(bg=theme["list_background"],
                                       fg=theme["current_text_font"])
        else:
            self.data_add_frame.config(bg=theme["list_background"],
                            highlightbackground=theme["current_text_disabled"])
            self.data_add_label.config(bg=theme["list_background"],
                                       fg=theme["current_text_disabled"])
        self.ret_add_frame.config(bg=theme["list_background"],
                                highlightbackground=theme["current_text_font"])
        self.ret_add_label.config(bg=theme["list_background"],
                                  fg=theme["current_text_font"])
        self.keycode_frame.config(bg=theme["list_background"],
                                highlightbackground=theme["current_text_font"])
        self.keycode_label.config(bg=theme["list_background"],
                                  fg=theme["current_text_font"])
        self.disp_en_frame.config(bg=theme["list_background"],
                                highlightbackground=theme["current_text_font"])
        self.disp_en_label.config(bg=theme["list_background"],
                                  fg=theme["current_text_font"])
                                       # we don't show the components if the list is short 
        if not short_list:
            self.component_frame.config(bg=theme["list_background"],
                                highlightbackground=theme["current_text_font"])
            self.component_title.config(bg=theme["window_background"],
                                        fg=theme["current_text_font"])
            self.component_label.config(bg=theme["list_background"],
                                        fg=theme["current_text_font"])
                                                                           # list - frames
        self.list_frame.config(bg=theme["list_background"],
                               highlightbackground=theme["list_font"],
                               highlightcolor=theme["list_font"])
        self.ot_frame.config(bg=theme["list_background"],
                             highlightbackground=theme["list_background"])
                                                                      # list - left spacer
        self.lefthand.config(bg=theme["list_background"],
                             fg=theme["list_font"])                                                                        
                                                                        # list - title bar
        self.ot_label.config(bg=theme["list_title_background"],
                             fg=theme["list_title_font"],
                             highlightbackground=theme["list_background"])
                                                                   # list - execution list
        self.listbox.config(bg=theme["list_background"], fg=theme["list_font"],
                                   selectbackground=theme["list_select"],
                                   selectforeground=theme["list_select_font"])
                                                                      # list - left spacer
        self.righthand.config(bg=theme["list_background"], fg=theme["list_font"])

        self.stepping_frame.config(bg=theme["stepping_label_background"],
                                   highlightbackground=theme["list_title_font"])
                                                                        # stepping buttons
        for button,_ in self.buttons:
            button.config(highlightbackground=theme["stepping_label_background"])

    def finishPreparation(self, title_string, start_strings, rom_strings,
                          current_line):
        """ finish setting up the list pane for the start of a new operation: 
        most of this processing is done in the main class as it uses multiple
        preferences, flags and methods """
        self.clear()
                                                                            # list - title
        self.list_title_string.set(title_string)
                                                    # add start state to beginning of list
        for string in start_strings:
            self.listbox.insert(tk.END, string)
                                                                              # list items
        if len(rom_strings) > 0:                  # add ROM listing to list if in ROM mode
            for string in rom_strings:
                self.listbox.insert(tk.END, string)
        self.listbox.see(current_line)    # 0 if INS mode, current ROM/address if ROM mode

    def updateCurrentVals(self, current_values_tuple, data_address_support,
                          short_list):
        """ update the current values at the top of the list pane """
        p = current_values_tuple[0]
        pointer_text =   f"POINTER         {p:>3}"
        carry_text =     f"CARRY           {current_values_tuple[1]:>3}"
        if data_address_support:
            data_a_text = f"DATA ADDRESS    {current_values_tuple[2]:>3}"
        else:
            data_a_text = f"DATA ADDRESS"
        return_a_text =  f"RETURN ADDRESS  {current_values_tuple[3]:>03}"
        keycode_text =   f"KEYCODE         {current_values_tuple[4]:>03}"
        if current_values_tuple[5] == 0:
            d_string = "OFF"
        else:
            d_string = " ON"
        display_e_text = f"DISPLAY         {d_string}"
        self.pointer_val.set(pointer_text)
        self.carry_val.set(carry_text)
        self.data_add_val.set(data_a_text)
        self.ret_add_val.set(return_a_text)
        self.keycode_val.set(keycode_text)
        self.disp_en_val.set(display_e_text)
                                       # we don't show the components if the list is short 
        if not short_list:
            if p > 13:                         # can't show P-dependent components if P>13
                components_text_pointer = (f"P      pointer > 13\n"
                            f"WP     pointer > 13")
            else:
                components_text_pointer = (f"P  [{'.'*(13-p)}{hex(p)[2:]}{'.'*(p)}]\n"
                            f"WP [{'.'*(13-p)}{'dcba9876543210'[(13-p)::]}]")           
            components_text = (f"{components_text_pointer}\n"
                            f"X  [...........210]\n"
                            f"XS [...........2..]\n"
                            f"M  [.cba9876543...]\n"
                            f"MS [dcba9876543...]\n"
                            f"W  [dcba9876543210]\n"
                            f"S  [d.............]")
            self.component_list.set(components_text)     

    def finishNewLine(self, list_mode, update_mode, list_strings, line,
                      total_byte_count):
        """ add new line to the list: most of this processing is done in the
        main class as it uses multiple preferences, flags and methods """
        if list_mode == 1:                                        # if list mode is INS...
            for string in list_strings:                  # ...add new lines to end of list
                self.listbox.insert(tk.END, string)
            if update_mode != 0:                      # if update mode is LIVE or STEP ...
                self.listbox.see(tk.END)                             # ...show end of list
        else:
            self.listbox.select_clear(0, tk.END)                  # if list mode is ROM...
            self.listbox.delete(line)       # ...delete line at current ROM/address and...
            self.listbox.insert(line, list_strings[0])      # ...replace with updated line
            self.listbox.select_set(line)                             # highlight new line
            if line < total_byte_count / 2:   # scroll to top or bottom of list to keep...
                self.listbox.see(tk.END)         #... new line in center of list on screen
            else:
                self.listbox.see(0)
            self.listbox.see(line)                                    # scroll to new line

    def loopMessage(self, update_mode):
        """ add a message about background key-wait loop running after
        foreground key-wait loops completed """
        self.listbox.insert(tk.END, "")
        self.listbox.insert(tk.END, "        CALCULATOR NOW RUNNING LOOP MARKED"
                                    " '>' IN THE BACKGROUND, UNTIL KEYPRESS"
                                    " RECEIVED AND STATUS BIT 0 SET HIGH")
        self.listbox.insert(tk.END, "")
        if update_mode > 0:                     # show end of list if in LIVE or STEP mode
            self.listbox.see(tk.END)

    def matchButtonToInstructions(self, steps_requested):
        """ instruction/condition buttons just request a large number of steps:
        these are decoded to instructions here """
        match steps_requested:
            case 2001: ins_match = ("clearAllRegs", "clearReg", "copyReg",
                                    "exchangeRegs", "addRegs", "subRegs",
                                    "incReg", "decReg", "negReg", "negDecReg")
            case 2002: ins_match = ("rShiftReg", "lShiftReg")
            case 2003: ins_match = ("pushC", "popA", "rotateDown")
            case 2004: ins_match = ("setDataAddress", "dataToC", "cToData")
            case 2005: ins_match = ("loadConstant")
            case 2006: ins_match = ("goTo")
            case 2007: ins_match = ("jumpSub", "ret")
            case 2008: ins_match = ("selectRom")
            case 3001: ins_match = ("setP", "incP", "decP", "ifPNotValue")
            case 3002: ins_match = ("clearAllStatus", "clearStatus", "setStatus",
                                    "ifSBitZero")
            case 3003: ins_match = ("displayOff", "displayToggle")
            case 3004: ins_match = ("keyGoTo")
            case 3005: ins_match = ("nOp")
            case 3006: ins_match = ("ifRegZero", "ifRegReg", "ifRegOne")
            case 3007: ins_match = ("carry 0 to 1")
            case 3008: ins_match = ("ifPNVfalse")
            case _:    ins_match = ("")
        return ins_match
    
    def performCarryChecks(self, ins_match, instruction, carry, ac_last_carry):
        """ the carry and P condition buttons need to look at the carry bit
        as well as the instruction """
        if ins_match == "ifPNVfalse":
            if instruction == "ifPNotValue" and carry == 1:
                ins_match = instruction
        if ins_match == "carry 0 to 1":
            if ac_last_carry == 0 and carry == 1:
                ins_match = instruction
        return ins_match

    def showHide(self, mode):
        """ show or hide the list pane depending on list mode """
        if mode != 0:                                                    # INS or ROM mode
            self.outer_frame.grid(row=3, column=1, columnspan=4,
                                  sticky="nsew", padx=0, pady=(10,0))
        else:
            self.outer_frame.grid_forget()

    def showStepping(self):
        """ show the stepping buttons """
        self.stepping_frame.grid(row=2, column=1, padx=0, pady=0, sticky="sew")

    def hideStepping(self):
        """ hide the stepping buttons """
        self.stepping_frame.grid_forget()

    def clear(self):
        """ clear the contents of the list """
        self.listbox.delete(0, tk.END)

    def showHideScroll(self, sbar):
        """ show or hide the scrollbar on the right of the list """
        if sbar:
            self.scrollbar.grid(row=0, column=2, rowspan=3, sticky="nse")
        else:
            self.scrollbar.grid_forget()

    def decreaseHeightStepping(self, reduction):
        """ called if stepping buttons or ROM details shown to avoid window
        exceeding height of screen """
        self.list_height = self.list_height - reduction
        if self.list_height < 5:
            self.list_height = self.list_height + reduction
        self.listbox.config(height = self.list_height)

    def increaseHeightStepping(self, increase):
        """ called if stepping buttons or ROM details hidden """
        self.list_height = self.list_height + increase
        if self.list_height > self.initial_height:
            self.list_height = self.initial_height
        self.listbox.config(height = self.list_height)

class Keyboard:
    """ the on-screen calculator keyboard, generated from elements of the
    external preferences file """
    def __init__(self, kb_format, calc_bindings, keycodes, mode):
        """ set up layout and format and show if keyboard shown at start """
        self.layout()
        self.format(kb_format, calc_bindings, keycodes)
        self.showHide(mode)

    def layout(self):
        """ layout of components """
                                                                                  # frames
        self.outer_frame = tk.Frame(root, bg="#000", highlightthickness=0,
                                    borderwidth=0, padx=0, pady=0)
        self.frame = tk.Frame(self.outer_frame, bg="#000",
                              highlightbackground="#000",
                              highlightthickness=1, padx=10, pady=10)
        self.frame.grid(row=1, column=0, sticky="nsew", padx=0, pady=0)
                                                                   # empty title as spacer
        self.title = tk.Label(self.outer_frame,
                text="", anchor="nw",
                justify=tk.LEFT, height=1, padx=0, pady=0,
                highlightthickness=0, borderwidth=0, bg="#000", fg="#000")
        self.title.grid(row=0,column=0, sticky="nw", padx=0, pady=2)
                                                   # list of labels above buttons and font
        self.upper_labels = []
        self.upper_label_font = ""
                                                                # list of buttons and font
        self.buttons = []
        self.button_font = ""
                                                   # list of labels below buttons and font
        self.lower_labels = []
        self.lower_label_font = ""
                              # list of binding_numbers (keyboard entry codes) for buttons
        self.binding_numbers = []
                                               # make sure keyboard fills height of window
        self.outer_frame.rowconfigure(1, weight=1)

    def format(self, kb_format, calc_bindings, keycodes):
        """ format the items """
        self.title.config(font=(kb_format["title_font"],
                                kb_format["title_font_size"]))
                                                                    # labels above buttons
        self.upper_label_font = (kb_format["upper_label_font"],
                                 kb_format["upper_label_font_size"])
                                                                       # labels on buttons
        self.button_font = (kb_format["button_font"],
                            kb_format["button_font_size"])
                                                                    # labels below buttons
        self.lower_label_font = (kb_format["lower_label_font"],
                                 kb_format["lower_label_font_size"])
                                        # decode the preference file to produce a keyboard
        for _, key_details in calc_bindings.items():
            b_row = key_details["position"][0] * 4                            # button row
            b_col = key_details["position"][1]                             # button column
            b_width = kb_format["button_width"] * key_details["width"] #\
                                    #+ (4*(key_details["width"]-1))          # button width
            b_col_span = key_details["width"]                # width is 0 if key not shown
            b_text = key_details["label"]                                # label on button
            u_text = key_details["upper_text"]                        # label above button
            b_key = key_details["readable_key"]    # label under button (less "key:" text)
            binding_number = keycodes[key_details["bind_to"]]             # button keycode
                                              # if button is shown then add it to keyboard
            if key_details["width"] != 0:
                upper_label = tk.Label(self.frame, text=u_text,       # label above button
                                       font=self.upper_label_font)
                upper_label.grid(row=b_row, column=b_col, columnspan=b_col_span,
                                 padx=0, pady=0)
                button = tk.Button(self.frame, text=b_text,                       # button
                                   font=self.button_font, width=b_width)
                button.grid(row=b_row+1, column=b_col, columnspan=b_col_span,
                            padx=2, pady=0)
                lower_label = tk.Label(self.frame,                    # label below button
                                       text="key: "+b_key, height=2, anchor="n",
                                       font=self.lower_label_font)
                lower_label.grid(row=b_row+2, column=b_col,
                                 columnspan=b_col_span, padx=0, pady=0)
                      # update lists of labels and buttons for use in theme and main class
                self.upper_labels.append(upper_label)
                self.buttons.append(button)
                self.lower_labels.append(lower_label)
                self.binding_numbers.append(binding_number)

    def theme(self, theme):
        """ apply theme """
                                                                                  # frames
        self.outer_frame.config(bg=theme["window_background"],
                          highlightbackground=theme["window_background"])
        self.frame.config(bg=theme["keyboard_background"],
                          highlightbackground=theme["keyboard_border"])
                                                                   # empty title as spacer
        self.title.config(bg=theme["window_background"],
                          fg=theme["window_background"])
                                                                    # labels above buttons
        for upper_label in self.upper_labels:
            upper_label.config(bg=theme["keyboard_background"],
                               fg=theme["keyboard_upper_label_font"])
                                                                                 # buttons
        for button in self.buttons:
            button.config(highlightbackground=theme["keyboard_background"])
                                                                    # labels below buttons
        for lower_label in self.lower_labels:
            lower_label.config(bg=theme["keyboard_background"],
                               fg=theme["keyboard_lower_label_font"])

    def showHide(self, mode):
        """ show or hide the keyboard """
        if mode == 1:                                                   # keyboard on left
            self.outer_frame.grid(row=0, column=0, rowspan=5, sticky="nsw",
                                  padx=(0,10), pady=(10,1))
        elif mode == 2:                                                # keyboard on right
            self.outer_frame.grid(row=0, column=5, rowspan=5, sticky="nse",
                                  padx=(10,0), pady=(10,1))
        else:                                                            # keyboard hidden
            self.outer_frame.grid_forget()

class Divider:
    """ a single, invisible canvas line the same size as the rom map which
    ensures the window does not change size when the rom map is hidden - the
    correct way to do this is left as an exercise for the reader """
    def __init__(self, format, rom_count, rom_byte_count):
        """ initialize variables, set up layout and format and show if shown
        at start """
        self.layout()
        self.format(format, rom_count, rom_byte_count)

    def layout(self):
        """ layout of map components """
                                                                                   # frame
        self.frame = tk.Frame(root, borderwidth = 0, highlightthickness = 0,
                              bg="#000", padx=0, pady=0)
                                                                                  # canvas
        self.canvas = tk.Canvas(self.frame, borderwidth = 0,
                                highlightthickness = 0, bg="#000")
        self.canvas.grid(row=0, column=0)
        self.frame.grid(row=4,column=1,columnspan=4)

    def format(self, format, rom_count, rom_byte_count):
        """ format the items """
                                                                                  # canvas
        self.rom_separator = format["map"]["rom_separator"]       # space between ROM bars
        self.byte_width = format["map"]["byte_width"]                   # width of address
        self.byte_separator = format["map"]["byte_separator"]    # space between addresses
        self.number_of_roms = rom_count
        self.total_width = ((self.byte_width + self.byte_separator) * rom_byte_count) \
                                    - self.byte_separator + 1
        self.canvas.config(height=1)
        self.canvas.config(width=self.total_width)

    def theme(self, theme):
        """ apply theme """
                                                                                   # frame
        self.frame.config(bg=theme["window_background"])
                                                                                  # canvas
        self.canvas.config(bg=theme["window_background"])
        self.canvas.delete("all")
        self.canvas.create_rectangle(0, 0, self.total_width, 1, 
                                     outline = theme["window_background"],
                                     fill = theme["window_background"])

class HelpWindow:
    """ a help window which gives access to the help text accompanying the
    simulator """
    def __init__(self, help_file, h_format, start_page, theme):
        """ initialize variables, create the help window, populate it, set
        layout and format, and apply theme """
                                                                    # initialize variables
        self.help_file = help_file
        self.buttons = []
        row_number = 0
        self.main_text = ""
        self.more_text = ""
        height_nb = h_format["height"]
        height_wb = h_format["height_with_button"]
                                                                      # create help window
        self.help_window = tk.Toplevel()
        self.help_window.resizable(False,False)
        self.help_window.configure(padx=15, pady=15)
        self.help_window.title(f"HP-1973    (version {version})")
                                                               # frame on left for buttons
        self.button_frame = tk.Frame(self.help_window, highlightthickness=0,
                                     borderwidth=0, padx=0, pady=0)
        self.button_frame.grid(row=0, column=0, sticky="ns")
                                                                 # frame on right for text
        self.text_frame = tk.Frame(self.help_window, padx=10, pady=10,
                                   highlightthickness=1)
        self.text_frame.rowconfigure(0, weight=1)
                                                                               # help text
        self.help_text = tk.Text(self.text_frame, width = 90, wrap='word',
                                 font=(h_format["font"],h_format["font_size"]),
                                 padx=0, pady=0, highlightthickness=0,
                                 borderwidth=0, state=tk.DISABLED)
        self.help_text.grid(row=0, column=0, sticky="ns")
        self.righthand = tk.Label(self.text_frame, text="", width = 3, 
                                 font=(h_format["font"],h_format["font_size"]),
                                 padx=0, pady=0, highlightthickness=0,
                                 borderwidth=0)
        self.righthand.grid(row=0, column=1, rowspan=2, sticky="e")
                                                                               # scrollbar
        self.scrollbar = tk.Scrollbar(self.text_frame, orient="vertical",
                                      width=11)
        self.scrollbar.config(command=self.help_text.yview)
        self.help_text.config(yscrollcommand=self.scrollbar.set)
                                                             # detailed information button
        self.more_button = tk.Button(self.text_frame,
                                    font=(h_format["font"],
                                          h_format["button_font_size"]),
                                    text="show detailed information", padx=3,
                                    command=lambda:self.showMore(height_nb))
                                                                # add text frame to window
        self.text_frame.grid(row=0, column=1, sticky="ns", padx=(10,0), pady=0)
                               # create button for each page of help, binding to help text
        for help_page, help_page_content in self.help_file.items():
            self.button = tk.Button(self.button_frame, text=f"{help_page}",
                                    anchor="center",
                                    font=(h_format["font"],
                                          h_format["button_font_size"]), 
                                    width=h_format["button_width"],
                                    height=help_page.count('\n')+2,
                                    highlightthickness=0, borderwidth=0, 
                                    command=lambda content \
                                        = help_page_content: \
                                        self.updateText(content, height_nb, height_wb))
            self.button.grid(row=row_number, column=0, padx=0,
                             pady=(0,6), sticky="nw")
            self.buttons.append(self.button)
            row_number += 1
                                               # add exit help button to help page buttons
        self.exit_button = tk.Button(self.button_frame, text=f"Exit Help",
                                     font=(h_format["font"],
                                           h_format["button_font_size"]),
                                     anchor="center",
                                     width=h_format["button_width"], height=2,
                                     highlightthickness=0, borderwidth=0)
        self.exit_button.grid(row=row_number, column=0, pady=(0,0),
                              sticky="sw")
                                                                             # apply theme
        self.theme(theme)
                                                             # show some initial help text
        self.updateText(self.help_file[start_page], height_nb, height_wb)

    def theme(self, theme):
        """ apply theme """
                                                                                  # window
        self.help_window.config(bg=theme["list_background"])
                                                                            # button frame
        self.button_frame.config(bg=theme["list_background"])
                                                                                 # buttons
        for button in self.buttons:
            button.config(highlightbackground=theme["list_background"])
                                                                        # exit help button
        self.exit_button.config(highlightbackground=theme["list_background"])
                                                                              # text frame
        self.text_frame.config(bg=theme["list_background"],
                               highlightbackground=theme["list_font"],
                               highlightcolor=theme["list_font"])
                                                                               # help text
        self.help_text.config(bg=theme["list_background"],
                              fg=theme["list_font"])
        self.righthand.config(bg=theme["list_background"],
                              fg=theme["list_font"])
                                                             # detailed information button
        self.more_button.config(highlightbackground=theme["list_background"])

    def updateText(self, help_page_content, height_nb, height_wb):
        """ update help text if button pressed """
        self.help_text.config(state=tk.NORMAL)                      # allow text to update
        self.scrollbar.grid_forget()             # hide scrollbar in case no longer needed
        self.main_text = help_page_content["main"]           # get main help text for page
        self.more_text = help_page_content["more"]         # get detailed information text
        self.help_text.delete('1.0', tk.END)         # clear the help text currently shown
        self.help_text.insert('1.0', self.main_text)         # show the new main help text
        if self.more_text != "":         # show detailed information button if required...
            self.more_button.grid(row=1, column=0, sticky="se", padx=(0,20), pady=(5,0))
            use_height = height_nb
        else:                                                       # ...otherwise hide it
            self.more_button.grid_forget()
            use_height = height_wb
                                 # if text has more lines than can be shown, add scrollbar
        self.help_window.update_idletasks()              # needed prior to count initially
        if self.help_text.count(1.0, tk.END, "displaylines")[0] > use_height:
            self.scrollbar.grid(row=0, column=1, rowspan=2, sticky="nse")
        self.help_text.config(state=tk.DISABLED)       #prevent user from typing into text

    def showMore(self, height_nb):
        """ show additional information text if additional information button
        clicked """
        self.help_text.config(state=tk.NORMAL)                      # allow text to update
        self.more_button.grid_forget()                # hide additional information button
                             # add additional information text at end of current help text
        self.help_text.insert(tk.END, f"\n\n{'-'*90}\n\n" + self.more_text)
                                                           # add scrollbar if now required
        if self.help_text.count(1.0, tk.END, "displaylines")[0] > height_nb:
            self.scrollbar.grid(row=0, column=1, rowspan=2, sticky="nse")
        self.help_text.config(state=tk.DISABLED)       #prevent user from typing into text

class Simulator(AugmentedCalculator):
    """ the simulator which hosts the calculator """
    def __init__(self, sp_file):
        """ initialize the simulator """
        self.sp = SimPreferences(sp_file)  # read preference file and populate preferences
        root.title(f"{self.sp.title}")           # set title (until calculator-ROM chosen)
        self.createMenus()
                            # read calculator definitions file and reformat calculator-ROM
                            # information and hash tables for use in calculator-ROM select
                            # and ROM details pane
        definitions = self.populateDefinitions(self.sp.calc["file"])
                                           # show calculator-ROM select window if required
        if self.sp.calc["prompt_for_calc"]:
            theme = self.sp.themes[self.sp.theme_names[self.sp.theme_initial_number]]
            self.cars = CalcAndROMSelect(self.sp.format, theme,
                                         self.sp.calc["default_type"],
                                         self.sp.calc["default_rom"],
                                         definitions,
                                         self.sp.using_normal_prefs)
                                # bind select rom button here to bind to main class method
            self.cars.select_rom_button.bind("<Button-1>", lambda event: \
                            self.selectedCalcRom(self.cars.selected_calculator,
                                                 self.cars.selected_rom_version,
                                                 definitions))
        else:
                                  # just use default calculator-ROM if select not required
            self.selectedCalcRom(self.sp.calc["default_type"],
                                 self.sp.calc["default_rom"],
                                 definitions)

    def selectedCalcRom(self, calculator_name, rom_version, definitions):
        """ continue start-up processing once calculator-ROM has been chosen """
                                            # hide calculator-ROM select window if showing
        if self.sp.calc["prompt_for_calc"]:
            self.cars.hide()
                     # initialize an augmented calculator (which initializes a calculator)
        AugmentedCalculator.__init__(self, calculator_name, rom_version,
                                     definitions, self.sp.calc["file"])
                                                                 # set the window title...
        root.title("HP-1973 (A 50th Anniversary Electronic Slide Rule)")
                                            # populate simulator flags with initial values
        self.sf = SimFlags(self.sp.prefs, self.sp.theme_initial_number,
                           self.sp.theme_names, self.ac_storage_support)
                                                      # initialize key-wait loop variables
        self.kl = Keyloop()
        calculator_rom_text = (f"{calculator_name.upper()} : {rom_version.upper()} ROM")
        if self.ac_known_bugs:                  # ...and add warning if ROM has known bugs
            calculator_rom_text += f" (WARNING: KNOWN BUGS)"
                                            # initialize pane: calculator display and info
        self.display_pane = Display(self.sp.format, calculator_rom_text)
                                                        # initialize pane: simulator flags
        self.flags_pane = FlagSettings(self.sp.format)
                                                              # initialize pane: internals
        self.internals_pane = Internals(self.sp.format["registers"],
                                        self.ac_lastx_support)
                                                                # initialize pane: ROM map
        self.map_pane = Map(self.sp.format, self.ac_rom_count,
                            self.ac_rom_byte_count, self.sf.map_active)
                                                                   # initialize pane: list
        self.list_pane = List(self.sp.format, self.sp.list_height,
                              self.sf.list_mode, self.sf.scrollbar,
                              self.sp.short_list)
                                                                # initialize pane: divider
        self.divider_pane = Divider(self.sp.format, self.ac_rom_count,
                            self.ac_rom_byte_count)
                                                      # initialize pane: onscreen keyboard
        self.gui_keyboard = Keyboard(self.sp.format["keyboard"],
                                     self.sp.bindings[calculator_name],
                                     self.keycodes, self.sf.keyboard_mode)
        self.ac_current_rom = self.ac_CurrentROMValue()                  # set current ROM
        self.ac_next_rom = self.ac_CurrentROMValue()     # set next ROM as same as current
                       # bind computer keyboard and onscreen keyboard and stepping buttons
        self.bindCalcKeysToKbd()
        self.bindSimKeysToKbd()
        self.bindCalcKeysToOSKbd()
        self.bindSteppingButtons()
                                                           # fill information help page...
        self.populateHelpInformationPage()
                               #...and enable menu items now we have necessary information
        self.menubar.entryconfig("System", state=tk.NORMAL)
        self.menubar.entryconfig("Help", state=tk.NORMAL)
                   # populate dictionary used when showing key press at start of list pane
        self.populateKeycodeDecodeDict()
                                                                               # set theme
        self.setTheme()
                           # populate initial calculator info, display and simulator flags
        self.display_Update()
        self.display_pane.updateCalcInfo(self.internal[r_m], self.status,
                                         self.ac_calc_info_flags,
                                         self.sf.display_mode)
        self.flags_pane.updateFlags(self.sp.themes[self.sf.theme_current_name],
                                    self.sf.flagTuple(),
                                    self.ac_storage_support,
                                    self.ac_m_register_sci)
                                   # call processKey for first time with 'dummy' key press
        self.processKey(99)

    # ----------- methods for processing key presses and operations (except key-wait loop)

    def getAKey(self, keycode):
        """ pressing a computer or onscreen key passes its keycode to this method; if
        the key-wait loop is not running in the background then the method sets status
        bit 0 high so the calculator knows a key has been pressed, and calls processKey
        with the keycode; if the key-wait loop is running in the background this method
        just sets self.keycode and the background key-wait loop method picks this up
        and triggers the necessary call to processKey """
        self.keycode = keycode
        if not self.keyloop_RunBackgroundLoop():
            self.setStatus([0])
            self.processKey(self.keycode)

    def processKey(self, keycode):
        """ begin processing of a onscreen or computer keyboard key press"""
        self.kl.reset()                               # reset the background key-wait loop
        if keycode >= 200:                     # if a simulator key is pressed, process it
            self.processSimKeys(keycode)
        else:                                   # otherwise process a calculator key press
            if keycode == 99:                    # if we're here as part of turning on ...
                keycode = 0                     # ... change keycode to 0 and continue ...
            else:                                                      # ... otherwise ...
                self.sf.just_turned_on = False                  # ... we're up and running
            self.display_pane.updateStatus("WORKING",
                                    self.sp.themes[self.sf.theme_current_name])             
                                          # if map active, set start ROM/address and clear
            if self.sf.map_active:
                self.map_pane.setStart(self.ac_next_rom, self.next_address)
                self.map_pane.clear()
                                                            # if list active, prepare list
            if self.sf.list_mode != 0:
                self.list_Prepare()
                                                    # process key depending on update mode
            if self.sf.update_mode == 2:
                self.processSteppingStart()                                # for STEP mode
            else:
                self.processThisKey()                              # for END or LIVE modes

    def processThisKey(self):
        """ process calculator operation caused by keypress (if update mode is
        END or LIVE) """
                                       # process in foreground until we've shown required
                                       # number of background key-wait loops in foreground
        while self.kl.cycle_count <= self.kl.total_loops_to_show:
            self.processCommonCore()       # processing common to END, LIVE and STEP modes
                                     # update simulator upper panes if update mode is LIVE
            if self.sf.update_mode == 1:
                self.internals_UpdateRegisters()
                self.display_Update()
                self.display_pane.updateCalcInfo(self.internal[r_m],
                                self.status,
                                self.ac_calc_info_flags, self.sf.display_mode)
                       # update current values if list pane active and update mode is LIVE
                if self.sf.list_mode !=0:
                    self.list_pane.updateCurrentVals(
                            self.ac_CurrentValsTuple(self.sf.just_turned_on,
                                                     self.sf.base, self.toBase),
                            self.ac_data_address_support, self.sp.short_list)
                root.update_idletasks()                              # ensure panes update
        self.processComplete()           # finish up: time to run background key-wait loop

    def processCommonCore(self):
        """ process byte at ROM/address: common to END, LIVE and STEP update
        modes """
        self.ac_CopyCurrenttoLast()    # store calculator state before current instruction
        self.ac_current_rom = self.ac_CurrentROMValue()         # get current ROM from ROE
        self.processByte()           # have calculator process byte at current ROM/address
        self.ac_next_rom = self.ac_CurrentROMValue()               # get next ROM from ROE
                                                                # update ROM map if active
        if self.sf.map_active:
            self.map_pane.update(self.ac_current_rom, self.current_address,
                                 self.ac_ShortInstructionString(),
                                 self.ac_next_rom, self.keycode)
                                                  # add line to list if in INS or ROM mode
        if self.sf.list_mode != 0:
            self.list_NewLine()
                # update display if instruction processed was diplay off or display toggle
        if self.ac_ShortInstructionString().startswith("display"):
            self.display_Update()
                   # update display if enabled and display shows garbage during op (HP-80)
        elif self.display_enabled == 1 and self.ac_display_garbage:
            self.display_Update()
            root.update_idletasks()                            # make sure display updates
                                         # if instruction is beginning of key-wait loop...
        if self.keyLoop_Start():
            if self.status[5] == 1:        # ...if blinking, show more loops in foreground
                self.kl.total_loops_to_show = 101
            self.kl.cycle_count += 1              # count number of foreground loops shown
    
    def processComplete(self):
        """ finish processing current operation and prepare for next """
                          # add key-wait loop explanation at end of list, if list mode INS
        if self.sf.list_mode == 1:
            self.list_pane.loopMessage(self.sf.update_mode)
                                                                        # update internals
        self.internals_UpdateRegisters()
                                                        # update the display and calc info
        self.display_Update()
        self.display_pane.updateCalcInfo(self.internal[r_m], self.status,
                                         self.ac_calc_info_flags,
                                         self.sf.display_mode)
                                               # update current values if list pane active
        if self.sf.list_mode != 0:
            self.list_pane.updateCurrentVals(
                            self.ac_CurrentValsTuple(self.sf.just_turned_on,
                                                     self.sf.base, self.toBase),
                            self.ac_data_address_support, self.sp.short_list)
                                                              # show calculator is "READY"
        self.display_pane.updateStatus("READY",
                                       self.sp.themes[self.sf.theme_current_name])
                   # we only actually run key-wait loop in background if blinking or timer
                   # or always-run preference set, otherwise just stop and wait for key
                   # press (saves CPU running in background for no good reason)
        # self.sf.just_turned_on = False  # no longer need to show calc started text in list
        if self.keyloop_RunBackgroundLoop():
            self.keycode += 300                           # set keycode to invalid keycode
            self.kl.loops_running += 1        # increment number of key-wait loops running
            self.processKeyloopByte()      # process  current ROM/address in key-wait loop

    def processSteppingStart(self):
        """ process calculator operation caused by keypress (if update mode
        is STEP) """
                           # unbind calculator and simulator keys apart from stepping keys
        self.unbindCalcKeysFromKbd()
        self.unbindSimKeysFromKbd()
        self.unbindCalcKeysFromOSKbd()
        h = self.sp.format["stepping_buttons"]["shrink_list_by"]
        self.list_pane.decreaseHeightStepping(h)          # make room for stepping buttons
        self.list_pane.showStepping()                          # show the stepping buttons
        self.processSteppingKey(1)    # send a dummy "1 step" press to start the operation

    def processSteppingKey(self, step):
        """ process the number of steps required by latest stepping button press """
        step_count = 0          # we haven't run any steps since the stepping button press
        self.display_pane.updateStatus("WORKING",
                                    self.sp.themes[self.sf.theme_current_name])
        root.update_idletasks()                       # make sure all panes are up to date
                                       # what are we matching (steps, instructions, carry)
        ins_match = self.list_pane.matchButtonToInstructions(step)
        if step > 1000:   # if matching instruction etc. then number of steps "run to end"
            step = 99999
        first_byte = True    # we're processing the first byte after stepping button press
                     # process steps as though in END or LIVE update mode while we haven't
                     # background key-wait loop and haven't completed necessary number of
                     # steps and haven't matched any requested instruction/carry and it's 
                     # not the first byte processed (need to process at least one byte
                     # before matching)
        while self.kl.cycle_count <= self.kl.total_loops_to_show and step_count != step \
                and (self.ac_ShortInstructionString() not in ins_match or first_byte):
            self.processCommonCore()
            step_count += 1
            first_byte = False                           # no longer processing first byte
                 # carry match stops execution by setting ins_match to current instruction
            ins_match = self.list_pane.performCarryChecks(
                                    ins_match, self.ac_ShortInstructionString(),
                                    self.carry, self.ac_last_carry)
        if not self.kl.cycle_count <= self.kl.total_loops_to_show:
                              # process end of operation if we've reached end of operation
            self.processSteppingEnd()
        else:
                                # prepare for next stepping button press by updating panes
            self.internals_UpdateRegisters()
            self.display_Update()
            self.display_pane.updateCalcInfo(self.internal[r_m], self.status,
                                             self.ac_calc_info_flags,
                                             self.sf.display_mode)
            if self.sf.list_mode != 0:                # update current info if list active
                self.list_pane.updateCurrentVals(
                            self.ac_CurrentValsTuple(self.sf.just_turned_on,
                                                     self.sf.base, self.toBase),
                            self.ac_data_address_support, self.sp.short_list)
            root.update_idletasks()
            self.display_pane.updateStatus("WAITING",
                                    self.sp.themes[self.sf.theme_current_name])

    def processSteppingEnd(self):
        """ process stepping operations needed at end of operation and then run
        processComplete as for END and LIVE update modes """
                                              # rebind computer and onscreen keyboard keys
        self.bindCalcKeysToKbd()
        self.bindSimKeysToKbd()
        self.bindCalcKeysToOSKbd()
        self.list_pane.hideStepping()                              # hide stepping buttons
        h = self.sp.format["stepping_buttons"]["shrink_list_by"]
        self.list_pane.increaseHeightStepping(h)   # increase height of list to fill space
        self.processComplete()                       # run same method as for END and LIVE

    # ----------------------------------------------- method for processing simulator keys

    def processSimKeys(self, keycode):
        """ prcess a key press which changes the simulator state rather than the 
        calculator """
        match keycode:
            case 200:              # select next list mode: 0=OFF, 1=INS, 2=ROM (and loop)
                self.sf.list_mode = (self.sf.list_mode + 1) % 3
                                                   # no STEP update mode if list not shown
                if self.sf.list_mode == 0 and self.sf.update_mode == 2:
                    self.sf.update_mode = 0
                self.list_pane.showHide(self.sf.list_mode)
                                                     # clear the list if we've unhidden it
                if self.sf.list_mode == 1:
                    self.list_Prepare()
            case 201:                                                     # toggle ROM map
                self.sf.map_active = not self.sf.map_active
                self.map_pane.showHide(self.sf.map_active)
            case 202:          # selext next update mode: 0=END, 1=LIVE, 2=STEP (and loop)
                if self.sf.list_mode == 0:
                    self.sf.update_mode = (self.sf.update_mode + 1) % 2
                else:
                    self.sf.update_mode = (self.sf.update_mode + 1) % 3
            case 203:                                          # toggle storage reg format
                if self.ac_storage_support or self.ac_m_register_sci:
                    self.sf.sci_view = not self.sf.sci_view
                    self.internals_UpdateRegisters()
            case 204:                                                               # quit
                root.destroy()
            case 205:                   # select next base: 0=DEC, 1=HEX, 3=OCT (and loop)
                self.sf.base = (self.sf.base + 1) % 3
                self.internals_UpdateRegisters()             # base of address has changed
                self.list_pane.updateCurrentVals(
                            self.ac_CurrentValsTuple(self.sf.just_turned_on,
                                                     self.sf.base, self.toBase),
                            self.ac_data_address_support, self.sp.short_list)
            case 206:                                       # select next theme (and loop)
                self.sf.theme_current_number = (self.sf.theme_current_number+1) \
                                                          % self.sp.theme_count
                self.sf.theme_current_name =  \
                              self.sp.theme_names[self.sf.theme_current_number]
                self.setTheme()
            case 207:                                                   # show help window
                self.showHelpWindow(self.sp.prefs["starting_help_page"])
            case 208:  # select next keyboard position: 0=OFF, 1=LEFT, 2= RIGHT (and loop)
                self.sf.keyboard_mode = (self.sf.keyboard_mode + 1) % 3
                self.gui_keyboard.showHide(self.sf.keyboard_mode)
            case 209:                                              # toggle list scrollbar
                if self.sf.list_mode != 0:
                    self.sf.scrollbar = not self.sf.scrollbar
                    self.list_pane.showHideScroll(self.sf.scrollbar)
            case 210:                                            # toggle calculator power
                self.togglePower()
            case 211:                                               # toggle zero-dot swap
                if self.sf.zero_swap == "0":
                    self.sf.zero_swap = "•"
                else:
                    self.sf.zero_swap = "0"
                self.internals_UpdateRegisters()
            case 212:                                # toggle address byte shown in binary
                if self.sf.list_mode != 0:
                    self.sf.binary = not self.sf.binary
            case 213:                                        # show calculator-ROM details
                self.showHelpWindow("Calculator-ROM\nInformation")
            case 214:                # select next display mode (0=AUTH, 1=FAST, 2=APPROX)
                self.sf.display_mode = (self.sf.display_mode + 1) % 3
                self.display_Update()
                self.display_pane.updateCalcInfo(self.internal[r_m],
                                                 self.status,
                                                 self.ac_calc_info_flags,
                                                 self.sf.display_mode)
            case 215:                                           # toggle low battery state
                if self.sf.display_mode == 0:
                    self.sf.low_battery = not self.sf.low_battery
                    self.display_Update()
                                                       # update flags display with changes
        self.flags_pane.updateFlags(self.sp.themes[self.sf.theme_current_name],
                                    self.sf.flagTuple(),
                                    self.ac_storage_support,
                                    self.ac_m_register_sci)

    # --------------------------------- methods for processing key-wait loop in background

    def processKeyloopByte(self):
        """ this method is first called at the end of processing an operation
        when the key-wait-loop has run a couple of times (more for blinking) in
        the foreground: it checks if a key has been pressed and if not it runs
        a few bytes of the key-wait loop in the background (without updating)
        the simulator window) and queues itself to run again after an interval;
        it continues this until a key has been pressed, at which point it calls
        processKey to process the key in the foreground """
                        # the ended flag is needed to ensure that a new processKeyLoopByte
                        # isn't queued to run after a key press has triggered processKey
        ended = False
                    # loops_running makes sure there's a maximum of one processKeyloopByte
                    # queued to run (otherwise an improper operation after an improper
                    # operation, or multiple timer inputs, can lead to multiple processKey
                    # methods running, which is a Bad Thing)
        self.kl.loops_running -= 1
        if self.ac_current_rom == self.ac_tl_rom:                      # in HP-45 timer...
            bytes_per_loop = self.sp.keyloop_timer_bpi    #... so set timer bytes per loop
        else:                                                              # otherwise ...
            bytes_per_loop = self.sp.keyloop_normal_bpi     #... set normal bytes per loop 
        if self.kl.loops_running == 0:    # process if no other processKeyLoopByte running
            if self.keycode < 300 and self.status[0] != 1:   #key press since last here...
                self.setStatus([0])                          # ...so set status bit 0 high
                                                    # run a few bytes of the key-wait loop
            for _ in range(bytes_per_loop):
                self.processByte()                             # calculator processes byte
                self.ac_current_rom = self.ac_CurrentROMValue()        #update current ROM
                self.keyloop_UpdateDisplayIfNeeded()            # update display if needed
                         # if this byte takes us out of the key-wait loop then process key
                if self.keyloop_Done():
                    self.processKey(self.keycode)
                    ended = True
            if not ended:  # queue the next run of processKeyloopByte if key-wait not over
                root.after(self.sp.keyloop_interval, self.processKeyloopByte)
                self.kl.loops_running += 1

    def keyloop_RunBackgroundLoop(self):
        """ determine if should run background loop or just halt processing
        calculator bytes and wait for key press: background loop will run if
        status bit 5 is high (blinking) or we're in calculator timer ROM
        (ac_tl_rom is set to 999 for calculators without timer) or preference
        is set to always run background loop """
        if self.status[5] == 1 or self.ac_current_rom == self.ac_tl_rom \
                                                or self.sp.always_loop_keywait:
            return True
        else:
            return False

    def keyloop_UpdateDisplayIfNeeded(self):
        """ update display during background key-wait loop if display changes
        from on to off or off to on, or if display is on and display_garbage
        is true (HP-80) """
        if self.ac_ShortInstructionString().startswith("display"):
                                                 # timer flicker tweak stops flickering in
                                                 # timer mode: see help page for details
            if self.sp.timer_flicker_tweak \
                                and self.ac_current_rom == self.ac_tl_rom \
                                and self.current_address == 169:
                pass
            else:
                self.display_Update() 
            root.update_idletasks()

    def keyLoop_Start(self):
        """ check to see if background key-wait loop should start: start
        requires next ROM/address to be keyloop start ROM / keyloop start
        address, or next ROM/address to be timer loop start ROM / timer loop
        start address """
        start = (self.ac_next_rom == self.ac_kl_rom \
                        and self.next_address == self.ac_kl_start_address) \
                    or (self.ac_next_rom == self.ac_tl_rom \
                        and self.next_address == self.ac_tl_start_address)
        return start

    def keyloop_Done(self):
        """ check to see if background key-wait loop should exit: exit
        requires next ROM/address to be keyloop exit ROM / keyloop exit
        address, or next ROM/address to be keyloop exit ROM / keyloop exit
        address """
        done = (self.ac_next_rom == self.ac_kl_rom \
                        and self.next_address == self.ac_kl_exit_address) \
                    or (self.ac_next_rom == self.ac_tl_rom \
                        and self.next_address == self.ac_tl_exit_address)
        return done

    # ----------------------------------------------- methods for updating window contents

    def setTheme(self):
        """ set the theme for all the panes / windows """
        theme = self.sp.themes[self.sf.theme_current_name]             # get current theme
        root.configure(bg=theme["window_background"])                        # main window
                                                                                 # display
        self.display_pane.theme(theme)
        self.display_Update()
                                                                                   # flags
        self.flags_pane.theme(theme, self.sf.flagTuple(),
                              self.ac_storage_support, self.ac_m_register_sci)
                                                                               # internals
        self.internals_pane.theme(theme, self.ac_storage_support,
                                  self.ac_lastx_support)
        self.map_pane.theme(theme, self.sf.map_active)                           # ROM map
                                                                         # values and list
        self.list_pane.theme(theme, self.ac_data_address_support,
                             self.sp.short_list)
        self.divider_pane.theme(theme)                                           # divider
        self.gui_keyboard.theme(theme)                                          # keyboard
        if self.sf.help_window_active:
            self.help_window.theme(theme)                        # help window (if active)

    def display_Update(self):
            """ uodate the calculator display """
            if self.sf.display_mode == 0:
                self.display_pane.update(self.authDisplay(self.sf.low_battery))
            elif self.sf.display_mode == 1:
                self.display_pane.updateFromDigits(self.fastDisplay())
            else:
                self.display_pane.updateFromDigits(self.approxDisplay())
            # this commented-out code compares the outputs of the 3 different
            # display modes: fast and auth should be the same, approx is the
            # same except for HP-80 'garbage' screens
            # authentic = ""
            # for segments in self.authDisplay():
            #     segment_list = segments.tolist()
            #     match segment_list:
            #         case [1,1,1,1,1,1,0,0]: character = "0"
            #         case [0,1,1,0,0,0,0,0]: character = "1"
            #         case [1,1,0,1,1,0,1,0]: character = "2"
            #         case [1,1,1,1,0,0,1,0]: character = "3"
            #         case [0,1,1,0,0,1,1,0]: character = "4"
            #         case [1,0,1,1,0,1,1,0]: character = "5"
            #         case [1,0,1,1,1,1,1,0]: character = "6"
            #         case [1,1,1,0,0,0,0,0]: character = "7"
            #         case [1,1,1,1,1,1,1,0]: character = "8"
            #         case [1,1,1,1,0,1,1,0]: character = "9"
            #         case [0,0,0,0,0,0,1,0]: character = "-"
            #         case [0,0,0,0,0,0,0,1]: character = "."
            #         case [0,0,0,0,0,0,0,0]: character = " "
            #     authentic += character
            # approx = self.approxDisplay()
            # fast = self.fastDisplay()
            # auth = authentic[::-1]
            # if approx != auth:
            #     int_regs = self.ac_InternalRegsDict()
            #     print(f"{int_regs['A']}")
            #     print(f"{int_regs['B']}")
            #     print(f"approx: |{approx:<15}|")
            #     print(f"auth:  |{authentic[::-1]:<15}|")
            # if fast != auth:
            #     print(f"fast:  |{fast():<15}|**********")

    def internals_UpdateRegisters(self):
        """ update the stack, internal registers, storage registers, status
        bits, ROE and address """
        int_regs = self.ac_InternalRegsDict()    # internal register strings in dictionary
        sto_regs = self.ac_StorageRegsDict()      # storage register strings in dictionary
        status = self.ac_StatusString(self.sp.show_status_high_to_low)     # status string
        roe = self.ac_ROEString(self.sp.show_roe_high_to_low)                 # ROE string
                                 # create the stack by converting registers to SCI9 format
        stack_string = (f"    T {self.internals_pane.regToSci(int_regs['F'])}\n"
                        f"    Z {self.internals_pane.regToSci(int_regs['E'])}\n"
                        f"    Y {self.internals_pane.regToSci(int_regs['D'])}\n"
                        f"    X {self.internals_pane.regToSci(int_regs['C'])}\n")
                          # create LASTx from R0 by converting to SCI9, if LASTx supported
        if self.ac_lastx_support:
            lastx_string = f"LASTx {self.internals_pane.regToSci(sto_regs['R0'])}"
        else:
            lastx_string = "LASTx"
                                                           # create current values strings
        current_values = self.ac_CurrentValsTuple(self.sf.just_turned_on,
                                                  self.sf.base, self.toBase)
        if self.ac_data_address_support:
            dat_text = f"DTA {current_values[2]}"
        else:
            dat_text = "     "
        values_string = (f"PTR {current_values[0]:>02} {dat_text} "
                         f"RETA {current_values[3]:>03}\n"
                         f"CRY {current_values[1]}  DSP {current_values[5]} "
                         f"KYCD {current_values[4]:>03}")
                      # if there are storage regs, create list: SCI9 & zero-swap if needed
        if self.ac_storage_support:
            sto_string = ""
            for name, reg in sto_regs.items():
                if self.sf.sci_view and not (name == "R0" \
                                    and self.sp.prevent_sci_view_for_r0):
                    sto_string += f"{name} {self.internals_pane.regToSci(reg)}\n"
                else:
                    sto_string += f"{name}  {self.zDot(reg)}\n"
        else:                                            # blank column if no storage regs
            sto_string = "                  "
                                       # create internal reg list with zero-swap if needed
        int_string = ""
        for name, reg in int_regs.items():
                                                           # M reg sci mode for some calcs
            if not(name == "M" and self.sf.sci_view and self.ac_m_register_sci):
                int_string += (f" {name}  {self.zDot(reg)}\n")
            else:
                int_string += (f" {name} {self.internals_pane.regToSci(reg)}\n")
                   # add status, ROE and address (in correct base) to internal regs string
        int_string += (f"\nSt  {status}\nROE {roe:>8}"
                    f" @ {self.toBase(self.current_address, self.sf.base):>03}")
                                                    # update the pane with the new strings
        self.internals_pane.stack_string.set(stack_string)
        self.internals_pane.lastx_string.set(lastx_string)
        self.internals_pane.working_string.set(values_string)
        self.internals_pane.sto_string.set(sto_string)
        self.internals_pane.int_string.set(int_string)

    def list_Prepare(self):
        """ prepare the list pane at the beginning of a new operation by
        clearing it, populating the first few lines with key pressed and
        starting state of calculator, adding ROM listing if in ROM mode, and
        positioning ready for first list line update """
        self.list_pane.ins_number = 1                    # restart the instruction counter
        self.list_pane.return_string = " "         # keeps track of jumpsub 'pseudo-depth'
        title_string = (("     ROM add  label    contents"                # list headings
                         "   --- instruction and parameters ----"
                        f"   --- state change {'-'*54}"))
        int_regs = self.ac_InternalRegsDict()     # the current register string dictionary
        sto_regs = self.ac_StorageRegsDict()       # the current storage string dictionary
                  # get the current status string in simple binary, zero-swapped if needed
        status = self.zDot(self.ac_StatusStringBinary(
                self.sp.show_status_high_to_low))
                            # get the current ROE in simple binary, zero-swapped if needed
        roe = self.zDot(self.ac_ROEStringBinary(
                self.sp.show_roe_high_to_low))
                                      # create a list of (zero-swapped) internal registers
        ints = []
        for name, reg in int_regs.items():
            ints.append(f"{name}  {self.zDot(reg)}   ")
                                       # create a list of (zero-swapped) storage registers
        stos = []
        for name, reg in sto_regs.items():
            stos.append(f"{name} {self.zDot(reg)}  ")
                                  # construct the start text for the beginning of the list
        current_values = self.ac_CurrentValsTuple(self.sf.just_turned_on,
                                                  self.sf.base, self.toBase)
        if self.ac_storage_support:
            da_string = f"DATA ADDRESS  {current_values[2]}    "
            da_spacer = ""
        else:
            da_string = ""
            da_spacer = f"                   "
        if self.display_enabled == 0:
            disp_string = "OFF"
        else:
            disp_string = " ON"
        current_values_string = (f"POINTER {current_values[0]:>02}    "
                                 f"CARRY {current_values[1]}    "
                                 f"{da_string}"
                                 f"RETURN ADDRESS {current_values[3]:>03}    "
                                 f"KEYCODE {current_values[4]:>03}    "
                                 f"DISPLAY {disp_string}"
                                 f"{da_spacer}")
        start_strings = [""]
                    # if calculator just turned on then add line to that effect, otherwise
                    # add line showing calculator key pressed and simulator equivalent
        if self.sf.just_turned_on:
            start_strings.append(" CALCULATOR TURNED ON")
        else:
            start_strings.append((" KEY   "
                                 f"{self.keycode_decode_dict[self.keycode][0]}  "
                                 f"{self.keycode_decode_dict[self.keycode][1]}"))
        start_strings.append("")
        start_strings.append(f" START {'-'*137}")
                                                  # if storage regs exist add storage regs
        if self.ac_storage_support:
            start_strings.append((f"       {stos[0]} {stos[1]} {stos[2]} "
                                  f"{stos[3]} {stos[4]}"))
            start_strings.append((f"       {stos[5]} {stos[6]} {stos[7]} "
                                  f"{stos[8]} {stos[9]}"))
            start_strings.append(f"       {'-'*137}")
                                                                       # add internal regs
        start_strings.append((f"       {ints[0]}{ints[1]}{ints[2]}"
                              f"{ints[3]}{ints[4]}{ints[5]}{ints[6]}"))
                                 # add line for current values string, status bits and ROE
        start_strings.append(f"       {'-'*97}+{'-'*39}")    
        start_strings.append((f"       {current_values_string}     |  St {status}"
                              f"    ROE {roe}"))
        start_strings.append(f" {'-'*103}+{'-'*39}")
        start_strings.append("")
        start_line = 0      # line to show when finished initial list, changed if ROM mode
        rom_strings = []              # an array to hold a ROM listing for use in ROM mode
                                                       # create ROM listing if in ROM mode
        if self.sf.list_mode == 2:
            for rom_number, rom in enumerate(self.ac_roms):
                for byte_number, byte in enumerate(rom):
                    rom_strings.append(self.list_ConstructLine(rom_number,
                                                               byte_number,
                                                               "populate"))
                                           # set first line to show to current ROM/address
            start_line += (self.ac_current_rom * self.ac_rom_byte_count) \
                            + self.current_address + self.sf.list_start_lines
                                               # update the list pane with the new strings
        self.list_pane.updateCurrentVals(
                            self.ac_CurrentValsTuple(self.sf.just_turned_on,
                                                     self.sf.base, self.toBase),
                            self.ac_data_address_support, self.sp.short_list)
        self.list_pane.finishPreparation(title_string, start_strings,
                                         rom_strings, start_line)

    def list_ConstructLine(self, rom, address, mode):
        """ put together the list line, not including the state changes """
        label = self.ac_Label(rom, address)                 # label of current ROM/address
        raw_byte = self.ac_RawByteValue(rom, address)              # address byte contents
        instruction = self.ac_InstructionString(rom, address)        # decoded instruction
        short_instruction = self.ac_ShortInstructionString(rom, address)       # short ins
        parameters = self.ac_ParameterList(rom, address)              # list of parameters
        branch_label = self.ac_BranchLabel(rom, address)     # label of any branch address
                             # convert parameters to string with addresses in correct base
        parameter_string = ""
        for param in parameters:
            if short_instruction == "goTo" or short_instruction == "jumpSub":
                parameter_string += f"{self.toBase(param, self.sf.base):>03}"
            else:
                parameter_string += f"{param}"
        this_instruction = instruction
                                        # construct current address string in correct base
        address_string = f"{self.toBase(address, self.sf.base):>03}"
                     # only if during execution: show branch execution and jumpsub nesting
        if mode == "execute":
                # if jumpSub(?) or GoTo instruction but carry == 1, add "not executed 'x'"
            if short_instruction == "jumpSub" and self.ac_last_carry == 1:
                this_instruction = "x|jumpSub #"
            elif short_instruction == "goTo" and self.ac_last_carry == 1:
                this_instruction = "> x|goto #"
                       # if we've just done a jumpsub, shown pseudo-nesting character (not
                       # actual nesting, as calculator only holds one return address)
            if self.ac_last_short_instruction == "jumpSub" \
                            and address == self.ac_last_parameters[0]:
                if self.list_pane.return_string == " ":
                    self.list_pane.return_string = "."                     # first jumpsub
                elif self.list_pane.return_string == ".":
                    self.list_pane.return_string = ":"                    # second jumpsub
                elif self.list_pane.return_string == ":":
                    self.list_pane.return_string = "|"       # third or subsequent jumpsub  
            elif self.ac_last_short_instruction == "ret":
                self.list_pane.return_string = " "                  # single return resets
                                           # convert contents to correct base or to binary
        raw_byte_string = self.toBase(raw_byte, self.sf.base, self.sf.binary)
        if self.sf.binary:
            raw_byte_string = self.zDot(f"{raw_byte_string:>010} ")
        else:
            raw_byte_string = f" [{raw_byte_string:>04}]    "
                                        # construct ROM contents part of line from strings
        if mode == "populate":
            rom_string_start = "       "
        else:
            rom_string_start = ""
                                            # replace parameter placeholder with parameter
        this_instruction = this_instruction.replace("@", parameter_string)
        this_instruction = this_instruction.replace("#", f"{parameter_string:>02}")
        this_instruction = this_instruction.replace("$", f"{parameter_string:<2}")
        if this_instruction[0] == ">":
            this_instruction = f"{' '*15}{this_instruction[1:]}"
        else:
            this_instruction = f"{this_instruction}"
        if branch_label != "":
            branch_label = f"({branch_label})"
            this_instruction += f" {branch_label:<8}"
        rom_string = (f"{rom_string_start} {rom}{self.list_pane.return_string}"
                      f"{address_string}  {label:<8} "
                      f"{raw_byte_string:>04}{this_instruction}")
        return f"{rom_string:<64}"

    def list_NewLine(self):
        """ add a new line to the list which shows the ROM/address just
        executed and the change to the state of the calculator as a result """
        rom_string = self.list_ConstructLine(self.ac_current_rom,
                                             self.current_address,
                                             "execute")
        values_string = ""
        if self.pointer != self.ac_last_pointer:                                 # pointer
                values_string += f"pointer {self.pointer:>02} | "
        if self.carry != self.ac_last_carry:                                       # carry
            values_string += f"carry {self.carry} | "
        if self.data_address != self.ac_last_data_address:                  # data address
            values_string += f"data address {self.data_address} | "
        if self.return_address != self.ac_last_return_address:            # return address
            return_address_in_base = self.toBase(self.return_address,
                                                 self.sf.base)
            values_string += f"return address {return_address_in_base:>03} | "
        if self.display_enabled != self.ac_last_display_enabled:                 # display
            if self.display_enabled == 1:
                values_string += f"display ON | "
            else:
                values_string += f"display OFF | "
        if not array_equal(self.status, self.ac_last_status):                     # status 
            binary_status = self.ac_StatusStringBinary(
                                               self.sp.show_status_high_to_low)
            values_string += (f"status {self.zDot(binary_status)} | ")
        if not array_equal(self.rom_enabled, self.ac_last_rom_enabled):              # ROE
            binary_roe = self.ac_ROEStringBinary(self.sp.show_roe_high_to_low)
            values_string += f"ROE {self.zDot(binary_roe)} | "
                 # construct string of internal regs which have changed due to instruction
        internal_reg_string = ""
        if not array_equal(self.internal, self.ac_last_internal): # quick check for change
            int_dict = self.ac_InternalRegsDict()            # dictionary of internal regs
            for number, int_pair in enumerate(int_dict.items()):
                if not array_equal(self.internal[number],
                                   self.ac_last_internal[number]):
                    internal_reg_string += (f"{int_pair[0]} "
                                            f"{self.zDot(int_pair[1])}  ")
            if internal_reg_string != "":
                 internal_reg_string = internal_reg_string[:-2] + " | "       # end with |
                  # construct string of storage regs which have changed due to instruction
        storage_reg_string = ""
        if not array_equal(self.storage, self.ac_last_storage):   # quick check for change
                    # quick check will have array_equal true if no storage regs (as all 0)
            sto_dict = self.ac_StorageRegsDict()              # dictionary of storage regs
            for number, sto_pair in enumerate(sto_dict.items()):
                if not array_equal(self.storage[number],
                                   self.ac_last_storage[number]):
                    storage_reg_string += (f"{sto_pair[0]} "
                                           f"{self.zDot(sto_pair[1])}  ")
            if storage_reg_string != "":
                storage_reg_string = storage_reg_string[:-2] + " | "          # end with |
                                         # create state string (remove any trailing " | ")
        state_string = \
               f" {values_string}{internal_reg_string}{storage_reg_string}"[:-3]
                      # add a > to the start of the line if it's part of the key-wait loop
        if self.kl.cycle_count > 1:
            start_character = ">"
        else:
            start_character = " "
                                                     # construct the final new line string
        list_string = (f"{start_character}"
                       f"{f'{self.list_pane.ins_number:0>4}':>5}"
                       f" {rom_string} {state_string}")
             # create an array of strings with new line string and any additional messages
        list_strings = [list_string]
        if self.sf.list_mode == 1:                      # add messages only if in INS mode
            if self.ac_next_rom != self.ac_current_rom:          # enabled ROM has changed
                list_strings.append("")
                binary_roe = self.ac_ROEStringBinary(self.sp.show_roe_high_to_low)
                list_strings.append((f"      ENABLING ROM "
                                     f"{self.ac_next_rom} WITH ROE"
                                     f" {self.zDot(binary_roe)}"))
                list_strings.append("")
            elif self.ac_ShortInstructionString() == "keyGoTo":      # keyboard entry jump
                list_strings.append("")
                list_strings.append((f"      USING KEYCODE "
                                     f"{self.toBase(self.keycode, self.sf.base)}"
                                      " AS BRANCH VECTOR"))
                list_strings.append("")
                                   # calculate the current list line number (for ROM mode)
        line = (self.ac_current_rom * self.ac_rom_byte_count) \
                            + self.current_address + self.sf.list_start_lines
                                                                    # update the list pane
        self.list_pane.finishNewLine(self.sf.list_mode, self.sf.update_mode,
                                     list_strings, line,
                                     self.ac_total_byte_count)
                                                        # increment the instruction number
        self.list_pane.ins_number += 1

    def showHelpWindow(self, page):
        """ show the help window by creating it or bringing it to the front """
                                           # create the window if it doesn't already exist
        if not self.sf.help_window_active:
            self.sf.help_window_active = True
            self.help_window = HelpWindow(self.sp.help_file,
                                    self.sp.format["help"], page,
                                    self.sp.themes[self.sf.theme_current_name])
                                    # bind help window title-bar close icon to hide method
            self.help_window.help_window.protocol('WM_DELETE_WINDOW',
                                                  lambda:self.hideHelpWindow())
                                 # and bind exit help button in help window to hide method
            self.help_window.exit_button.config(
                                        command = lambda:self.hideHelpWindow())
        else:                           # bring help window to the front if already exists
            self.help_window.help_window.focus_force()
            self.help_window.help_window.lift()
            content = self.sp.help_file[page]
                        # need to update in case brought to front from page chosen in menu
            self.help_window.updateText(content,
                                self.sp.format["help"]["height"],
                                self.sp.format["help"]["height_with_button"])

    def hideHelpWindow(self):
        """ destroy the help window on exit and delete the instantiated help
        window class """
        self.sf.help_window_active = False
        self.flags_pane.updateFlags(self.sp.themes[self.sf.theme_current_name],
                                    self.sf.flagTuple(),
                                    self.ac_storage_support,
                                    self.ac_m_register_sci)
        self.help_window.help_window.destroy()
        del self.help_window

    # ----------------------------------------- methods for keyboard binding and unbinding

    def bindCalcKeysToKbd(self):
        """ match simulator key "bind to" to calculator key to keycode """
        calc_bindings = self.sp.bindings[self.ac_name]
        for key, key_dict in calc_bindings.items():
            binding_number = self.keycodes[key_dict["bind_to"]]
            root.bind_all(key, lambda event, \
                        keycode = binding_number: self.getAKey(keycode))

    def unbindCalcKeysFromKbd(self):
        """ unbind simulator keyboard keys: calculator operations """
        calc_bindings = self.sp.bindings[self.ac_name]
        for key in calc_bindings:
            root.unbind_all(key)

    def bindSimKeysToKbd(self):
        """ match simulator key "bind to" to higher keycodes which affect
        simulator flags rather than calculator operations """
        sim_bindings = self.sp.bindings["sim"]
        for key, binding_number in sim_bindings.items():
            root.bind_all(key, lambda event, \
                        keycode = binding_number: self.processKey(keycode))
        
    def unbindSimKeysFromKbd(self):
        """ unbind simulator keyboard keys: simulator flags """
        sim_bindings = self.sp.bindings["sim"]
        for key in sim_bindings:
            root.unbind_all(key)

    def bindCalcKeysToOSKbd(self):
        """ match on-screen keyboard button "bind to" to calculator key to
        keycode """
        for button, binding_number in zip(self.gui_keyboard.buttons,
                                          self.gui_keyboard.binding_numbers):
            button.config(
                   command=lambda keycode=binding_number:self.getAKey(keycode))

    def unbindCalcKeysFromOSKbd(self):
        """ unbind simulator on-screen keyboard buttons """
        for button in self.gui_keyboard.buttons:
            button.config(command="")

    def bindSteppingButtons(self):
        """ bind stepping buttons to steps """
        for button, button_step in self.list_pane.buttons:
            button.bind("<Button-1>", lambda event,
                            step = button_step: self.processSteppingKey(step))

    # --------------------------------------------------------- methods for creating menus

    def createMenus(self):
        """ create menu entries for help file pages """
        self.menubar = tk.Menu(root)
                                        # replace "About" in system menu with link to help
        app_menu = tk.Menu(self.menubar, name='apple', tearoff=0)
        app_menu.add_command(label="About",
                             command=lambda \
                             page="About":self.showHelpWindow(page))
        if platformName() == "Windows" or platformName() == "Linux":
            app_menu.add_command(label="Quit",
                                 command=root.destroy)
        self.menubar.add_cascade(label="System",menu=app_menu)
                                            # create "Help" menu from entries in help file
        help_menu = tk.Menu(self.menubar, tearoff=0)
        for help_page in self.sp.help_file:
            menu_item = help_page.replace('\n',' ')
            help_menu.add_command(label=menu_item,
                                  command=lambda \
                                  page=help_page:self.showHelpWindow(page))
        self.menubar.add_cascade(label="Help", menu=help_menu)
        root.config(menu=self.menubar)
                                # when we call to create we do not have enough information
                                # to activate help windows, so disable entries for now
        self.menubar.entryconfig("System",state=tk.DISABLED)
        self.menubar.entryconfig("Help",state=tk.DISABLED)

    # ------------------------------------------------------ methods for manipulating data

    def populateDefinitions(self,definitions_file):
        """ read the calculator definitions file into a dictionary and
        manipulate that dictionary so that each calculator-ROM has an
        information dict which includes the ROM details and hash checks
        required for the calculator-ROM select window and the ROM details
        pane """
                                                                   # read definitions file
        try:
            with open(ospath.join(ospath.dirname(sysargv[0]),definitions_file),
                      'r', newline='', encoding="utf-8") as cf:       
                definitions = jload(cf)
        except FileNotFoundError:
            error_text = tk.Text(root, font=("",16), width=40, wrap='word',
                                 padx=20, pady=20)
            error_text.pack()
            error_text.insert(tk.END, 
                    ("There is no valid calculator definitions file available."
                     "\n\nThe file hp1973_calcs.json should be in the same "
                     "folder as the HP1973 executable.\n\nYou can close this "
                     "window using the usual button in the window's title "
                     "bar."))
            error_text.config(state=tk.DISABLED)
            root.update_idletasks()
            root.mainloop()
            raise SystemExit(("Sorry, but the calculator definitions file,\n"
                              f"{definitions_file}, cannot be found. It\n"
                              "should be in the same directory as the HP-1973\n"
                              "executable."))
                                                          # loop through calculators, ROMs
        for calc in definitions:
            long_name = definitions[calc]["info"]["long_name"]
            for rom_v in definitions[calc]["rom_versions"]:
                roms_dict = definitions[calc]["rom_versions"][rom_v]["roms"]
                rom_hash_dict = definitions[calc]["rom_versions"][rom_v]["rom_hashes"]
                info_list = definitions[calc]["rom_versions"][rom_v]["info"][:20]
                known_bugs = definitions[calc]["rom_versions"][rom_v]["known_bugs"]
                info_dict = {}
                info_dict["calculator"] = calc
                info_dict["long_name"] = long_name
                info_dict["rom_version"] = rom_v
                info_dict["information"] = info_list
                info_dict["hash_checks"] = []
                # perform hash checks on ROM contents
                for rom, bytes in roms_dict.items():
                    if rom_hash_dict[rom] == 0:
                        hash_string = "N/A"
                    elif rom_hash_dict[rom] == hash(tuple(bytes)):
                        hash_string = "OK"
                    else:
                        hash_string = "ERROR"
                    info_dict["hash_checks"].append((f"ROM {rom:<1} :"
                                                f" {len(bytes):<3} values :"
                                                f" hash {hash_string:<5}    "))
                info_dict["known_bugs"] = known_bugs
                                                   # add formatted information to each ROM
                definitions[calc]["rom_versions"][rom_v]["info_dict"] = info_dict
                               # delete unnecessary duplicate information from definitions
                del definitions[calc]["rom_versions"][rom_v]["rom_hashes"]
                del definitions[calc]["rom_versions"][rom_v]["known_bugs"]
                del definitions[calc]["rom_versions"][rom_v]["info"]

        return definitions

    def populateKeycodeDecodeDict(self):
        """ creates a dictionary to decode simulator key presses into 
        calculator key presses : required because simulator and calculator
        code is kept as separate as possible """
        calc_bindings = self.sp.bindings[self.ac_name]
        self.keycode_decode_dict = {}
        for _, key_dict in calc_bindings.items():
            this_keycode = self.keycodes[key_dict["bind_to"]]
                                   # form calculator key text of form "(label|upper_text)"
                                   # or "(label)" or "(upper text)"
            this_calc_key = f"({key_dict['label']}"
            if key_dict["label"] != "" and key_dict["upper_text"] != "":
                this_calc_key += " | "
            this_calc_key += f"{key_dict['upper_text']})"
                                                 # form simulator key text of form "[key]"
            this_sim_key = f"[{key_dict['readable_key']}]"
                   # save to dictionary as "keycode:(calculator string, simulator string)"
            self.keycode_decode_dict[this_keycode] = (this_calc_key, this_sim_key)

    def populateHelpInformationPage(self):
        information_string = (f"{self.ac_information_dict['calculator']}"
                             " calculator with "
                            f"{self.ac_information_dict['rom_version'].upper()}"
                             " ROM\n")
        information_string += '-'*(len(information_string)-1)
        information_string += "\n\n\n\n"
        if self.ac_known_bugs:
            information_string += ("            "
                                   "****** WARNING: THIS ROM IS KNOWN TO"
                                   " CONTAIN BUGS ******\n\n\n\n")
        for line in self.ac_information_dict['information']:
            if line == "":
                information_string += "\n\n"
            else:
                information_string += f"{line} "
        information_string += "\n\n\n"
        for number, hash_check in \
                            enumerate(self.ac_information_dict['hash_checks']):
            if not(number % 2):
                information_string += "\n            "
            information_string += hash_check
                              # update help (overwrites title with calculator-ROM details)
        self.sp.help_file["Calculator-ROM\nInformation"]["main"] = \
                                                            information_string

    def toBase(self, value, base, binary=False):
        """ convert value to base or to binary if binary = True"""
        if binary:
            base_value = bin(value)[2:]
        else:
            if base == 0:
                base_value = value 
            elif base == 1:
                base_value = hex(value)[2:]
            else:
                base_value = oct(value)[2:]
        return base_value
    
    def zDot(self, string):
        """ replace 0s in string with dots, or leave alone, depending on 
        zero_swap flag """
        return string.replace('0',self.sf.zero_swap)

    # --------------------------------- method to toggle calculator power off and on again

    def togglePower(self):
        """ toggle the power on the calculator to restart it wthin the
        simulator """
        self.sf.power_on = not self.sf.power_on
        self.kl.loops_running = 0                 # ensures background key-wait loop stops
        sleep(1)
        self.powerSwitch(0)
        self.flags_pane.updateFlags(self.sp.themes[self.sf.theme_current_name],
                                    self.sf.flagTuple(),
                                    self.ac_storage_support,
                                    self.ac_m_register_sci)
        self.map_pane.clear()
        self.internals_UpdateRegisters()
        self.list_pane.clear()
        root.update_idletasks()
        sleep(1)
        self.kl.loops_running = 0
        self.sf.power_on = not self.sf.power_on
        self.powerSwitch(1)
        self.ac_current_rom = self.ac_CurrentROMValue()
        self.ac_next_rom = self.ac_CurrentROMValue()
        self.ac_CopyCurrenttoLast()
        self.display_Update()
        self.display_pane.updateCalcInfo(self.internal[r_m], self.status,
                                               self.ac_calc_info_flags,
                                               self.sf.display_mode)
        self.flags_pane.updateFlags(self.sp.themes[self.sf.theme_current_name],
                                    self.sf.flagTuple(),
                                    self.ac_storage_support,
                                    self.ac_m_register_sci)
        self.sf.just_turned_on = True
        self.processKey(99)

if __name__ == "__main__":
    """ let's do this thing! """
    root = tk.Tk()
    root.resizable(False,False)
    root.config(bg="#000", padx=15, pady=15)
    root.rowconfigure(4, weight=10)
    match platformName():
        case "Darwin" : simulator = Simulator("hp1973_prefs_macos.json")
        case "Linux"  : simulator = Simulator("hp1973_prefs_linux.json")
        case "Windows": simulator = Simulator("hp1973_prefs_windows.json")
    root.mainloop()              # Wait for a keypress and then run the method bound to
                                 # that key. Also run the key-wait loop in the background.

""" Below is a minimal interface for the calculator, if you want a starting
point to create your own.  Comment out the __main__ which is immediately
above this comment, and uncomment the following few lines. Make sure that the
indentation is correct and remember to change the name of the preference file
for your operating system. """

# def minimalProcess(keycode):                                       # runs when key pressed
#     calc.keycode = keycode                  # sets calculator keycode based on key pressed
#     while not calc.display_and_input:                       # until operation completed...
#         calc.processByte()                       # ...process instructions from ROMs/bytes
#     calc.display_and_input = False                    # prep calculator for next key press
#     calc.setStatus([0])
#     calc.carry = 1
#     display.set(calc.approxDisplay())             # update tkinter display from calculator
#                                                      # control returns to tkinter mainloop
# if __name__ == "__main__":
#     root = tk.Tk()                                            # set up tkinter root window
#     display = tk.StringVar()                              # tkinter string to hold display
#                                            # define tkinter label holding display string
#                                            # (change font to "Consolas" for Windows, etc.)
#     label = tk.Label(textvariable=display, font=("Menlo",50),
#                      bg="#000", fg="#f00", width=20)
#     label.pack()                                                     # add label to window
#     calc = Calculator("HP-45", "standard", "hp1973_calcs.json") # instantiate a calculator
#                          # get keyboard keys from file (change filename for Windows, etc.)
#     with open("hp1973_prefs_mac.json") as kbf:
#         pref_data = jload(kbf)
#         for key, details in pref_data["bindings"]["HP-45"].items():
#                                               # match sim key to calc operation to keycode
#             binding_number = calc.keycodes[details["bind_to"]]
#             root.bind_all(key, lambda event, \
#                     keycode = binding_number: minimalProcess(keycode))
#     minimalProcess(62)                     # send ENTER keypress so process loop runs once
#     root.mainloop()                        # wait for key press then call minimalProcess()
