// 2022 Sarah K. Libman - sarahkmarr.com

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define ESC 27
#define SPACE 32
#define COLUMNS 80
#define ROWS 24


// FLOWERS!
// Type 0
// 0 ...  1 ...  2 ...  3 ...  4 ...  5 .@.  6 .*.  7 ...  8 ...  9 ...
//   ...    ...    ...    .V.    \|.    \|.    \|.    \..    ...    ...
//   ...    .|.    .V.    .|/    .|/    .|/    .|/    .|/    .|.    .\.
// Type 1
// 0 ...  1 ...  2 ...  3 ...  4 ...  5 ../  6 ../  7 ...  8 ...  9 ...
//   ...    ...    ...    .\.    .\\    .\\    ..\    ..\    ..\    ...
//   ...    ./.    \//    \//    \//    \//    \//    \//    .//    ../
// Type 2
// 0 ...  1 ...  2 ...  3 ...  4 #..  5 #.#  6 ..#  7 ..#  8 #..  9 ...
//   ...    .#.    .#.    |#.    |#|    |.|    ..|    ..|    .\.    ...
//   ...    .|.    ||.    |||    |||    |.|    |.|    |.|    ..|    ..|
// Type 3
// 0 ...  1 ...  2 .+.  3 .O.  4 .O.  5 ..+  6 ..O  7 ..O  8 ...  9 ...
//   ...    ...    .|.    .|.    .|(    +.(    O.(    O.(    O..    ...
//   ...    \|/    \|/    \|/    \|/    \|/    \ /    \./    \./    \..
// Type 4
// 0 ...  1 ...  2 ...  3 .).  4 ...  5 ...  6 ..)  7 ..)  8 ...  9 ...
//   ...    ...    (..    (..    (..    .(.    .(.    .(.    .(.    ...
//   ...    .).    .).    .).    .))    ..)    ..)    ..)    ..)    ..)
// Type 5
// 0 ...  1 ...  2 ...  3 ._.  4 ._.  5 ._.  6 ._.  7 ._.  8 ...  9 ...
//   ...    ...    |..    |..    |.'    |.A    |.A    |.;    |\.    ...
//   ...    |..    |..    |..    |..    |..    |..    |..    |..    /..

// coordinate of flower is centre of 3x3 square
// square is    T[op]L[eft]     TC[entre]   TR[ight]
//              CL              CC          CR
//              BL              BC          BR     

char _tL[6][10] = {
                {SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE},
                {SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE},
                {SPACE, SPACE, SPACE, SPACE,  '#',   '#',  SPACE, SPACE,  '#',  SPACE},
                {SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE},
                {SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE},
                {SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE} };
char _tC[6][10] = {
                {SPACE, SPACE, SPACE, SPACE, SPACE,  '@',   '*',  SPACE, SPACE, SPACE},
                {SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE},
                {SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE},
                {SPACE, SPACE,  '+',   'O',   'O',  SPACE, SPACE, SPACE, SPACE, SPACE},
                {SPACE, SPACE, SPACE,  ')',  SPACE, SPACE, SPACE, SPACE, SPACE, SPACE},
                {SPACE, SPACE, SPACE,  '_',   '_',   '_',   '_',   '_',  SPACE, SPACE} };
char _tR[6][10] = {
                {SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE},
                {SPACE, SPACE, SPACE, SPACE, SPACE,  '/',   '/',  SPACE, SPACE, SPACE},
                {SPACE, SPACE, SPACE, SPACE, SPACE,  '#',   '#',   '#',  SPACE, SPACE},
                {SPACE, SPACE, SPACE, SPACE, SPACE,  '+',   'O',   'O',  SPACE, SPACE},
                {SPACE, SPACE, SPACE, SPACE, SPACE, SPACE,  ')',   ')',  SPACE, SPACE},
                {SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE} };
char _cL[6][10] = {
                {SPACE, SPACE, SPACE, SPACE, '\\',  '\\',  '\\',  '\\',  SPACE, SPACE},
                {SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE},
                {SPACE, SPACE, SPACE,  '|',   '|',   '|',  SPACE, SPACE, SPACE, SPACE},
                {SPACE, SPACE, SPACE, SPACE, SPACE,  '+',   'O',   'O',   'O',  SPACE},
                {SPACE, SPACE,  '(',   '(',  SPACE, SPACE, SPACE, SPACE, SPACE, SPACE},
                {SPACE, SPACE,  '|',   '|',   '|',   '|',   '|',   '|',   '|',  SPACE} };
char _cC[6][10] = {
                {SPACE, SPACE, SPACE,  'V',   '|',   '|',   '|',  SPACE, SPACE, SPACE},
                {SPACE, SPACE, SPACE, '\\',  '\\',  '\\',  SPACE, SPACE, SPACE, SPACE},
                {SPACE,  '#',   '#',   '#',   '#',  SPACE, SPACE, SPACE, '\\',  SPACE},
                {SPACE, SPACE,  '|' ,  '|' ,  '|' , SPACE, SPACE, SPACE, SPACE, SPACE},
                {SPACE, SPACE, SPACE, SPACE,  '(',   '(',    '(',  '(',   '(',  SPACE},
                {SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, '\\',  SPACE} };
char _cR[6][10] = {
                {SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE},
                {SPACE, SPACE, SPACE, SPACE, '\\',  '\\',  '\\',  '\\',  '\\',  SPACE},
                {SPACE, SPACE, SPACE, SPACE,  '|',   '|',   '|',   '|',  SPACE, SPACE},
                {SPACE, SPACE, SPACE, SPACE,  '(',   '(',   '(',   '(',  SPACE, SPACE},
                {SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE},
                {SPACE, SPACE, SPACE, SPACE, '\'',   'A',   'A',   ';',  SPACE, SPACE} };
char _bL[6][10] = {
                {SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE},
                {SPACE, SPACE, '\\',  '\\',  '\\',  '\\',  '\\',  '\\',  SPACE, SPACE},
                {SPACE, SPACE,  '|' ,  '|',   '|',   '|',   '|',   '|',  SPACE, SPACE},
                {SPACE, '\\',  '\\',  '\\',  '\\',  '\\',  '\\',  '\\',  '\\',  '\\' },
                {SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE},
                {SPACE,  '|',   '|',   '|',   '|',   '|',   '|',   '|',   '|',   '/'} };
char _bC[6][10] = {
                {SPACE,  '|',   'V',   '|',   '|',   '|',   '|',   '|',   '|',  '\\' },
                {SPACE,  '/',   '/',   '/',   '/',   '/',   '/',   '/',   '/',  SPACE},
                {SPACE,  '|',   '|',   '|',   '|',  SPACE, SPACE, SPACE, SPACE, SPACE},
                {SPACE,  '|',   '|',   '|',   '|',   '|',  SPACE, SPACE, SPACE, SPACE},
                {SPACE,  ')',   ')',   ')',   ')',  SPACE, SPACE, SPACE, SPACE, SPACE},
                {SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE} };
char _bR[6][10] = {
                {SPACE, SPACE, SPACE,  '/',   '/',   '/',   '/',   '/',  SPACE, SPACE},
                {SPACE, SPACE,  '/',   '/',   '/',   '/',   '/',   '/',   '/',   '/' },
                {SPACE, SPACE, SPACE,  '|',   '|',   '|',   '|',   '|',   '|',   '|' },
                {SPACE,  '/',   '/',   '/',   '/',   '/',   '/',   '/',   '/',  SPACE},
                {SPACE, SPACE, SPACE,  ')',   ')',   ')',   ')',   ')',   ')',   ')' },
                {SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE, SPACE} };

//
// Flowers on the screen
int _Screen[ROWS+1][COLUMNS+1];                         // lazy hack so we can us 1...ROWS, 1..COLUMNS

void clearScreen()                                      // clear the screen
{
    printf("%c[2J", ESC);
    return;
}


void printFlower(int row, int col)   // print flower centred at row, column
{                                   // and update flower type at that address
    int flowerSpecies, flowerType, nextFlowerType;
    
    if (_Screen[row][col] == 0)     // if no flower then pick a species at random
    {
        flowerSpecies = rand() % 6;
    }
    else                            // otherwise get species from location
    {
        flowerSpecies = _Screen[row][col] / 10;
    }

    flowerType = _Screen[row][col] % 10;    // get current flower type of species
    nextFlowerType = (flowerType + 1) % 10;        // and set next flower type & to zero if at 9

    printf("%c[%d;%dH%c", ESC, row-1, col-1, _tL[flowerSpecies][nextFlowerType]);
    printf("%c", _tC[flowerSpecies][nextFlowerType]);
    printf("%c", _tR[flowerSpecies][nextFlowerType]);
    printf("%c[%d;%dH%c", ESC, row, col-1, _cL[flowerSpecies][nextFlowerType]);
    printf("%c", _cC[flowerSpecies][nextFlowerType]);
    printf("%c", _cR[flowerSpecies][nextFlowerType]);
    printf("%c[%d;%dH%c", ESC, row+1, col-1, _bL[flowerSpecies][nextFlowerType]);
    printf("%c", _bC[flowerSpecies][nextFlowerType]);
    printf("%c", _bR[flowerSpecies][nextFlowerType]);

    if (nextFlowerType == 0)                 // reset type and species if zero
    {
        _Screen[row][col] = 0;
    }
    else                                   // otherwise just update type
    {
        _Screen[row][col] = (flowerSpecies * 10) + nextFlowerType;
    }
    
    return;
}

int min(int a, int b)
{
    if (a < b)
    {
        return a;
    }
    else
    {
        return b;
    }
}

int max(int a, int b)
{
    if (a > b)
    {
        return a;
    }
    else
    {
        return b;
    }
}

// int main()              // prints flowers out to check them
// {
//     for (int i = 0; i <= 5; i++)
//     {
//         printf("\nType %d\n", i);
//         for (int j = 0; j <= 9; j++)
//         {
//             printf("%c", _tL[i][j]);
//             printf("%c", _tC[i][j]);
//             printf("%c   ", _tR[i][j]);
//         }
//         printf("\n");
//         for (int j = 0; j <= 9; j++)
//         {
//             printf("%c", _cL[i][j]);
//             printf("%c", _cC[i][j]);
//             printf("%c   ", _cR[i][j]);
//         }
//         printf("\n");
//         for (int j = 0; j <= 9; j++)
//         {
//             printf("%c", _bL[i][j]);
//             printf("%c", _bC[i][j]);
//             printf("%c   ", _bR[i][j]);
//         }
//         printf("\n");
//     }
//     return 0;
// }

bool clearFlag(int row, int col)
{
for (int i = max(1,row-4); i <= min(ROWS,row+4); i++)       //only print a flower if there isn't another flower in its way.
    {                                                                       
        for (int j = max(1,col-4); j <= min(COLUMNS,col+4); j++)
        {
            if (_Screen[i][j] != 0)
            {
                if (i != row || j != col) return false;    // let flowers overwrite themselves though
            }
        }
    }                                               
    return true;
}

int main()
{
    int flowerRow, flowerCol;
    int keyStatus = 0;
    clearScreen();
    while (true)
    {
        flowerRow = 2 + rand() % (ROWS-2);                  // center of flower (row) (whole flower fits screen)
        flowerCol = 2 + rand() % (COLUMNS-2);               // center of flower (column) (whole flower fits screen)

        

    if (clearFlag(flowerRow,flowerCol)) 
    {
        printFlower(flowerRow, flowerCol);
        printf("%c[%d;%dH", ESC, ROWS, COLUMNS);
    for (int i = 0; i <= 4000; i++)                 // take it easy
    {
    outp(1,128);                                        // opcode to read User Key
    keyStatus = inp(0);
    if (keyStatus != 0) return 0;                       // and break to CP/M is pressed
    }
    }
    }
    return 0;
}