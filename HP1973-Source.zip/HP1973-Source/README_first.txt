Hi, and thanks for downloading the Python source code for HP-1973. Please read the following to ensure the simulator works for you.

PYTHON VERSION

The code should run under a Python 3.10.10+ installation which includes numpy and tkinter. 

EXTERNAL FILES

The following files need to be in the same directory as HP1973.py:
 - hp1973_calcs.json
 - hp1973_help.json
 - hp1973_prefs.json
 
WINDOWS SPECIFIC

On some machines, Windows defaults to showing the screen at 125% magnification, which makes the simulator too large for a 1920x1080 screen. You can fix this by going into display settings and, under 'Scale and layout', changing this to 100%.

LINUX/FREEBSD SPECIFIC

The Linux/FreeBSD preference file uses DejaVu Sans Mono as its base font. Even if that font is installed, tkinter's font smoothing seems, er, non-existent so the display looks pretty terrible. However, YMMV: this might be a function of my particular Linux flavour, or Python installation, or...

ALL

I found that (on some Macs) the usual list height (which works on my 1920x1080 screen) caused the application window to display incorrectly on some other screens. If this happens, the "short_list" preference item in hp1973_prefs.json can be set to true.

Sarah Libman