// 2022 Sarah K. Libman - sarahkmarr.com

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <conio.h>

#define A_ESC 27

int rtc[7];                             // holds the last read rtc time
int old_rtc[7];                         // holds the rtc time prior to waiting for the next second

int alert_wait_minutes = 0;             // the wait between alerts, in minutes
int alert_wait[3];                      // hours [2] and minutes [1] and seconds [0] (always 0) between alerts
int next_alert[3];                      // next alert time, same format as alert_wait
int last_alert[3];                      // last alert time, same format as alert_wait
bool alert_set = false;                 // have alerts been set
bool alert_on = false;                  // are we currently alerting the user
int alert_length = 30;                  // how long does the alert last (seconds) KEEP BELOW 45 (NO MINUTES LOGIC)
bool user_led_on = false;               // is the user_led_lit
bool first_alert = true;                // set false after first alarm to change display

int date_format = 0;                    // 1 (dd/mm/yy) 2 (mm/dd/yy) 3 (yy/mm/dd)

int disp_start_row = 3;                 // could pass these to function but tedious; could define in function but meh.
int disp_start_col = 2;
int disp_char_width = 7;
int disp_char_spacing = 3;
int disp_char_height = 7;
int disp_row_spacing = 3;

// ------ DECLARE FUNCTIONS OUTSIDE DEFINITIONS SO ORDERING CAN BE MORE FLEXIBLE BELOW ---------------------------------
// core
void write_opcode(int opcode); void set_user_led(bool led_state); bool user_key_pressed();
// clock and time
void get_rtc_data(); bool rtc_tick(bool check_user_key);
int diff_time(int component, int hour_hi, int min_hi, int sec_hi, int hour_lo, int min_lo, int sec_lo);
int add_time(int component, int hour_1, int min_1, int sec_1, int hour_2, int min_2, int sec_2);
// alert
void trigger_alert(); void flash_alert_led(); bool get_alert_wait(bool easter);
void set_next_alert(); void update_initial_screen_alert(); void update_screen_alert();
// temperature
void update_screen_temp();
// screen
void print_big_char(int character, int row, int digit, int format); void clear_screen(); void prepare_screen();
void update_screen(); void intro_date_alert(); void display_date(); void display_initial_time();


// ------ Z80-MBC2 CLOCK -----------------------------------------------------------------------------------------------
int main()
{

    intro_date_alert();

    prepare_screen();
    
    while(true){
        if(rtc_tick(true)){                                                          // get the next set of rtc data
            clear_screen();                                                             // but clear screen ...
            printf("%c[m", A_ESC);                                                      // ... return to normal text ... (to be safe)
            return 0;                                                                   // ... and end execution if User Key pressed
        }
        update_screen();
        if(alert_set){
            trigger_alert();  
        }
        if(alert_on){
            flash_alert_led();
        }
 
    }

    return 0;
}


// ------ CORE FUNCTIONS -----------------------------------------------------------------------------------------------

void write_opcode(int opcode)                               // write an opcode
{
    outp(1,opcode);
    return;
}

void set_user_led(bool led_state)                           // turn the user LED on and off
{
    write_opcode(0);                                        // opcode to set User LED     
    if (led_state){
        outp(0,1);
        user_led_on = true;
    }
    else {
        outp(0,0);
        user_led_on = false;
    }
    return;
}

bool user_key_pressed()                                     // check for User Key press
{
    write_opcode(128);                                      // opcode to read User Key
    int key_status = inp(0);
    return (key_status && 1);
}

// ------ CLOCK AND TIME FUNCTIONS -------------------------------------------------------------------------------------

void get_rtc_data()                                         // retrieve a set of RTC data
{

    write_opcode(132);              // opcode to read RTC

    rtc[0] = inp(0);                // seconds
    rtc[1] = inp(0);                // minutes
    rtc[2] = inp(0);                // hours
    rtc[3] = inp(0);                // day
    rtc[4] = inp(0);                // month
    rtc[5] = inp(0);                // year
    rtc[6] = inp(0);                // temperature

    return;
}

bool rtc_tick(bool check_user_key)                          // poll the RTC until next second (and optionally check User Key)
{
    old_rtc[0] = rtc[0]; old_rtc[1] = rtc[1]; old_rtc[2] = rtc[2]; old_rtc[3] = rtc[3];        // making assumption quicker for loop
    old_rtc[4] = rtc[4];old_rtc[5] = rtc[5]; old_rtc[6] = rtc[6];
    int current_second = rtc[0];
    get_rtc_data();
    while(rtc[0] == current_second){
        get_rtc_data();
        if(check_user_key && user_key_pressed()){
            return true;
        }
    }
    return false;
}

                                                            // time difference (0 = sec, 1 = min, 2 = hour)
int diff_time(int component, int hour_hi, int min_hi, int sec_hi, int hour_lo, int min_lo, int sec_lo)
{
    int dh = 0; int dm = 0; int ds=0;
 
    if(sec_lo <= sec_hi){
        ds = sec_hi - sec_lo;
    }
    else{
        ds = sec_hi + 60 - sec_lo;
        min_lo++;
    }
    if(component > 0){ 
        if(min_lo <= min_hi){
            dm = min_hi - min_lo;
        }
        else{
            dm = min_hi + 60 - min_lo;
            hour_lo++;
        }
        if(component > 1){
            if(hour_hi < hour_lo){                      // cope with crossing midnight
                hour_hi = hour_hi + 24;
            }
            dh = hour_hi - hour_lo;                     // assumes hi time is later than lo time
            return dh;
        }
        return dm;
    }
    return ds;
}

                                                            // time addition (0 = sec, 1 = min, 2 = hour)
int add_time(int component, int hour_1, int min_1, int sec_1, int hour_2, int min_2, int sec_2)
{
    int ah = 0; int am = 0; int as = 0;

    as = sec_1 + sec_2;
    if(as > 59){
        as = as - 60;
        min_1++;
    }
    if(component > 0){
        am = min_1 + min_2;
        if(am > 59){
            am = am - 60;
            hour_1++;
        }
        if(component > 1){
            ah = hour_1 + hour_2;
            if (ah > 23){
                ah = ah - 24;
            }
            return ah;
        }
        return am;
    }
    return as;
}

// ------ ALERT FUNCTIONS ---------------------------------------------------------------------------------------------

bool get_alert_wait(bool easter)                            // get user input for alert details
{
    alert_wait[0] = 0;
    next_alert[0] = 0; //always
    last_alert[0] = 0; //always

    int i;
    char null;
    int first_alert = 0;

    clear_screen();
    printf("%c[7m", A_ESC);                                 // inverse text
    printf("*******************************  Z80-MBC2 CLOCK  *******************************");
    printf("%c[m", A_ESC);                                  // back to normal text
    printf("\n\n");

    printf("Please enter the frequency of alerts, in whole minutes.\n");
    if(easter){
        while((alert_wait_minutes < 5) || (alert_wait_minutes > 300 && alert_wait_minutes != 1983)){
            printf("Minimum 5 minutes. Maximum 300 minutes (5 hours). %c7%c[24;62H1983 to list games%c8", A_ESC, A_ESC, A_ESC);
                                                            // %c7 saves cursor pos %c8 restores
            scanf("%d", &alert_wait_minutes);
        }
    }
    else{
        while((alert_wait_minutes < 5) || (alert_wait_minutes > 300)){
            printf("Minimum 5 minutes. Maximum 300 minutes (5 hours). ");
            scanf("%d", &alert_wait_minutes);
        }
    }

    if(alert_wait_minutes == 1983){
        clear_screen();
        printf("List Games\n\n");
        for(i = 0; i < 5000; i++){            
        }
        printf("FALKEN'S MAZE\nBLACK JACK\nGIN RUMMY\nHEARTS\nBRIDGE\nCHECKERS\nCHESS\nPOKER\n");
        printf("FIGHTER COMBAT\nGUERRILLA ENGAGEMENT\nDESERT WARFARE\nTHEATERWIDE TACTICAL WARFARE\n");
        printf("THEATERWIDE BIOTOXIC AND CHEMICAL WARFARE\n\n");
        for(i = 0; i < 7000; i++){            
        }
        printf("GLOBAL THERMONUCLEAR WAR\n\n");
        printf(">");
        getch();
        printf("%c[1DACCESS DENIED", A_ESC);
        for(i = 0; i < 7000; i++){            
        }
        printf("%c[13D             ", A_ESC);
        for(i = 0; i < 7000; i++){            
        }
        printf("%c[13DACCESS DENIED", A_ESC);
        for(i = 0; i < 7000; i++){            
        }
        printf("%c[13D             ", A_ESC);
        for(i = 0; i < 7000; i++){           
        }
        printf("%c[13DACCESS DENIED", A_ESC);
        for(i = 0; i < 7000; i++){            
        }
        printf("%c[13DACCESS DENIED", A_ESC);
        for(i = 0; i < 7000; i++){            
        }
        return true;
    }

    printf("%c7%c[24;62H                  %c8", A_ESC, A_ESC, A_ESC);                   // remove the 1983 option if still there

    while(first_alert != 1 && first_alert != 2 && first_alert != 3 && first_alert != 4){
        printf("\n\nDo you want the first alert to occur %d minutes from now (enter 1)\n", alert_wait_minutes);
        printf("or on the next quarter hour (2), half hour (3) or hour (4)? ");
        scanf("%d", &first_alert);
    }
   
    alert_wait[2] = alert_wait_minutes/60;                       // save the interval in h,m and s
    alert_wait[1] = alert_wait_minutes%60;
    alert_wait[0] = 0;

    alert_set = true;                                       // set alert_set flag

    // set the first alert time
    get_rtc_data();
    last_alert[2] = rtc[2];                                 // need to set these because otherwise not set in cases  2, 3 and 4, below
    last_alert[1] = rtc[1];
    switch(first_alert){                                    // using 14, 29, etc. to give time to set
        case 1:
            next_alert[2] = rtc[2];
            next_alert[1] = rtc[1];
            set_next_alert();
            break;
        case 2:
            if(rtc[1] < 14){                                // 00 to 13 triggers hour+0 15 minutes
                next_alert[2] = rtc[2];
                next_alert[1] = 15; 
            }
            else if(rtc[1] < 29){                           // 14 to 28 triggers hour+0 30 minutes
                next_alert[2] = rtc[2];
                next_alert[1] = 30;
            }
            else if(rtc[1] < 44){                           // 29 to 43 triggers hour+0 45 minutes
                next_alert[2] = rtc[2];
                next_alert[1] = 45;
            }
            else if(rtc[1] < 59){                           // 44 to 58 triggers hour+1 00 minutes
                next_alert[2] = rtc[2] + 1;
                next_alert[1] = 0;
            }
            else{                                           // 59 triggers hour+1 15 minutes
                next_alert[2] = rtc[2] + 1;
                next_alert[1] = 15;
            }
            break;
        case 3:
            if(rtc[1] < 29){                                // 00 to 28 triggers hour+0 30 minutes
                next_alert[2] = rtc[2];
                next_alert[1] = 30;
            }
            else if(rtc[1] < 59){                           // 29 to 58 triggers hour+1 00 minutes
                next_alert[2] = rtc[2] + 1;
                next_alert[1] = 0;
            }
            else{                                           // 59 triggers hour+1 30 minutes
                next_alert[2] = rtc[2] + 1;
                next_alert[1] = 30;
            }
            break;
        case 4:
            if(rtc[1] < 59){                                // 00 to 58 triggers hour+1 00 minutes
                next_alert[2] = rtc[2] + 1;
                next_alert[1] = 0;
            }
            else{                                           // 59 triggers hour+2 00 minutes
                next_alert[2] = rtc[2] + 2;
                next_alert[1] = 0;
            }
            break;
    }

    if(next_alert[2] > 23){                                 // if hour is more than 23 then correct
        next_alert[2] = next_alert[2] - 24;
    }

    return;
}

void trigger_alert()                                        // check for alert, if true turn on, calculate next alert, update screen
{    
    if(next_alert[2] == rtc[2] && next_alert[1] == rtc[1]){                         // not checking seconds in case we miss the 0s point
        alert_on = true;
    
        set_next_alert();
        first_alert = false;

        // printf("%c[23;51Hnext alert at %c[1m%02d:%02d%c[m  ", A_ESC, A_ESC, next_alert[2], next_alert[1], A_ESC);      // update screen

        update_screen_alert(); // update screen
    }                                                                            

    return;
}

void flash_alert_led()                                      // flash alert LED for alert period then turn off and end alert
{
    if(rtc[0] <= alert_length){                                         // checking seconds against duration as always start on 0 seconds
        if(user_led_on){
            set_user_led(false);
        }
        else{
            set_user_led(true);
        }
    }
    else{
        set_user_led(false);                                         // to be sure
        alert_on = false;
    }

    return;
}


void set_next_alert()                                       // store time of current alert and set the time of the next alert
{
    last_alert[1] = next_alert[1];
    last_alert[2] = next_alert[2];

    next_alert[1] = add_time(1, last_alert[2], last_alert[1], last_alert[0], alert_wait[2], alert_wait[1], alert_wait[0]);
    next_alert[2] = add_time(2, last_alert[2], last_alert[1], last_alert[0], alert_wait[2], alert_wait[1], alert_wait[0]);
   
    return; 
}

void update_initial_screen_alert()                          // put the initial alert information on screen
{
    if(alert_set){
        printf("%c[22;43HALERTS every ", A_ESC);                               // intro
        if(alert_wait[2] > 0) {                                                     // text if there are hours
            printf("%d hour",alert_wait[2]);
            if (alert_wait[2] > 1) {
                printf("s");
            }
            if (alert_wait[1] > 0){
                printf(" & ");
            }
        }
        if(alert_wait[1] > 0){                                                      // text if there are minutes
            printf("%d minute", alert_wait[1]);
            if(alert_wait[1] > 1){
                printf("s");
            }
        }
        // printf("%c[23;51Halerts start at %c[1m%02d:%02d%c[m", A_ESC, A_ESC, next_alert[2], next_alert[1], A_ESC); */
        update_screen_alert();
    }
    else{
        printf("%c[22;43HALERTS are not active", A_ESC);                                // text if no alerts
    }
    return;
}

void update_screen_alert(){                                   // update the screen display for the alert
    // first character after first | is max_wait (alert_wait); first character before last | is min_wait (0); | at current wait
    // the 100 factor is used here to avoid use of float/double and ensure int rounds to correct (enough) value
    // but! don't set too high values or will overflow
    int i; int time_shift;
    int hrs_since_last = diff_time(2, rtc[2], rtc[1], rtc[0], last_alert[2], last_alert[1], last_alert[0]);
    int mins_since_last = diff_time(1, rtc[2], rtc[1], rtc[0], last_alert[2], last_alert[1], last_alert[0]);
    int hrs_to_next = diff_time(2, next_alert[2], next_alert[1], next_alert[0], rtc[2], rtc[1], rtc[0]);
    int mins_to_next = diff_time(1, next_alert[2], next_alert[1], next_alert[0], rtc[2], rtc[1], rtc[0]);
    if(hrs_to_next + mins_to_next == 0){        // don't update if we're at the time of the next alert as update is done after next alert set
        return;
    }
    int mins_passed = (hrs_since_last * 60) + mins_since_last;                             // total minutes since last alert
    if(first_alert){                                                                        // different display for first alert
        int bar_length = 14;
        int first_wait_minutes = (diff_time(2, next_alert[2], next_alert[1], next_alert[0], last_alert[2], last_alert[1], last_alert[0]) * 60) \
                                    + diff_time(1, next_alert[2], next_alert[1], next_alert[0], last_alert[2], last_alert[1], last_alert[0]);
        int bar_passed = ((mins_passed * 100) / first_wait_minutes) * bar_length / 100;           // can't use alert_wait_minutes for first wait period
        printf("%c[23;43Hstarting at|", A_ESC);                         // start of bar
        for(i = 0; i <= bar_length; i++){                                                       // bar and temp indicator
            if(i == bar_passed){
                printf("|");
            }
            else{
                printf("-");
            }
        }
        printf("|%c[1m%02d:%02d%c[m", A_ESC, next_alert[2], next_alert[1], A_ESC);                                  // end of bar
        printf("%c[24;43Hin                             ", A_ESC);                       // clear remaining line change if line length changes
        if(bar_passed <= bar_length / 3){                                                          // position of time relative to bar indicator changes 
            time_shift = 0;
        }
        else if(bar_passed <= 2 * bar_length / 3){
            time_shift = 2;
        }
        else{
            time_shift = 5;
        }
        printf("%c[24;%dH%02dh%02dm", A_ESC, 43+12+bar_passed-time_shift, hrs_to_next, mins_to_next);    
    }
    else{
        int bar_length = 20;                                                                                   // normal display
        int bar_passed = ((mins_passed * 100) / alert_wait_minutes) * bar_length / 100;           // where is mins_passed on the bar
        printf("%c[23;43H%02d:%02d|", A_ESC, last_alert[2], last_alert[1]);                         // start of bar
        for(i = 0; i <= bar_length; i++){                                                       // bar and temp indicator
            if(i == bar_passed){
                printf("|");
            }
            else{
                printf("-");
            }
        }
        printf("|%c[1m%02d:%02d%c[m", A_ESC, next_alert[2], next_alert[1], A_ESC);                                  // end of bar
        printf("%c[24;43Hlast                         next", A_ESC);                       // clear remaining line change if line length changes
        if(bar_passed <= bar_length / 3){                                                          // position of time relative to bar indicator changes 
            time_shift = 0;
        }
        else if(bar_passed <= 2 * bar_length / 3){
            time_shift = 2;
        }
        else{
            time_shift = 5;
        }
        printf("%c[24;%dH%02dh%02dm", A_ESC, 43+6+bar_passed-time_shift, hrs_to_next, mins_to_next);    
    }
    return;
}

// ------ TEMPERATURE FUNCTIONS ----------------------------------------------------------------------------------------

void update_screen_temp()                                   // update temperature display from last read RTC
{
    // first character after first | is min_temp; first character before last | is max_temp; < and > if outside bounds
    // else | at correct point along bar
    // the 100 factor is used here to avoid use of float/double and ensure int rounds to correct (enough) value
    // but! don't set too high values or will overflow
    int min_temp = 18; int max_temp = 28; int bar_length = 20; int bar_temp;            // min max temps for temp bar and length
    int temp = rtc[6]; int i;                                                           // temp we correct for max min limits
    char temp_char = '|';
    
    if(temp < min_temp){
        temp = min_temp;
        temp_char = '<';
    }
    else if(temp > max_temp){
        temp = max_temp;
        temp_char = '>';
    }

    bar_temp = (((temp - min_temp) * 100) / (max_temp - min_temp)) * bar_length / 100;    // position in bar
    
    printf("%c[23;5H%d˚|", A_ESC, min_temp);                                            // start of bar
    for(i = 0; i <= bar_length; i++){                                                   // bar and temp indicator
        if(i == bar_temp){
            printf("%c", temp_char);
        }
        else{
            printf("-");
        }
    }
    printf("|%d˚", max_temp);                                                           // end of bar
 
    printf("%c[24;%dH    %c[1m%d˚C%c[m    ", A_ESC, 5+4+bar_temp-5, A_ESC, rtc[6], A_ESC);    // spaces delete previous

    return;
}

// ------ SCREEN FUNCTIONS ---------------------------------------------------------------------------------------------

                                                            // print a big number (format = 0 normal, 1 bright, 2 inverse, 3 underline)
void print_big_char(int character, int row, int digit, int format)
{
    int digit_row = disp_start_row + (row * (disp_char_height + disp_row_spacing));     // 1st row is 0
    int digit_col = disp_start_col + (digit * (disp_char_width + disp_char_spacing));   // 1st digit is 0
    printf("%c[%d;%dH", A_ESC, digit_row, digit_col);                                   // put number in right digit
    switch(format){
        case 0:                                                                         // no need to do anything
            break;
        case 1:
            printf("%c[1m", A_ESC);
            break;
        case 2:
            printf("%c[7m", A_ESC);
            break;
        case 3:
            printf("%c[4m", A_ESC);
            break;
    }
    switch(character){
        case 0:
            printf(" ***** %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);                // chars then down 1 and back width
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf(" ***** ");                                                          // just chars
            break;
        case 1:
            printf("  **   %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf(" * *   %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("   *   %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("   *   %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("   *   %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("   *   %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf(" ***** ");
            break;
        case 2:
            printf(" ***** %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("      *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf(" ***** %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*      %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*      %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("******");
            break;
        case 3:
            printf(" ***** %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("      *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("  **** %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("      *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf(" ***** ");
            break;
        case 4:
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*******%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("      *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("      *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("      *");
            break;
        case 5:
            printf("****** %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*      %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*      %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf(" ***** %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("      *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf(" ***** ");
            break;
        case 6:
            printf(" ***** %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*      %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*      %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("****** %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf(" ***** ");
            break;
        case 7:
            printf(" ******%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("     * %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("    *  %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("    *  %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("    *  %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("    *  ");
            break;
        case 8:
            printf(" ***** %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf(" ***** %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf(" ***** ");
            break;
        case 9:
            printf(" ***** %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("*     *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf(" ******%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("      *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("      *%c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf(" ***** ");
            break;
        case 10:                                                                        // : separator
            printf("       %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("   *   %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("   *   %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("       %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("   *   %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("   *   %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("       ");
            break;
        case 11:                                                                        // / separator
            printf("       %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("     * %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("    *  %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("   *   %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("  *    %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf(" *     %c[1B%c[%dD", A_ESC, A_ESC, disp_char_width);
            printf("       ");
            break;
    }
       printf("%c[m", A_ESC);                                                           // normal text
    return;
}

void clear_screen()                                         // clear the screen
{
    printf("%c[2J", A_ESC);
    return;
}

void prepare_screen()                                       // prepare the screen for the clock and other information
{
   // initialize display
    clear_screen();
    
    printf("%c[7m", A_ESC);                                                               // inverse text
    printf("*******************************  Z80-MBC2 CLOCK  *******************************");
    printf("%c[m", A_ESC);                                                                // back to normal text
    printf("%c[11;0H", A_ESC);
    printf("********************************************************************************");
    printf("%c[21;0H", A_ESC);
    printf("********************************************************************************");

    printf("%c[22;5HTEMPERATURE", A_ESC);

    print_big_char(10,0,2,0);                                                               // HM separator
    print_big_char(10,0,5,0);                                                               // MS separator
    print_big_char(11,1,2,0);                                                               // DM separator
    print_big_char(11,1,5,0);                                                               // MY separator

    get_rtc_data();                                                                         // initial values
    display_date();
    display_initial_time();
    
    update_screen_temp();
    update_initial_screen_alert();

    return;
}

void display_date()                                         // date display
{
    if(date_format == 1){
        print_big_char(rtc[3]/10,1,0,0);
        print_big_char(rtc[3]%10,1,1,0);
        print_big_char(rtc[4]/10,1,3,0);
        print_big_char(rtc[4]%10,1,4,0);
        print_big_char(rtc[5]/10,1,6,0);
        print_big_char(rtc[5]%10,1,7,0);
    }
    else if(date_format == 2){
        print_big_char(rtc[4]/10,1,0,0);
        print_big_char(rtc[4]%10,1,1,0);
        print_big_char(rtc[3]/10,1,3,0);
        print_big_char(rtc[3]%10,1,4,0);
        print_big_char(rtc[5]/10,1,6,0);
        print_big_char(rtc[5]%10,1,7,0);
    }
    else{
        print_big_char(rtc[5]/10,1,0,0);
        print_big_char(rtc[5]%10,1,1,0);
        print_big_char(rtc[4]/10,1,3,0);
        print_big_char(rtc[4]%10,1,4,0);
        print_big_char(rtc[3]/10,1,6,0);
        print_big_char(rtc[3]%10,1,7,0);
    }
    return;
}

void display_initial_time()                                 // display initial time _excluding_ second units (because old by this point)
{
    print_big_char(rtc[2]/10,0,0,1);                                                        // clock display
    print_big_char(rtc[2]%10,0,1,1);
    print_big_char(rtc[1]/10,0,3,1);
    print_big_char(rtc[1]%10,0,4,1);
    print_big_char(rtc[0]/10,0,6,1);
    // print_big_char(rtc[0]%10,0,7,1);                     // exclude because old and always updated on screen update
    return;
}

void update_screen()                                        // update screen information
{
    print_big_char(rtc[0]%10,0,7,1);                                                  // update units of seconds
    if(rtc[0]/10 != old_rtc[0]/10){              // this used to check if units were zero, but edge case if seconds units skip from 8 or 9 to 1 or 2
        print_big_char(rtc[0]/10,0,6,1);                                              // update tens of seconds
    }

    if (rtc[1] != old_rtc[1]){                                                      // if minutes have changed
        print_big_char(rtc[1]%10,0,4,1);                                              // update units of minutes
        if(rtc[1]/10 != old_rtc[1]/10){ 
            print_big_char(rtc[1]/10,0,3,1);                                          // update tens of minutes
        }
        if (rtc[6] != old_rtc[6]){                                                  // and check the temperature
            update_screen_temp();
        }
        if(alert_set){
            update_screen_alert();                                                          // and update alert information
        }
    }

    if (rtc[2] != old_rtc[2]){                                                      // if hours have changed
        print_big_char(rtc[2]%10,0,1,1);                                              // update units of hours
        if(rtc[2]/10 != old_rtc[2]/10){                                                         // and if units are 0
            print_big_char(rtc[2]/10,0,0,1);                                          // update tens of hours
            if(rtc[2]/10 == 0){                                                     // and if tens are 0
                display_date();                                                     // update date at midnight
            }
        }
    }

    return; 
}

void intro_date_alert()                                     // print intro screen and get date format and alert info
{
    char alerts = 0;
    clear_screen();
    printf("%c[7m", A_ESC);                                 // inverse text
    printf("*******************************  Z80-MBC2 CLOCK  *******************************");
    printf("%c[m", A_ESC);                                  // back to normal text
    printf("\n\n");
    printf("Welcome to Z80-MBC2 Clock. Once the clock is running you can press the User Key\n");
    printf("on the Z80-MBC2 to exit.\n\n");
    while(date_format < 1 || date_format > 3){
        printf("Select date format. Enter 1 for dd/mm/yy, 2 for mm/dd/yy, 3 for yy/mm/dd. ");
        scanf("%d", &date_format);
    }
    printf("\n\n");
    printf("Z80-MBC2 Clock can alert you at regular intervals by flashing the blue User LED.\n");
    printf("This can be useful to ensure you are taking breaks from sitting and staring at\n");
    printf("a screen, for example.\n\n");
    printf("Would you like to set regular alerts (y or n)? ");
    while(alerts != 121 && alerts != 89 && alerts != 110 && alerts != 78){
        if(alerts != 0){
            printf("\nPlease enter y (or Y) for 'Yes' or n (or N) for 'No'. ");
        }
        scanf(" %c", &alerts);
    }
    
    if(alerts == 121 || alerts == 89){
           if(get_alert_wait(true)){                        // do alert_wait and ...
                get_alert_wait(false);                      // ... redo if games listed first time
        }
    }

    return;
}
